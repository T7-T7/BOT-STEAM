import fs from 'fs'
import path from 'path'
import os from 'os'
import { execFile } from 'child_process'
import { promisify } from 'util'
import https from 'https'
import zlib from 'zlib'

import {
    generateWAMessageFromContent,
    generateWAMessageContent,
    proto
} from '@whiskeysockets/baileys'

const TMP = os.tmpdir()
const execFileAsync = promisify(execFile)

const CHROME_CIPHERS = [
    'TLS_AES_128_GCM_SHA256',
    'TLS_AES_256_GCM_SHA384',
    'TLS_CHACHA20_POLY1305_SHA256',
    'ECDHE-ECDSA-AES128-GCM-SHA256',
    'ECDHE-RSA-AES128-GCM-SHA256',
    'ECDHE-ECDSA-AES256-GCM-SHA384',
    'ECDHE-RSA-AES256-GCM-SHA384',
    'ECDHE-ECDSA-CHACHA20-POLY1305',
    'ECDHE-RSA-CHACHA20-POLY1305',
    'ECDHE-RSA-AES128-SHA',
    'ECDHE-RSA-AES256-SHA',
    'AES128-GCM-SHA256',
    'AES256-GCM-SHA384',
    'AES128-SHA',
    'AES256-SHA'
].join(':')

const UA =
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) ' +
    'AppleWebKit/537.36 (KHTML, like Gecko) ' +
    'Chrome/131.0.0.0 Safari/537.36'

/* =========================================================
 * HTTP REQUEST
 * ========================================================= */

function request(
    url,
    {
        method = 'GET',
        maxRedirects = 8,
        headers = {},
        binary = false
    } = {}
) {
    return new Promise((resolve, reject) => {
        let u

        try {
            u = new URL(url)
        } catch {
            return reject(
                new Error('رابط غير صالح')
            )
        }

        const req = https.request(
            {
                hostname: u.hostname,
                port: u.port || undefined,
                path: u.pathname + u.search,
                method,

                headers: {
                    'User-Agent': UA,

                    'Accept':
                        'text/html,application/xhtml+xml,' +
                        'application/xml;q=0.9,*/*;q=0.8',

                    'Accept-Language':
                        'en-US,en;q=0.9',

                    'Accept-Encoding':
                        'gzip, deflate, br',

                    'Sec-Fetch-Dest': 'document',
                    'Sec-Fetch-Mode': 'navigate',
                    'Sec-Fetch-Site': 'none',
                    'Upgrade-Insecure-Requests': '1',

                    ...headers
                },

                timeout: 30000,

                ciphers:
                    CHROME_CIPHERS,

                minVersion:
                    'TLSv1.2',

                maxVersion:
                    'TLSv1.3'
            },

            async res => {
                /*
                 * مهم:
                 * نحتفظ بسلوك الـ scraper الأصلي.
                 * لا نضع whitelist على روابط CDN
                 * لأن Facebook قد يعيد روابط مختلفة.
                 */

                if (
                    [
                        301,
                        302,
                        303,
                        307,
                        308
                    ].includes(
                        res.statusCode
                    ) &&
                    res.headers.location &&
                    maxRedirects > 0
                ) {
                    res.resume()

                    let next =
                        res.headers.location

                    if (
                        !next.startsWith(
                            'http'
                        )
                    ) {
                        next =
                            new URL(
                                next,
                                url
                            ).href
                    }

                    try {
                        return resolve(
                            await request(
                                next,
                                {
                                    method,
                                    maxRedirects:
                                        maxRedirects -
                                        1,
                                    headers,
                                    binary
                                }
                            )
                        )
                    } catch (error) {
                        return reject(
                            error
                        )
                    }
                }

                const chunks = []

                res.on(
                    'data',
                    chunk =>
                        chunks.push(chunk)
                )

                res.on(
                    'error',
                    reject
                )

                res.on(
                    'end',
                    () => {
                        let buffer =
                            Buffer.concat(
                                chunks
                            )

                        try {
                            const encoding =
                                res.headers[
                                    'content-encoding'
                                ] || ''

                            if (
                                encoding.includes(
                                    'gzip'
                                )
                            ) {
                                buffer =
                                    zlib.gunzipSync(
                                        buffer
                                    )
                            } else if (
                                encoding.includes(
                                    'deflate'
                                )
                            ) {
                                buffer =
                                    zlib.inflateSync(
                                        buffer
                                    )
                            } else if (
                                encoding.includes(
                                    'br'
                                )
                            ) {
                                buffer =
                                    zlib.brotliDecompressSync(
                                        buffer
                                    )
                            }
                        } catch {}

                        resolve({
                            status:
                                res.statusCode,

                            headers:
                                res.headers,

                            buffer,

                            text:
                                binary
                                    ? ''
                                    : buffer.toString(
                                          'utf-8'
                                      )
                        })
                    }
                )
            }
        )

        req.on(
            'error',
            reject
        )

        req.on(
            'timeout',
            () => {
                req.destroy()

                reject(
                    new Error(
                        'انتهت مهلة الاتصال'
                    )
                )
            }
        )

        req.end()
    })
}

/* =========================================================
 * FACEBOOK SEARCH
 * ========================================================= */

async function searchFacebookVideo(
    query
) {
    const url =
        `https://www.facebook.com/watch/search/?q=${encodeURIComponent(
            query
        )}`

    const r =
        await request(url)

    /*
     * نفس منطق الـscraper الأصلي.
     *
     * لكن نرجع رسالة تشخيصية أفضل حتى نعرف
     * هل المشكلة 403 / redirect / صفحة تسجيل دخول.
     */

    if (
        r.status !== 200 ||
        r.text.length < 1000
    ) {
        console.error(
            '[Facebook Search]',
            {
                status: r.status,
                length: r.text?.length || 0,
                contentType:
                    r.headers?.[
                        'content-type'
                    ]
            }
        )

        throw new Error(
            'فيسبوك رفض البحث'
        )
    }

    const html =
        r.text

    const ids = []
    const seen = new Set()

    const idRegex =
        /"video_id":"(\d+)"/g

    let m

    while (
        (m =
            idRegex.exec(
                html
            )) !== null
    ) {
        if (
            !seen.has(
                m[1]
            )
        ) {
            seen.add(
                m[1]
            )

            ids.push(
                m[1]
            )
        }
    }

    const titles = []
    const seenT = new Set()

    const titleRegex =
        /"message":\{"text":"([^"]{5,150})"/g

    while (
        (m =
            titleRegex.exec(
                html
            )) !== null
    ) {
        const title =
            m[1]
                .replace(
                    /\\n/g,
                    ' '
                )
                .replace(
                    /\\"/g,
                    '"'
                )
                .trim()

        if (
            !seenT.has(
                title
            )
        ) {
            seenT.add(
                title
            )

            titles.push(
                title
            )
        }
    }

    const all =
        ids.map(
            (id, i) => ({
                id,

                title:
                    titles[i] ||
                    titles[0] ||
                    `Facebook Video ${
                        i + 1
                    }`,

                url:
                    `https://www.facebook.com/watch/?v=${id}`
            })
        )

    /*
     * نفس العشوائية الموجودة في scraper الأصلي.
     */

    for (
        let i =
            all.length - 1;
        i > 0;
        i--
    ) {
        const j =
            Math.floor(
                Math.random() *
                    (i + 1)
            )

        const temp =
            all[i]

        all[i] =
            all[j]

        all[j] =
            temp
    }

    return all
}

/* =========================================================
 * GET VIDEO URL
 * ========================================================= */

async function getVideoUrl(
    videoId,
    preferHD = true
) {
    const r =
        await request(
            `https://www.facebook.com/watch/?v=${videoId}`
        )

    if (
        r.status !== 200 ||
        r.text.length < 1000
    ) {
        throw new Error(
            'فشل فتح الفيديو'
        )
    }

    const html =
        r.text

    const sdMatch =
        html.match(
            /browser_native_sd_url":"([^"]+)"/
        )

    const hdMatch =
        html.match(
            /browser_native_hd_url":"([^"]+)"/
        )

    const clean =
        value =>
            value
                ? value
                      .replace(
                          /\\u0025/g,
                          '%'
                      )
                      .replace(
                          /\\u0026/g,
                          '&'
                      )
                      .replace(
                          /\\\//g,
                          '/'
                      )
                      .replace(
                          /\\/g,
                          ''
                      )
                : null

    const sd =
        clean(
            sdMatch?.[1]
        )

    const hd =
        clean(
            hdMatch?.[1]
        )

    if (
        !sd &&
        !hd
    ) {
        throw new Error(
            'ما لقيناش رابط الفيديو'
        )
    }

    if (
        preferHD &&
        hd
    ) {
        return hd
    }

    return (
        sd ||
        hd
    )
}

/* =========================================================
 * DOWNLOAD
 * ========================================================= */

async function downloadVideoToFile(
    url
) {
    const outFile =
        path.join(
            TMP,
            `fb_${Date.now()}_${Math.random()
                .toString(36)
                .slice(2)}.mp4`
        )

    /*
     * execFile بدل execSync مع shell string.
     * نفس الوظيفة لكن أكثر أمانًا مع روابط الفيديو.
     */

    const args = [
        '-y',

        '-user_agent',
        UA,

        '-headers',
        'Referer: https://www.facebook.com/\r\n',

        '-i',
        url,

        '-c',
        'copy',

        '-movflags',
        '+faststart',

        '-t',
        '60',

        outFile
    ]

    try {
        await execFileAsync(
            'ffmpeg',
            args,
            {
                timeout: 180000,
                maxBuffer: 2 * 1024 * 1024
            }
        )
    } catch (e) {
        const err =
            (
                e.stderr ||
                e.stdout ||
                e.message ||
                ''
            ) + ''

        throw new Error(
            'فشل التحميل: ' +
                err.slice(-500)
        )
    }

    if (
        !fs.existsSync(
            outFile
        )
    ) {
        throw new Error(
            'ملف الفيديو غير موجود'
        )
    }

    const stats =
        fs.statSync(
            outFile
        )

    if (
        !stats.size ||
        stats.size < 10000
    ) {
        try {
            fs.unlinkSync(
                outFile
            )
        } catch {}

        throw new Error(
            'ملف صغير'
        )
    }

    return outFile
}

/* =========================================================
 * BATCH
 * ========================================================= */

async function processBatch(
    items,
    fn,
    batchSize = 5
) {
    const results = []

    for (
        let i = 0;
        i < items.length;
        i += batchSize
    ) {
        const batch =
            items.slice(
                i,
                i + batchSize
            )

        const batchResults =
            await Promise.all(
                batch.map(
                    item =>
                        fn(
                            item
                        ).catch(
                            error => {
                                console.error(
                                    '[Facebook Batch]',
                                    error?.message ||
                                        error
                                )

                                return null
                            }
                        )
                )
            )

        results.push(
            ...batchResults
        )
    }

    return results
}

/* =========================================================
 * URL PARSER
 * ========================================================= */

function extractVideoId(
    input
) {
    const match =
        String(input)
            .trim()
            .match(
                /(?:v=|\/videos\/|reel\/)(\d+)/i
            )

    return (
        match?.[1] ||
        null
    )
}

function isFacebookUrl(
    text
) {
    return /^https?:\/\/(www\.|m\.)?(facebook\.com|fb\.watch)/i.test(
        String(text).trim()
    )
}

/* =========================================================
 * TEMP CLEANUP
 * ========================================================= */

function removeFile(
    file
) {
    if (!file) {
        return
    }

    try {
        fs.unlinkSync(
            file
        )
    } catch {}
}

/* =========================================================
 * COMMAND
 * ========================================================= */

export default {
    name: 'فيس_فيديو',

    aliases: [
        'فيس',
        'فيسبوك_فيديو',
        'fb_video',
        'بحث_فيس'
    ],

    category: 'وسائط',

    requiredRole: 'user',

    async execute(ctx) {
        const {
            message,
            sock
        } = ctx

        if (
            !message?.chatId ||
            !sock
        ) {
            return false
        }

        const text =
            Array.isArray(
                ctx.args
            )
                ? ctx.args
                      .join(' ')
                      .trim()
                : String(
                      ctx.text ||
                          ''
                  ).trim()

        const react =
            async emoji => {
                try {
                    await message.react?.(
                        emoji
                    )
                } catch {}
            }

        if (!text) {
            return message.reply(
                [
                    '📘 *بحث فيسبوك*',
                    '',
                    '🔍 *بحث:*',
                    '`.فيس_فيديو <كلمة>`',
                    '',
                    '📥 *تحميل:*',
                    '`.فيس <رابط>`',
                    '',
                    'مثال:',
                    '`.فيس_فيديو ميمز`'
                ].join(
                    '\n'
                )
            )
        }

        /* =================================================
         * DIRECT URL
         * ================================================= */

        if (
            isFacebookUrl(
                text
            )
        ) {
            await react(
                '⏳'
            )

            let file =
                null

            try {
                const videoId =
                    extractVideoId(
                        text
                    )

                if (
                    !videoId
                ) {
                    throw new Error(
                        'ما لقيناش ID الفيديو'
                    )
                }

                const videoUrl =
                    await getVideoUrl(
                        videoId,
                        true
                    )

                file =
                    await downloadVideoToFile(
                        videoUrl
                    )

                await message.reply({
                    video: {
                        url: file
                    },

                    mimetype:
                        'video/mp4',

                    caption:
                        '✅ Facebook Video'
                })

                await react(
                    '✅'
                )

                return true
            } catch (error) {
                await react(
                    '❌'
                )

                return message.reply(
                    '❌ ' +
                        (
                            error?.message ||
                            error
                        )
                )
            } finally {
                removeFile(
                    file
                )
            }
        }

        /* =================================================
         * SEARCH
         * ================================================= */

        await react(
            '⏳'
        )

        const tempFiles = []

        try {
            const videos =
                await searchFacebookVideo(
                    text
                )

            if (
                !videos.length
            ) {
                await react(
                    '❌'
                )

                return message.reply(
                    '❌ مفيش نتايج'
                )
            }

            /*
             * نفس النظام الأصلي:
             * أقصى 10 نتائج.
             */

            const toDownload =
                videos.slice(
                    0,
                    10
                )

            const videoUrls =
                await processBatch(
                    toDownload,

                    async video =>
                        getVideoUrl(
                            video.id,
                            true
                        ),

                    5
                )

            const files =
                await Promise.all(
                    videoUrls.map(
                        url =>
                            url
                                ? downloadVideoToFile(
                                      url
                                  ).catch(
                                      () =>
                                          null
                                  )
                                : null
                    )
                )

            const cards = []

            for (
                let i = 0;
                i <
                toDownload.length;
                i++
            ) {
                const file =
                    files[i]

                if (!file) {
                    continue
                }

                tempFiles.push(
                    file
                )

                try {
                    const {
                        videoMessage
                    } =
                        await generateWAMessageContent(
                            {
                                video: {
                                    url: file
                                },

                                mimetype:
                                    'video/mp4'
                            },
                            {
                                upload:
                                    sock.waUploadToServer
                            }
                        )

                    const video =
                        toDownload[i]

                    const title =
                        video.title ||
                        `Facebook Video ${
                            i + 1
                        }`

                    cards.push({
                        body:
                            proto
                                .Message
                                .InteractiveMessage
                                .Body.fromObject(
                                    {
                                        text:
                                            `🎬 ${title.slice(
                                                0,
                                                100
                                            )}`
                                    }
                                ),

                        footer:
                            proto
                                .Message
                                .InteractiveMessage
                                .Footer.fromObject(
                                    {
                                        text:
                                            '𓂃 ࣪˖ ִֶָ⚜️ 𝑺𝑻𝑬𝑨𝑴 𝑩𝑶𝑻 ♖ ִֶָ ˖ ࣪'
                                    }
                                ),

                        header:
                            proto
                                .Message
                                .InteractiveMessage
                                .Header.fromObject(
                                    {
                                        title:
                                            title.length >
                                            50
                                                ? title.substring(
                                                      0,
                                                      47
                                                  ) +
                                                  '...'
                                                : title,

                                        hasMediaAttachment:
                                            true,

                                        videoMessage
                                    }
                                ),

                        nativeFlowMessage:
                            proto
                                .Message
                                .InteractiveMessage
                                .NativeFlowMessage.fromObject(
                                    {
                                        buttons:
                                            []
                                    }
                                )
                    })
                } catch (error) {
                    console.error(
                        '[Facebook Card]',
                        error?.message ||
                            error
                    )
                }
            }

            if (
                !cards.length
            ) {
                await react(
                    '❌'
                )

                return message.reply(
                    '❌ فشل التحميل'
                )
            }

            const msg =
                generateWAMessageFromContent(
                    message.chatId,

                    {
                        viewOnceMessage: {
                            message: {
                                messageContextInfo:
                                    {
                                        deviceListMetadata:
                                            {},

                                        deviceListMetadataVersion:
                                            2
                                    },

                                interactiveMessage:
                                    proto
                                        .Message
                                        .InteractiveMessage
                                        .fromObject(
                                            {
                                                body:
                                                    proto
                                                        .Message
                                                        .InteractiveMessage
                                                        .Body.create(
                                                            {
                                                                text:
                                                                    `📘 *Facebook: ${text}*`
                                                            }
                                                        ),

                                                footer:
                                                    proto
                                                        .Message
                                                        .InteractiveMessage
                                                        .Footer.create(
                                                            {
                                                                text:
                                                                    '⚜️ *S T E A M B O T ♖*'
                                                            }
                                                        ),

                                                header:
                                                    proto
                                                        .Message
                                                        .InteractiveMessage
                                                        .Header.create(
                                                            {
                                                                hasMediaAttachment:
                                                                    false
                                                            }
                                                        ),

                                                carouselMessage:
                                                    proto
                                                        .Message
                                                        .InteractiveMessage
                                                        .CarouselMessage.fromObject(
                                                            {
                                                                cards
                                                            }
                                                        )
                                            }
                                        )
                            }
                        }
                    },

                    {
                        quoted:
                            message.raw
                    }
                )

            await sock.relayMessage(
                message.chatId,
                msg.message,
                {
                    messageId:
                        msg.key.id
                }
            )

            await react(
                '✅'
            )

            return true
        } catch (error) {
            console.error(
                '[FACEBOOK]',
                error?.message ||
                    error
            )

            await react(
                '❌'
            )

            return message.reply(
                '❌ ' +
                    (
                        error?.message ||
                        error
                    )
            )
        } finally {
            /*
             * نحذف الملفات بعد انتهاء
             * عملية relay/upload.
             */

            setTimeout(
                () => {
                    for (
                        const file of
                            tempFiles
                    ) {
                        removeFile(
                            file
                        )
                    }
                },
                120000
            )
        }
    }
}