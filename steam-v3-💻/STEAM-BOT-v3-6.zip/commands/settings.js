import { read, write } from '../database/index.js';
import { sendInteractive, listButton } from '../services/interactive.js';
import { setEnabled } from '../console/index.js';
import { setBotDeveloperMode } from '../services/bot-mode.js';

const defaults = {
  mode: 'public',
  console: true,
  bot: 'user'
};

async function getSettings() {
  return {
    ...defaults,
    ...(await read('settings.json', defaults))
  };
}

function normalize(value) {
  return String(value || '')
    .trim()
    .toLowerCase()
    .replace(/[_-]+/g, ' ')
    .replace(/\s+/g, ' ');
}

function parseSetting(args) {
  const input = normalize((args || []).join(' '));

  if (!input) return null;

  if (/^(مود|وضع) (عام|public)$/.test(input)) {
    return {
      key: 'mode',
      value: 'public'
    };
  }

  if (/^(مود|وضع) (خاص|خاصه|خاصّة|private)$/.test(input)) {
    return {
      key: 'mode',
      value: 'private'
    };
  }

  if (/^(طباعة|كونسول) (تشغيل|تشغيله|on|1)$/.test(input)) {
    return {
      key: 'console',
      value: true
    };
  }

  if (/^(طباعة|كونسول) (تعطيل|ايقاف|إيقاف|off|0)$/.test(input)) {
    return {
      key: 'console',
      value: false
    };
  }

  if (/^بوت (مطور|developer)$/.test(input)) {
    return {
      key: 'bot',
      value: 'developer'
    };
  }

  if (/^بوت (ليس مطور|غير مطور|user)$/.test(input)) {
    return {
      key: 'bot',
      value: 'user'
    };
  }

  return null;
}

function sections(s) {
  return [
    {
      title: '🌐 الوضع',
      rows: [
        {
          id: '.اعداد مود عام',
          title: '🌍 الوضع العام',
          description:
            s.mode === 'public'
              ? 'مفعل حاليًا'
              : 'تفعيل الوضع العام'
        },
        {
          id: '.اعداد مود خاص',
          title: '🔒 وضع المطورين',
          description:
            s.mode === 'private'
              ? 'مفعل حاليًا'
              : 'تفعيل وضع المطورين'
        }
      ]
    },
    {
      title: '💻 الكونسول',
      rows: [
        {
          id: '.اعداد طباعة تشغيل',
          title: '📋 طباعة الأوامر',
          description:
            s.console
              ? 'مفعل حاليًا'
              : 'تفعيل طباعة الكونسول'
        },
        {
          id: '.اعداد طباعة تعطيل',
          title: '🔇 تعطيل طباعة',
          description:
            !s.console
              ? 'مفعل حاليًا'
              : 'تعطيل طباعة الكونسول'
        }
      ]
    },
    {
      title: '🤖 البوت',
      rows: [
        {
          id: '.اعداد بوت مطور',
          title: '🤖 البوت مطور',
          description:
            s.bot === 'developer'
              ? 'مفعل حاليًا'
              : 'تعريف البوت كمطور'
        },
        {
          id: '.اعداد بوت ليس مطور',
          title: '👤 البوت ليس مطور',
          description:
            s.bot !== 'developer'
              ? 'مفعل حاليًا'
              : 'تعريف البوت كمستخدم'
        }
      ]
    }
  ];
}

function getSettingLabel(change) {
  if (change.key === 'mode') {
    return change.value === 'public'
      ? 'الوضع العام'
      : 'وضع المطورين';
  }

  if (change.key === 'console') {
    return change.value
      ? 'طباعة الأوامر'
      : 'تعطيل طباعة';
  }

  if (change.key === 'bot') {
    return change.value === 'developer'
      ? 'البوت مطور'
      : 'البوت ليس مطور';
  }

  return 'غير معروف';
}

export default {
  name: 'اعداد',
  aliases: ['إعداد', 'اعدادات', 'إعدادات'],
  category: 'نظام',
  requiredRole: 'developer',

  async execute({ message, sock, args }) {
    if (!message?.chatId || !sock) return false;

    const s = await getSettings();

    setBotDeveloperMode(s.bot);

    const change = parseSetting(args);

    if (args?.length && !change) {
      return message.reply(
        '⚠️ اختيار إعداد غير صحيح.\n' +
        'استخدم الأزرار أو:\n' +
        '`.اعداد مود عام` / `.اعداد مود خاص`\n' +
        '`.اعداد طباعة تشغيل` / `.اعداد طباعة تعطيل`\n' +
        '`.اعداد بوت مطور` / `.اعداد بوت ليس مطور`'
      );
    }

    /*
     * عند تغيير أي إعداد:
     * نحفظ التغيير ثم نرسل رسالة نجاح فقط.
     * لا نعيد إرسال قائمة الإعدادات.
     */
    if (change) {
      s[change.key] = change.value;

      await write('settings.json', s);

      if (change.key === 'console') {
        setEnabled(change.value);
      }

      if (change.key === 'bot') {
        setBotDeveloperMode(change.value);
      }

      const label = getSettingLabel(change);

      await message.reply(
        `✅ تم ضبط بنجاح\n` +
        `⚙️ الإعداد جديد : ${label}`
      );

      return true;
    }

    const mode =
      s.mode === 'public'
        ? 'الوضع العام'
        : 'وضع المطورين';

    const con =
      s.console
        ? 'طباعة الأوامر'
        : 'تعطيل طباعة';

    const bot =
      s.bot === 'developer'
        ? 'البوت مطور'
        : 'البوت ليس مطور';

    await sendInteractive(sock, message.chatId, {
      text:
        `⚙️ *إعدادات BOT*\n\n` +
        `┊⌔🌐︙ الوضع : *${mode}*\n` +
        `┊⌔💻︙ الكونسول : *${con}*\n` +
        `┊⌔🤖︙ البوت : *${bot}*`,

      title: '⚜️ *S T E A M B O T ♖*',

      footer:
        '𓂃 ࣪˖ ִֶָ⚜️ 𝑺𝑻𝑬𝑨𝑴 𝑩𝑶𝑻 ♖ ִֶָ ˖ ࣪',

      buttons: [
        listButton('𝐒𝐄𝐓𝐓𝐈𝐍𝐆𝐒', sections(s))
      ],

      quoted: message.raw
    });

    return true;
  }
};