import fs from 'fs/promises';
import path from 'path';
import { cleanArchiveName, updateArchive } from '../services/archive.js';
import { isGroupMessage, groupContext, assertSenderCanManageGroup } from '../services/group.js';
import { walkProject, isSensitivePath } from '../services/system-files.js';

const root = path.resolve('.');
const adir = path.resolve('./data/archives');

function normalizeRel(value) {
  return String(value || '')
    .replaceAll(path.sep, '/')
    .replace(/^\.\//, '');
}

/*
 * IMPORTANT:
 * This is intentionally the same ordering used by commands/system.js.
 * .حذف 30 therefore means exactly the same file shown as #30 by .سيستم.
 */
function orderedProjectFiles(files, dirs) {
  const allDirs = [...dirs]
    .filter(Boolean)
    .sort((a, b) => a.localeCompare(b, 'ar'));

  const ordered = [];

  for (const dir of allDirs) {
    const directFiles = files
      .filter(file => path.posix.dirname(file) === dir)
      .sort((a, b) => a.localeCompare(b, 'ar'));

    ordered.push(...directFiles);
  }

  const rootFiles = files
    .filter(file => !file.includes('/'))
    .sort((a, b) => a.localeCompare(b, 'ar'));

  ordered.push(...rootFiles);
  return ordered;
}

async function numberedSystemFiles() {
  const { files, dirs } = await walkProject();
  return orderedProjectFiles(files, dirs);
}

function safeProjectTarget(relativePath) {
  const rel = normalizeRel(relativePath);

  if (!rel || isSensitivePath(rel)) return null;

  const absolute = path.resolve(root, ...rel.split('/'));

  if (
    absolute !== root &&
    !absolute.startsWith(`${root}${path.sep}`)
  ) {
    return null;
  }

  return { rel, absolute };
}

async function deleteSystemFileByNumber(number) {
  const files = await numberedSystemFiles();
  const relativePath = files[number - 1];

  if (!relativePath) {
    return { ok: false, reason: 'invalid-number' };
  }

  const target = safeProjectTarget(relativePath);
  if (!target) {
    return { ok: false, reason: 'protected' };
  }

  try {
    const stat = await fs.stat(target.absolute);
    if (!stat.isFile()) {
      return { ok: false, reason: 'not-file' };
    }
  } catch {
    return { ok: false, reason: 'missing' };
  }

  await fs.unlink(target.absolute);

  return {
    ok: true,
    path: target.rel
  };
}

const safe = cleanArchiveName;

const deleteCommand = {
  name: 'حذف',
  aliases: [],
  category: 'إدارة',
  requiredRole: 'developer',

  async execute(ctx) {
    const raw = ctx.args.join(' ').trim();

    if (!raw) {
      return ctx.message.reply(
        '⚠️ `.حذف رقم` لحذف ملف بنفس رقم `.سيستم`، أو `.حذف اسم` لحذف أرشيف كامل، أو `.حذف اسم "1-2-3"` لحذف عناصر من الأرشيف.'
      );
    }

    const qm = raw.match(/^(.+?)\s+"(\d+(?:-\d+)*)"\s*$/);

    if (qm) {
      const name = safe(qm[1]);
      const ids = qm[2]
        .split('-')
        .map(Number)
        .sort((a, b) => b - a);

      try {
        let old = 0;
        let nextLength = 0;

        await updateArchive(name, archive => {
          if (!archive.entries.length) return archive;
          old = archive.entries.length;
          archive.entries = archive.entries.filter((_, i) => !ids.includes(i + 1));
          nextLength = archive.entries.length;
          return archive;
        });

        if (!old) {
          return ctx.message.reply('❌ الأرشيف غير موجود.');
        }

        return ctx.message.reply(
          `🗑️ تم حذف ${old - nextLength} عنصر من *أرشيف-${name}*.`
        );
      } catch {
        return ctx.message.reply('❌ الأرشيف غير موجود.');
      }
    }

    /*
     * Numeric input is ALWAYS interpreted as the global .سيستم index.
     * It is no longer restricted to commands/.
     */
    if (/^\d+$/.test(raw)) {
      const number = Number(raw);

      if (!Number.isSafeInteger(number) || number <= 0) {
        return ctx.message.reply('❌ رقم الملف غير صحيح.');
      }

      try {
        const result = await deleteSystemFileByNumber(number);

        if (!result.ok) {
          if (result.reason === 'protected') {
            return ctx.message.reply('❌ هذا الملف محمي ولا يمكن حذفه.');
          }

          return ctx.message.reply('❌ رقم الملف غير صحيح.');
        }

        return ctx.message.reply(
          `🗑️ تم حذف الملف رقم *${number}*:\n📄 *${result.path}*`
        );
      } catch (error) {
        console.error('[DELETE SYSTEM FILE]', error);
        return ctx.message.reply('❌ تعذر حذف الملف.');
      }
    }

    /* Named archive deletion remains supported. */
    try {
      await fs.unlink(
        path.join(adir, `${safe(raw)}.json`)
      );

      return ctx.message.reply(
        `🗑️ تم حذف الأرشيف: *${safe(raw)}*`
      );
    } catch {
      return ctx.message.reply(
        '❌ لم أجد الملف أو الأرشيف.'
      );
    }
  }
};

const delitCommand = {
  name: 'دليت',
  aliases: [],
  category: 'Tools',
  requiredRole: 'user',

  async execute(ctx) {
    const { message, sock } = ctx;

    if (!message?.chatId || !sock) return false;

    const quoted = message.quoted;

    if (!quoted?.id) {
      return message.reply(
        '⚠️ اعمل رد على الرسالة التي تريد حذفها ثم اكتب `.دليت`.'
      );
    }

    if (!quoted.fromMe && isGroupMessage(message)) {
      try {
        const { metadata } = await groupContext(ctx);
        assertSenderCanManageGroup(ctx, metadata);
      } catch (error) {
        return message.reply(error?.message || String(error));
      }
    }

    const deleteKey = {
      remoteJid: message.chatId,
      id: quoted.id,
      fromMe: Boolean(quoted.fromMe)
    };

    if (quoted.participant) deleteKey.participant = quoted.participant;
    if (quoted.participantAlt) deleteKey.participantAlt = quoted.participantAlt;

    try {
      await sock.sendMessage(message.chatId, { delete: deleteKey });
      return true;
    } catch (error) {
      console.error('[DELIT]', error);
      return message.reply(
        `❌ تعذر حذف الرسالة.\nالسبب: ${error?.message || error}`
      );
    }
  }
};

export default {
  commands: [deleteCommand, delitCommand]
};
