import {
  groupContext,
  assertSenderCanManageGroup,
  isGroupMessage
} from '../services/group.js';

async function requireGroupAdmin(ctx) {
  if (!isGroupMessage(ctx.message)) {
    throw new Error(
      '⚠️ هذا الأمر يعمل داخل المجموعات فقط.'
    );
  }

  const { metadata } = await groupContext(ctx, {
    fresh: true
  });

  assertSenderCanManageGroup(ctx, metadata);

  return metadata;
}

async function closeChat(ctx) {
  const { message, sock } = ctx;

  await requireGroupAdmin(ctx);

  try {
    await sock.groupSettingUpdate(
      message.chatId,
      'announcement'
    );

    await message.react?.('🔒');

    return message.reply(
      '🔒 *تم قفل الشات.*\n\n' +
      '👑 المشرفون فقط يمكنهم إرسال الرسائل الآن.'
    );
  } catch (error) {
    console.error(
      '[ق شات]',
      error
    );

    await message.react?.('❌');

    return message.reply(
      `❌ تعذر قفل الشات.\n` +
      `السبب: ${error?.message || error}`
    );
  }
}

async function openChat(ctx) {
  const { message, sock } = ctx;

  await requireGroupAdmin(ctx);

  try {
    await sock.groupSettingUpdate(
      message.chatId,
      'not_announcement'
    );

    await message.react?.('🔓');

    return message.reply(
      '🔓 *تم فتح الشات.*\n\n' +
      '👥 جميع الأعضاء يمكنهم إرسال الرسائل الآن.'
    );
  } catch (error) {
    console.error(
      '[ف شات]',
      error
    );

    await message.react?.('❌');

    return message.reply(
      `❌ تعذر فتح الشات.\n` +
      `السبب: ${error?.message || error}`
    );
  }
}

export default {
  commands: [
    {
      name: 'ق شات',

      aliases: [
        'قشات',
        'ق_شات'
      ],

      category: 'إدارة',

      requiredRole: 'user',

      async execute(ctx) {
        try {
          return await closeChat(ctx);
        } catch (error) {
          console.error(
            '[ق شات]',
            error
          );

          return ctx.message.reply(
            `❌ تعذر تنفيذ أمر قفل الشات.\n` +
            `السبب: ${error?.message || error}`
          );
        }
      }
    },

    {
      name: 'ف شات',

      aliases: [
        'فشات',
        'ف_شات'
      ],

      category: 'إدارة',

      requiredRole: 'user',

      async execute(ctx) {
        try {
          return await openChat(ctx);
        } catch (error) {
          console.error(
            '[ف شات]',
            error
          );

          return ctx.message.reply(
            `❌ تعذر تنفيذ أمر فتح الشات.\n` +
            `السبب: ${error?.message || error}`
          );
        }
      }
    }
  ]
};