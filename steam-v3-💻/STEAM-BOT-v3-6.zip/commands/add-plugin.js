import fs from 'fs/promises';
import path from 'path';
import { execFile } from 'child_process';
import { promisify } from 'util';
import { downloadMediaMessage } from '@whiskeysockets/baileys';
import { isSensitivePath } from '../services/system-files.js';

const execFileAsync = promisify(execFile);
const ROOT = path.resolve('.');

/* =========================================================
 * PATH
 * ========================================================= */

function normalizePath(value) {
  return String(value || '')
    .trim()
    .replaceAll('\\', '/')
    .replace(/^\/+/, '')
    .replace(/\/+/g, '/');
}

function insideRoot(absolute) {
  return (
    absolute === ROOT ||
    absolute.startsWith(`${ROOT}${path.sep}`)
  );
}

function validateTarget(input) {
  const relative = normalizePath(input);

  if (!relative) {
    return {
      ok: false,
      reason: 'empty'
    };
  }

  if (
    relative.includes('\0') ||
    relative === '..' ||
    relative.startsWith('../') ||
    relative.includes('/../')
  ) {
    return {
      ok: false,
      reason: 'traversal'
    };
  }

  /*
   * لا نفرض امتداد .js.
   * يمكن الآن إنشاء/تعديل أي ملف، مثل:
   *
   * commands/test.py
   * commands/test.php
   * commands/test.ts
   * services/test.css
   * assets/logo.png
   * config.json
   * README.md
   */

  if (isSensitivePath(relative)) {
    return {
      ok: false,
      reason: 'protected'
    };
  }

  const absolute = path.resolve(
    ROOT,
    ...relative.split('/')
  );

  if (!insideRoot(absolute)) {
    return {
      ok: false,
      reason: 'outside-root'
    };
  }

  return {
    ok: true,
    relative,
    absolute
  };
}

/* =========================================================
 * QUOTED MESSAGE
 * ========================================================= */

function quotedRoot(ctx) {
  return ctx.message?.quoted?.message || {};
}

function quotedMediaKey(root) {
  if (root.imageMessage) {
    return 'imageMessage';
  }

  if (root.videoMessage) {
    return 'videoMessage';
  }

  if (root.audioMessage) {
    return 'audioMessage';
  }

  if (root.documentMessage) {
    return 'documentMessage';
  }

  if (root.stickerMessage) {
    return 'stickerMessage';
  }

  return null;
}

/* =========================================================
 * DOWNLOAD QUOTED MEDIA
 * ========================================================= */

async function downloadQuotedMedia(ctx, root, key) {
  const q = ctx.message?.quoted;

  if (!q || !key || !root?.[key]) {
    return null;
  }

  const buffer = await downloadMediaMessage(
    {
      key: q.key || {
        remoteJid: q.chatId,
        id: q.id,
        fromMe: q.fromMe,
        participant: q.participant
      },
      message: root
    },
    'buffer',
    {},
    {
      logger: console,
      reuploadRequest: ctx.sock.updateMediaMessage
    }
  );

  if (!Buffer.isBuffer(buffer) || !buffer.length) {
    throw new Error('الملف المقتبس لا يحتوي على بيانات قابلة للتحميل.');
  }

  return buffer;
}

/* =========================================================
 * EXTRACT QUOTED TEXT
 * ========================================================= */

function quotedText(root) {
  if (root.conversation) {
    return root.conversation;
  }

  if (root.extendedTextMessage?.text) {
    return root.extendedTextMessage.text;
  }

  /*
   * إذا كان Reply على صورة/فيديو/مستند وله Caption،
   * نعتبر الـ Caption محتوى نصيًا عندما لا نستخدم
   * الوسائط نفسها.
   */

  return (
    root.imageMessage?.caption ||
    root.videoMessage?.caption ||
    root.documentMessage?.caption ||
    root.audioMessage?.caption ||
    ''
  );
}

/* =========================================================
 * CONTENT
 * ========================================================= */

async function readQuotedContent(ctx, target) {
  const root = quotedRoot(ctx);

  if (!root || !Object.keys(root).length) {
    return null;
  }

  const mediaKey = quotedMediaKey(root);

  /*
   * الصور/الفيديو/الصوت/المستندات تحفظ كـ Binary.
   * هذا يسمح مثلًا بـ:
   *
   * .ضيف assets/logo.png
   * ثم Reply على صورة.
   *
   * وكذلك:
   * .ضيف files/test.py
   * ثم Reply على ملف Python.
   */
  if (mediaKey) {
    const buffer = await downloadQuotedMedia(
      ctx,
      root,
      mediaKey
    );

    return {
      kind: 'binary',
      buffer,
      sourceType: mediaKey,
      caption: quotedText(root)
    };
  }

  const text = quotedText(root);

  if (String(text || '').trim()) {
    return {
      kind: 'text',
      buffer: Buffer.from(String(text), 'utf8'),
      sourceType: 'text'
    };
  }

  return null;
}

/* =========================================================
 * JAVASCRIPT SYNTAX CHECK
 * ========================================================= */

async function validateJavaScript(code) {
  const tempDir = await fs.mkdtemp(
    path.join(ROOT, '.steam-jscheck-')
  );

  const tempFile = path.join(
    tempDir,
    'check.js'
  );

  try {
    await fs.writeFile(
      tempFile,
      String(code),
      'utf8'
    );

    await execFileAsync(
      process.execPath,
      ['--check', tempFile],
      {
        windowsHide: true
      }
    );

    return {
      ok: true
    };
  } catch (error) {
    return {
      ok: false,
      error: String(
        error?.stderr ||
        error?.stdout ||
        error?.message ||
        error
      ).trim()
    };
  } finally {
    await fs.rm(
      tempDir,
      {
        recursive: true,
        force: true
      }
    ).catch(() => {});
  }
}

/* =========================================================
 * CURRENT FILE
 * ========================================================= */

async function currentFile(absolute) {
  try {
    const stat = await fs.stat(absolute);

    if (!stat.isFile()) {
      return {
        exists: true,
        isFile: false
      };
    }

    return {
      exists: true,
      isFile: true,
      source: await fs.readFile(absolute)
    };
  } catch {
    return {
      exists: false,
      isFile: true,
      source: null
    };
  }
}

/* =========================================================
 * HELPERS
 * ========================================================= */

function extensionOf(relative) {
  return path.extname(relative).toLowerCase();
}

function isJavaScriptFile(relative) {
  return [
    '.js',
    '.mjs',
    '.cjs'
  ].includes(
    extensionOf(relative)
  );
}

function isTextLikeFile(relative) {
  return [
    '.js', '.mjs', '.cjs',
    '.ts', '.tsx', '.jsx',
    '.py', '.pyw',
    '.php', '.rb', '.go',
    '.rs', '.java', '.kt', '.kts',
    '.c', '.h', '.cpp', '.hpp',
    '.cs', '.swift', '.dart',
    '.lua', '.r', '.sql',
    '.sh', '.bash', '.zsh',
    '.ps1', '.bat', '.cmd',
    '.html', '.htm', '.css', '.scss', '.sass',
    '.xml', '.svg', '.json', '.json5',
    '.yaml', '.yml', '.toml',
    '.ini', '.conf', '.env',
    '.md', '.markdown', '.txt',
    '.vue', '.svelte', '.astro',
    '.graphql', '.gql',
    '.proto', '.dockerfile'
  ].includes(
    extensionOf(relative)
  );
}

function usage() {
  return [
    '⚡ *طريقة استخدام أمر .ضيف*',
    '',
    '💻 *لغات البرمجة:*',
    '`.ضيف commands/test.py`',
    '`.ضيف commands/test.php`',
    '`.ضيف commands/test.ts`',
    '`.ضيف commands/test.cpp`',
    '`.ضيف commands/test.java`',
    '',
    '📝 *ملفات نصية وإعدادات:*',
    '`.ضيف config.json`',
    '`.ضيف README.md`',
    '`.ضيف styles.css`',
    '',
    '🖼️ *صورة:*',
    'Reply على الصورة ثم:',
    '`.ضيف assets/logo.png`',
    '',
    '📦 *ملف:*',
    'Reply على الملف ثم:',
    '`.ضيف path/to/file.ext`',
    '',
    '📌 لا يوجد الآن شرط JavaScript فقط.',
    '📌 إذا كان الملف `.js` / `.mjs` / `.cjs` سيتم فحص Syntax قبل الحفظ.',
    '📌 المجلدات غير الموجودة يتم إنشاؤها تلقائيًا.'
  ].join('\n');
}

function successMessage(target, content, previous) {
  const sourceLabel =
    content.kind === 'binary'
      ? `📦 ${content.sourceType}`
      : '📝 نص / كود';

  return [
    previous.exists
      ? '✅ تم تحديث الملف.'
      : '✅ تم إنشاء الملف.',
    '',
    `📄 *${target.relative}*`,
    sourceLabel,
    '🔄 تمت إعادة تحميل النظام بنجاح.'
  ].join('\n');
}

/* =========================================================
 * COMMAND
 * ========================================================= */

export default {
  name: 'ضيف',

  category: 'نظام',

  requiredRole: 'developer',

  async execute(ctx) {
    const input = (ctx.args || [])
      .join(' ')
      .trim();

    if (!input) {
      return ctx.message.reply(
        usage()
      );
    }

    const target =
      validateTarget(input);

    if (!target.ok) {
      const messages = {
        empty:
          '❌ لم تحدد مسار الملف.',

        traversal:
          '❌ المسار غير صالح.',

        protected:
          '❌ هذا المسار محمي ولا يمكن تعديله بهذا الأمر.',

        'outside-root':
          '❌ لا يمكن الكتابة خارج مجلد البوت.'
      };

      return ctx.message.reply(
        `${messages[target.reason] || '❌ مسار غير صالح.'}\n\n${usage()}`
      );
    }

    let content;

    try {
      content =
        await readQuotedContent(
          ctx,
          target
        );
    } catch (error) {
      return ctx.message.reply(
        [
          '❌ تعذر قراءة المحتوى المقتبس.',
          '',
          `السبب: ${error?.message || error}`,
          '',
          usage()
        ].join('\n')
      );
    }

    if (!content?.buffer?.length) {
      return ctx.message.reply(
        [
          '❌ لم أجد محتوى صالحًا في الرسالة المقتبسة.',
          '',
          '💡 اعمل Reply على كود، نص، صورة، فيديو، صوت، أو ملف ثم استخدم `.ضيف المسار`.',
          '',
          usage()
        ].join('\n')
      );
    }

    /* =====================================================
     * JAVASCRIPT ONLY VALIDATION
     * =====================================================
     *
     * لا نفحص Python / PHP / Java / C++ ... إلخ.
     * فحص Syntax المدمج هنا خاص بـ Node.js فقط.
     */

    if (
      content.kind === 'text' &&
      isJavaScriptFile(target.relative)
    ) {
      const code =
        content.buffer.toString('utf8');

      const syntax =
        await validateJavaScript(
          code
        );

      if (!syntax.ok) {
        return ctx.message.reply(
          [
            '❌ الكود JavaScript يحتوي على خطأ Syntax.',
            '',
            '```',
            syntax.error.slice(0, 2500),
            '```',
            '',
            '⚠️ لم يتم تعديل الملف.'
          ].join('\n')
        );
      }
    }

    const previous =
      await currentFile(
        target.absolute
      );

    if (
      previous.exists &&
      !previous.isFile
    ) {
      return ctx.message.reply(
        '❌ المسار المحدد مجلد وليس ملفًا.'
      );
    }

    await fs.mkdir(
      path.dirname(
        target.absolute
      ),
      {
        recursive: true
      }
    );

    /*
     * الكتابة Binary مباشرة.
     * هذا يحافظ على الصور والملفات كما هي.
     */

    await fs.writeFile(
      target.absolute,
      content.buffer
    );

    /*
     * لا توجد إعادة تحميل تلقائية بعد إنشاء الملف.
     * ملفات JavaScript الجديدة تحتاج إعادة تشغيل يدوية للبوت
     * حتى تدخل Registry.
     */

    return ctx.message.reply(
      successMessage(
        target,
        content,
        previous
      )
    );
  }
};