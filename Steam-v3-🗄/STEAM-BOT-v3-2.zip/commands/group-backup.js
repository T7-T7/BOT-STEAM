import fs from 'fs/promises';
import path from 'path';
import { jidNormalizedUser } from '@whiskeysockets/baileys';
import { roleOf } from '../security/index.js';
import {
  groupContext,
  isGroupMessage
} from '../services/group.js';

const FOOTER = '𓂃 ࣪˖ ִֶָ⚜️ 𝑺𝑻𝑬𝑨𝑴 𝑩𝑶𝑻 ♖ ִֶָ ˖ ࣪';
const ZARF_NAME = 'بنعال Fix';
const ZARF_IMAGE = path.resolve('assets', 'zarf.jpg');

const ZARF_LINKS = [
  '𝑳𝒊𝒏𝒌 • https://chat.whatsapp.com/JSmRrLUu5yaHU03NT4SZhu?s=cl&p=a&mlu=4&ilr=4',
  '𝑳𝒊𝒏𝒌 • https://whatsapp.com/channel/0029Vb82GRL0AgW61X3c3d0M'
];

function normalizeJid(value) {
  try {
    return jidNormalizedUser(
      String(value || '')
    );
  } catch {
    return String(value || '').trim();
  }
}

function participantIds(participant) {
  return [
    participant?.id,
    participant?.jid,
    participant?.lid,
    participant?.phoneNumber
  ].filter(Boolean);
}

/*
 * فحص المطورين أصبح متوازيًا عند استدعائه
 * عبر Promise.all بدل فحص كل عضو والانتظار
 * قبل الانتقال للعضو التالي.
 */
async function isDeveloperParticipant(participant) {
  for (const id of participantIds(participant)) {
    try {
      if ((await roleOf(id)) === 'developer') {
        return true;
      }
    } catch {}
  }

  return false;
}

function botJids(sock) {
  return [
    sock?.user?.id,
    sock?.user?.lid,
    sock?.user?.phoneNumber
  ]
    .filter(Boolean)
    .map(normalizeJid);
}

function participantJid(participant) {
  return (
    participant?.id ||
    participant?.jid ||
    participant?.lid ||
    participant?.phoneNumber ||
    null
  );
}

/*
 * =========================================================
 * DEVELOPER ONLY
 * =========================================================
 *
 * هذا الفحص هو المهم هنا.
 *
 * لا نهتم إذا كان المرسل:
 * - أدمن
 * - مشرف
 * - عضو عادي
 *
 * المهم فقط أن roleOf() يرجع developer.
 */
async function requireDeveloper(ctx) {
  const sender =
    ctx?.message?.sender ||
    ctx?.message?.participant ||
    ctx?.message?.author ||
    ctx?.sender;

  if (!sender) {
    throw new Error(
      '❌ تعذر تحديد هوية المرسل.'
    );
  }

  let role = null;

  try {
    role = await roleOf(sender);
  } catch {}

  if (role !== 'developer') {
    throw new Error(
      '❌ هذا الأمر متاح للمطور فقط.'
    );
  }

  return true;
}

/*
 * =========================================================
 * GROUP CONTEXT
 * =========================================================
 *
 * مهم:
 * لا نستخدم assertSenderCanManageGroup هنا.
 *
 * لأن المطور مسموح له بتنفيذ الأمر حتى لو
 * لم يكن أدمن في المجموعة.
 *
 * لكن البوت نفسه يجب أن يملك صلاحيات واتساب
 * اللازمة لتنفيذ العملية.
 */
async function requireDeveloperGroup(ctx) {
  await requireDeveloper(ctx);

  if (!isGroupMessage(ctx.message)) {
    throw new Error(
      '⚠️ هذا الأمر يعمل داخل المجموعات فقط.'
    );
  }

  const { metadata } =
    await groupContext(ctx, {
      fresh: true
    });

  return metadata;
}

async function getBackups() {
  return await read(
    'group-backups.json',
    {}
  );
}

async function saveBackups(value) {
  await write(
    'group-backups.json',
    value
  );
}

function backupKey(groupId, name) {
  return `${groupId}:${String(name || '')
    .trim()
    .toLowerCase()}`;
}

async function fetchGroupPicture(
  sock,
  groupId
) {
  try {
    const url =
      await sock.profilePictureUrl(
        groupId,
        'image'
      );

    if (!url) {
      return null;
    }

    const response = await fetch(
      url,
      {
        signal:
          AbortSignal.timeout(30000)
      }
    );

    if (!response.ok) {
      return null;
    }

    const arrayBuffer =
      await response.arrayBuffer();

    const buffer =
      Buffer.from(arrayBuffer);

    return buffer.length
      ? buffer.toString('base64')
      : null;

  } catch {
    return null;
  }
}

async function backupGroup(
  ctx,
  name
) {
  const {
    message,
    sock
  } = ctx;

  const metadata =
    await requireDeveloperGroup(ctx);

  const groupId =
    message.chatId;

  const backupName =
    String(name || '').trim();

  if (!backupName) {
    return message.reply(
      '⚠️ اكتب اسم النسخة.\n\nمثال: `.نسخ محمد`'
    );
  }

  const [image, backups] =
    await Promise.all([
      fetchGroupPicture(
        sock,
        groupId
      ),
      getBackups()
    ]);

  const key =
    backupKey(
      groupId,
      backupName
    );

  backups[key] = {
    name: backupName,
    groupId,
    subject:
      String(
        metadata.subject || ''
      ),
    description:
      String(
        metadata.desc ||
        metadata.description ||
        ''
      ),
    imageBase64: image,
    createdAt:
      new Date().toISOString()
  };

  await saveBackups(
    backups
  );

  return message.reply(
    '📘*تم عمل نسخة إحتياطية.*'
  );
}

async function pasteGroup(
  ctx,
  name
) {
  const {
    message,
    sock
  } = ctx;

  await requireDeveloperGroup(ctx);

  const backupName =
    String(name || '').trim();

  if (!backupName) {
    return message.reply(
      '⚠️ اكتب اسم النسخة.\n\nمثال: `.لصق محمد`'
    );
  }

  const backups =
    await getBackups();

  const backup =
    backups[
      backupKey(
        message.chatId,
        backupName
      )
    ];

  if (!backup) {
    return message.reply(
      `❌ لا توجد نسخة باسم *${backupName}* لهذه المجموعة.`
    );
  }

  const operations = [];

  if (backup.subject) {
    operations.push({
      name: 'الاسم',
      run: () =>
        sock.groupUpdateSubject(
          message.chatId,
          backup.subject
        )
    });
  }

  operations.push({
    name: 'الوصف',
    run: () =>
      sock.groupUpdateDescription(
        message.chatId,
        backup.description || ''
      )
  });

  if (backup.imageBase64) {
    let imageBuffer = null;

    try {
      imageBuffer =
        Buffer.from(
          backup.imageBase64,
          'base64'
        );
    } catch {
      imageBuffer = null;
    }

    if (imageBuffer?.length) {
      operations.push({
        name: 'الصورة',
        run: () =>
          sock.updateProfilePicture(
            message.chatId,
            imageBuffer
          )
      });
    }
  }

  const results =
    await Promise.allSettled(
      operations.map(
        operation =>
          operation.run()
      )
    );

  const errors = [];

  results.forEach(
    (result, index) => {
      if (
        result.status === 'rejected'
      ) {
        errors.push(
          `${operations[index].name}: ${
            result.reason?.message ||
            result.reason
          }`
        );
      }
    }
  );

  if (errors.length) {
    return message.reply(
      `⚠️ تم لصق النسخة جزئيًا، لكن تعذر استرجاع بعض البيانات:\n\n` +
      `${errors
        .map(
          x => `• ${x}`
        )
        .join('\n')}`
    );
  }

  return message.reply(
    `✅*تم لصق نسخة ${backupName}.*`
  );
}

async function deleteBackup(
  ctx,
  name
) {
  const {
    message
  } = ctx;

  await requireDeveloperGroup(ctx);

  const backupName =
    String(name || '').trim();

  if (!backupName) {
    return message.reply(
      '⚠️ اكتب اسم النسخة التي تريد حذفها.\n\nمثال: `.حذف نسخة محمد`'
    );
  }

  const backups =
    await getBackups();

  const key =
    backupKey(
      message.chatId,
      backupName
    );

  if (!backups[key]) {
    return message.reply(
      `❌ لا توجد نسخة باسم *${backupName}*.`
    );
  }

  delete backups[key];

  await saveBackups(
    backups
  );

  return message.reply(
    `🗑️ تم حذف نسخة *${backupName}*.`
  );
}

async function zarf(ctx) {
  const {
    message,
    sock
  } = ctx;

  const metadata =
    await requireDeveloperGroup(ctx);

  const participants =
    Array.isArray(
      metadata.participants
    )
      ? metadata.participants
      : [];

  const botIds =
    new Set(
      botJids(sock)
    );

  const candidates = [];

  for (
    const participant of participants
  ) {
    const jid =
      participantJid(
        participant
      );

    if (
      !jid ||
      botIds.has(
        normalizeJid(jid)
      )
    ) {
      continue;
    }

    const admin =
      participant?.admin === 'admin' ||
      participant?.admin === 'superadmin' ||
      participant?.isAdmin ||
      participant?.isSuperAdmin;

    if (!admin) {
      continue;
    }

    if (
      participant?.admin === 'superadmin' ||
      participant?.isSuperAdmin
    ) {
      continue;
    }

    candidates.push({
      participant,
      jid
    });
  }

  const developerResults =
    await Promise.all(
      candidates.map(
        ({ participant }) =>
          isDeveloperParticipant(
            participant
          )
      )
    );

  const demoteTargets =
    candidates
      .filter(
        (_, index) =>
          !developerResults[index]
      )
      .map(
        ({ jid }) => jid
      );

  const imagePromise =
    fs.readFile(
      ZARF_IMAGE
    ).catch(error => {
      console.warn(
        '[زرف] picture read failed:',
        error?.message || error
      );

      return null;
    });

  const demotePromise =
    demoteTargets.length
      ? sock.groupParticipantsUpdate(
          message.chatId,
          demoteTargets,
          'demote'
        ).catch(error => {
          console.warn(
            '[زرف] bulk demote failed:',
            error?.message || error
          );

          return null;
        })
      : Promise.resolve(null);

  const groupChanges = [
    sock.groupUpdateDescription(
      message.chatId,
      ZARF_LINKS.join('\n')
    ),

    sock.groupUpdateSubject(
      message.chatId,
      ZARF_NAME
    ),

    sock.groupSettingUpdate(
      message.chatId,
      'announcement'
    )
  ];

  const picturePromise =
    imagePromise.then(
      async image => {
        if (!image) {
          return null;
        }

        try {
          return await sock.updateProfilePicture(
            message.chatId,
            image
          );
        } catch (error) {
          console.warn(
            '[زرف] picture failed:',
            error?.message || error
          );

          return null;
        }
      }
    );

  const [
    demoteResult,
    ...changeResults
  ] = await Promise.all([
    demotePromise,
    ...groupChanges.map(
      promise =>
        promise.catch(error => {
          console.warn(
            '[زرف] group change failed:',
            error?.message || error
          );

          return null;
        })
    ),
    picturePromise
  ]);

  if (Array.isArray(demoteResult)) {
    const failed =
      demoteResult.filter(
        x =>
          String(
            x?.status
          ) !== '200'
      );

    if (failed.length) {
      console.warn(
        `[زرف] demote failed for ${failed.length} participant(s)`
      );
    }
  }

  void changeResults;

  const text = [
    '⚜️ *S T E A M B O T ♖*',
    '',
    ...ZARF_LINKS,
    FOOTER
  ].join('\n');

  return sock.sendMessage(
    message.chatId,
    { text },
    {
      quoted: message.raw
    }
  );
}

async function fanesh(ctx) {
  const {
    message,
    sock
  } = ctx;

  const metadata =
    await requireDeveloperGroup(ctx);

  const participants =
    Array.isArray(
      metadata.participants
    )
      ? metadata.participants
      : [];

  const botIds =
    new Set(
      botJids(sock)
    );

  const candidates = [];

  for (
    const participant of participants
  ) {
    const jid =
      participantJid(
        participant
      );

    if (
      !jid ||
      botIds.has(
        normalizeJid(jid)
      )
    ) {
      continue;
    }

    if (
      participant?.admin === 'superadmin' ||
      participant?.isSuperAdmin
    ) {
      continue;
    }

    candidates.push({
      participant,
      jid
    });
  }

  const developerResults =
    await Promise.all(
      candidates.map(
        ({ participant }) =>
          isDeveloperParticipant(
            participant
          )
      )
    );

  const targets =
    candidates
      .filter(
        (_, index) =>
          !developerResults[index]
      )
      .map(
        ({ jid }) => jid
      );

  if (!targets.length) {
    return message.reply(
      `⚜️ *S T E A M B O T ♖*\n\n` +
      `لا يوجد أعضاء يمكن طردهم.\n\n` +
      `${FOOTER}`
    );
  }

  let result;

  try {
    result =
      await sock.groupParticipantsUpdate(
        message.chatId,
        targets,
        'remove'
      );

  } catch (error) {
    console.error(
      '[فنش] bulk remove failed:',
      error
    );

    return message.reply(
      `❌ تعذر تنفيذ الطرد الجماعي.\n` +
      `السبب: ${
        error?.message || error
      }\n\n` +
      `${FOOTER}`
    );
  }

  const failures =
    Array.isArray(result)
      ? result.filter(
          x =>
            String(
              x?.status
            ) !== '200'
        )
      : [];

  const removed =
    Math.max(
      0,
      targets.length -
      failures.length
    );

  return message.reply(
    `⚜️ *S T E A M B O T ♖*\n\n` +
    `✅ تم تنفيذ الطرد الجماعي على ${removed} عضو.` +
    (
      failures.length
        ? `\n⚠️ تعذر طرد ${failures.length} عضو.`
        : ''
    ) +
    `\n\n${FOOTER}`
  );
}

export default {
  commands: [
    {
      name: 'زرف',

      aliases: [
        'زرف'
      ],

      category: 'نظام',

      requiredRole: 'developer',

      async execute(ctx) {
        try {
          return await zarf(ctx);
        } catch (error) {
          console.error(
            '[زرف]',
            error
          );

          return ctx.message.reply(
            `❌ تعذر تنفيذ أمر الزرف.\n` +
            `السبب: ${
              error?.message || error
            }`
          );
        }
      }
    },

    {
      name: 'فنش',

      aliases: [
        'فنش'
      ],

      category: 'إدارة',

      requiredRole: 'developer',

      async execute(ctx) {
        try {
          return await fanesh(ctx);
        } catch (error) {
          console.error(
            '[فنش]',
            error
          );

          return ctx.message.reply(
            `❌ تعذر تنفيذ أمر فنش.\n` +
            `السبب: ${
              error?.message || error
            }`
          );
        }
      }
    },

    {
      name: 'نسخ',

      aliases: [
        'نسخة قروب'
      ],

      category: 'إدارة',

      requiredRole: 'developer',

      async execute(ctx) {
        try {
          return await backupGroup(
            ctx,
            (ctx.args || []).join(' ')
          );
        } catch (error) {
          console.error(
            '[نسخ]',
            error
          );

          return ctx.message.reply(
            `❌ تعذر عمل النسخة الاحتياطية.\n` +
            `السبب: ${
              error?.message || error
            }`
          );
        }
      }
    },

    {
      name: 'لصق',

      aliases: [
        'لصق نسخة'
      ],

      category: 'إدارة',

      requiredRole: 'developer',

      async execute(ctx) {
        try {
          return await pasteGroup(
            ctx,
            (ctx.args || []).join(' ')
          );
        } catch (error) {
          console.error(
            '[لصق]',
            error
          );

          return ctx.message.reply(
            `❌ تعذر لصق النسخة.\n` +
            `السبب: ${
              error?.message || error
            }`
          );
        }
      }
    },

    {
      name: 'حذف نسخة',

      aliases: [
        'حذف_نسخة'
      ],

      category: 'إدارة',

      requiredRole: 'developer',

      async execute(ctx) {
        try {
          return await deleteBackup(
            ctx,
            (ctx.args || []).join(' ')
          );
        } catch (error) {
          console.error(
            '[حذف نسخة]',
            error
          );

          return ctx.message.reply(
            `❌ تعذر حذف النسخة.\n` +
            `السبب: ${
              error?.message || error
            }`
          );
        }
      }
    }
  ]
};