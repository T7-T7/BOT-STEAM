export default {
  name: 'xo',
  aliases: ['إكس', 'اكس'],
  category: 'ألعاب',
  requiredRole: 'user',

  async execute(ctx) {
    const { message, sock } = ctx;

    if (!message?.chatId || !sock) return false;

    await message.react?.('🎮');

    const xoHtml = `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
<title>XO ARCADE</title>
<style>
*{box-sizing:border-box; -webkit-tap-highlight-color:transparent; user-select:none; -webkit-touch-callout:none;}
html,body{margin:0; padding:0; width:100%; min-height:100%;}
body{
  font-family:'Courier New', ui-monospace, monospace;
  color:var(--ink);
  background:transparent;
  touch-action:manipulation;
  display:flex;
  justify-content:center;
  align-items:flex-start;
  overflow:hidden;
}

/* ============================================================
   4 ثيمات — عبر data-theme على body
   ============================================================ */
body[data-theme="neon"]{
  --p1:#5ee3ff; --p2:#ff5e9e;
  --glow-p1:rgba(94,227,255,.6); --glow-p2:rgba(255,94,158,.6);
  --bg-top:#0d1220; --bg-bot:#05060a;
  --board-glow:rgba(94,227,255,.08);
  --ink:#e8ecf5; --ink-dim:#7d879e;
  --line:#1c2333;
  --accent:#5ee3ff;
}
body[data-theme="ocean"]{
  --p1:#22D3EE; --p2:#F472B6;
  --glow-p1:rgba(34,211,238,.6); --glow-p2:rgba(244,114,182,.6);
  --bg-top:#073a52; --bg-bot:#02121f;
  --board-glow:rgba(34,211,238,.10);
  --ink:#e8f5fa; --ink-dim:#6a8ba0;
  --line:#123a52;
  --accent:#22D3EE;
}
body[data-theme="sunset"]{
  --p1:#FB923C; --p2:#FCD34D;
  --glow-p1:rgba(251,146,60,.6); --glow-p2:rgba(252,211,77,.6);
  --bg-top:#3a1b0c; --bg-bot:#0f0602;
  --board-glow:rgba(251,146,60,.10);
  --ink:#f5e8d8; --ink-dim:#a0836a;
  --line:#4a2a1a;
  --accent:#FB923C;
}
body[data-theme="forest"]{
  --p1:#34D399; --p2:#FBBF24;
  --glow-p1:rgba(52,211,153,.6); --glow-p2:rgba(251,191,36,.6);
  --bg-top:#0b3a1a; --bg-bot:#03140a;
  --board-glow:rgba(52,211,153,.10);
  --ink:#e0f5e8; --ink-dim:#6a8f7a;
  --line:#143a1a;
  --accent:#34D399;
}

/* ============================================================
   الإطار العام
   ============================================================ */
.wrap{
  width:100%;
  max-width:520px;
  padding:8px;
  display:flex;
  flex-direction:column;
}
.cab{
  position:relative;
  padding:14px;
  background:
    radial-gradient(circle at 50% 0%, var(--board-glow) 0%, transparent 60%),
    linear-gradient(180deg, var(--bg-top), var(--bg-bot));
  border-radius:22px;
  border:1px solid var(--line);
  box-shadow:
    0 0 0 1px rgba(255,255,255,.02) inset,
    0 20px 40px -20px rgba(0,0,0,.9);
  transition:background .5s ease, border-color .4s ease;
}

/* ============================================================
   الهيدر
   ============================================================ */
.top{
  display:flex;
  align-items:center;
  justify-content:space-between;
  padding:2px 4px 10px;
  flex-wrap:wrap;
  gap:8px;
}
.brand{font-size:10px; letter-spacing:3px; color:var(--ink-dim);}
.brand b{color:var(--ink); letter-spacing:1px;}
.score-row{display:flex; align-items:center; gap:14px;}
.score{text-align:center; min-width:40px;}
.score .tag{font-size:9px; letter-spacing:2px; color:var(--ink-dim); margin-bottom:2px;}
.score .num{
  font-size:24px; font-weight:bold; line-height:1;
  font-variant-numeric:tabular-nums;
  transition:transform .15s cubic-bezier(.34,1.56,.64,1);
}
.score.p1 .num{color:var(--p1); text-shadow:0 0 18px var(--glow-p1);}
.score.p2 .num{color:var(--p2); text-shadow:0 0 18px var(--glow-p2);}
.score.bump .num{transform:scale(1.35);}
.divider{color:var(--ink-dim); font-size:16px;}
.mode-badge{
  font-size:9px; letter-spacing:2px; color:var(--ink-dim);
  border:1px solid var(--line); padding:5px 10px; border-radius:20px;
  transition:.3s;
}
.ctrl-btn{
  font-family:inherit; font-size:9px; letter-spacing:2px;
  background:transparent; color:var(--ink-dim); border:1px solid var(--line);
  padding:6px 10px; border-radius:20px; cursor:pointer; transition:.15s ease;
  display:inline-flex; align-items:center; gap:5px;
}
.ctrl-btn:hover{color:var(--ink); border-color:var(--accent);}
.ctrl-btn svg{display:block;}

/* ============================================================
   مؤشر الجولات (5 نقاط)
   ============================================================ */
.rounds{
  display:flex;
  justify-content:center;
  gap:8px;
  padding:0 4px 10px;
}
.round-dot{
  width:9px; height:9px;
  border-radius:50%;
  border:1.5px solid var(--line);
  background:transparent;
  transition:.35s cubic-bezier(.34,1.56,.64,1);
}
.round-dot.win-X{
  background:var(--p1);
  border-color:var(--p1);
  box-shadow:0 0 10px var(--glow-p1);
  transform:scale(1.15);
}
.round-dot.win-O{
  background:var(--p2);
  border-color:var(--p2);
  box-shadow:0 0 10px var(--glow-p2);
  transform:scale(1.15);
}
.round-dot.draw{
  background:var(--ink-dim);
  border-color:var(--ink-dim);
}
.round-dot.current{
  animation:pulse-dot 1.2s ease-in-out infinite;
}
@keyframes pulse-dot{
  0%,100%{transform:scale(1);}
  50%{transform:scale(1.35);}
}

/* ============================================================
   منطقة اللعب
   ============================================================ */
.stage{
  position:relative;
  width:100%;
  aspect-ratio:1;
  max-width:440px;
  margin:0 auto;
}

.board{
  position:absolute;
  inset:0;
  display:grid;
  grid-template-columns:repeat(3, 1fr);
  grid-template-rows:repeat(3, 1fr);
  gap:10px;
  padding:12px;
  border-radius:18px;
  background:rgba(0,0,0,.25);
  border:1px solid var(--line);
}

.cell{
  width:100%;
  height:100%;
  border-radius:14px;
  background:rgba(255,255,255,.025);
  border:1.5px solid rgba(255,255,255,.07);
  display:flex;
  align-items:center;
  justify-content:center;
  font-size:clamp(36px, 12vw, 64px);
  font-weight:900;
  color:var(--ink);
  font-family:inherit;
  cursor:pointer;
  transition:background .15s, border-color .2s, transform .1s, opacity .3s;
  position:relative;
  overflow:hidden;
  padding:0;
  outline:none;
}
.cell:not(:disabled):not(.filled):active{
  transform:scale(.94);
  background:rgba(255,255,255,.06);
  border-color:var(--accent);
}
.cell.x{color:var(--p1); text-shadow:0 0 22px var(--glow-p1);}
.cell.o{color:var(--p2); text-shadow:0 0 22px var(--glow-p2);}
.cell.win{
  background:linear-gradient(180deg, var(--board-glow), rgba(255,255,255,.04));
  border-color:var(--ink);
  box-shadow:0 0 26px var(--board-glow);
}
.cell.filled{ cursor:not-allowed; }
.cell.dim{ opacity:.45; }
.cell.locked{ cursor:not-allowed; }

/* أنيميشن ظهور X/O */
.cell.pop > span{
  display:inline-block;
  animation:pop .35s cubic-bezier(.34,1.56,.64,1);
}
@keyframes pop{
  0%{transform:scale(0) rotate(-90deg); opacity:0;}
  100%{transform:scale(1) rotate(0); opacity:1;}
}

/* خط الفوز */
.win-line{
  position:absolute;
  height:8px;
  background:var(--accent);
  z-index:5;
  display:none;
  top:0; left:0;
  transform-origin:0 50%;
  border-radius:4px;
  box-shadow:0 0 20px var(--accent), 0 0 40px var(--accent);
  pointer-events:none;
  opacity:0;
}
.win-line.show{
  display:block;
  animation:growLine .5s cubic-bezier(.34,1.56,.64,1) forwards;
}
@keyframes growLine{
  0%{transform:scaleX(0) rotate(var(--ang)); opacity:1;}
  100%{transform:scaleX(1) rotate(var(--ang)); opacity:1;}
}

/* ============================================================
   القوائم
   ============================================================ */
.overlay{
  position:absolute;
  inset:0;
  background:rgba(5,6,10,.92);
  backdrop-filter:blur(8px);
  -webkit-backdrop-filter:blur(8px);
  border-radius:18px;
  border:1px solid var(--line);
  display:flex;
  flex-direction:column;
  align-items:center;
  justify-content:center;
  gap:12px;
  padding:20px 16px;
  text-align:center;
  z-index:100;
  animation:fadeIn .25s ease;
  overflow-y:auto;
}
@keyframes fadeIn{from{opacity:0}to{opacity:1}}
.overlay.hide{display:none!important;}

.overlay h1{
  margin:0;
  font-size:clamp(20px,5.5vw,30px);
  letter-spacing:5px;
  color:var(--ink);
  text-shadow:0 0 24px rgba(255,255,255,.15);
  font-family:inherit;
}
.overlay h1 .x{color:var(--p1); text-shadow:0 0 20px var(--glow-p1);}
.overlay h1 .o{color:var(--p2); text-shadow:0 0 20px var(--glow-p2);}
.overlay h1 .sm{font-size:.5em; color:var(--ink-dim); letter-spacing:2px;}
.overlay h2{margin:0; font-size:12px; letter-spacing:3px; color:var(--ink-dim); font-family:inherit;}

.subtitle{
  font-size:10px;
  letter-spacing:2px;
  color:var(--ink-dim);
  display:flex;
  align-items:center;
  gap:6px;
}
.result{
  font-size:13px; letter-spacing:2px; margin-bottom:-2px;
  font-weight:bold;
}
.result.win{color:var(--p1); text-shadow:0 0 16px var(--glow-p1);}
.result.lose{color:var(--p2); text-shadow:0 0 16px var(--glow-p2);}
.result.draw{color:var(--ink-dim);}

.row{display:flex; gap:6px; flex-wrap:wrap; justify-content:center; align-items:center;}
.row .lbl{
  width:100%;
  font-size:9px; letter-spacing:2px; color:var(--ink-dim);
  margin-bottom:2px;
}
.chip{
  font-family:inherit; font-size:10px; letter-spacing:1.5px;
  padding:7px 13px; border-radius:20px;
  background:transparent; color:var(--ink-dim);
  border:1px solid var(--line);
  cursor:pointer; transition:.15s ease;
}
.chip:hover{color:var(--ink); border-color:var(--ink-dim);}
.chip.active{
  color:#0a0d18;
  background:var(--ink);
  border-color:var(--ink);
}

/* بطاقات الثيمات */
.theme-grid{
  display:flex;
  gap:8px;
  flex-wrap:wrap;
  justify-content:center;
  margin:2px 0;
}
.theme-card{
  width:82px;
  padding:6px;
  border-radius:10px;
  cursor:pointer;
  border:1px solid var(--line);
  background:rgba(255,255,255,.02);
  transition:.15s ease;
  display:flex;
  flex-direction:column;
  align-items:center;
  gap:5px;
}
.theme-card:hover{border-color:var(--ink-dim);}
.theme-card.active{
  border-color:var(--accent);
  box-shadow:0 0 16px var(--board-glow);
  background:rgba(255,255,255,.04);
}
.theme-preview{
  width:100%;
  height:36px;
  border-radius:6px;
  overflow:hidden;
  position:relative;
}
.theme-preview::before{
  content:'';
  position:absolute;
  inset:0;
  background:linear-gradient(135deg, var(--prev-p1, #5ee3ff), var(--prev-p2, #ff5e9e));
}
.theme-preview::after{
  content:'';
  position:absolute;
  inset:0;
  background:radial-gradient(circle at 30% 30%, rgba(255,255,255,.25) 0%, transparent 60%);
}
.theme-card .name{
  font-size:9px;
  letter-spacing:1.5px;
  color:var(--ink-dim);
  font-family:inherit;
}
.theme-card.active .name{color:var(--ink);}

/* الأزرار الرئيسية */
.btn{
  margin-top:4px;
  padding:11px 26px;
  font-family:inherit;
  font-size:12px;
  letter-spacing:3px;
  color:#0a0d18;
  background:var(--accent);
  border:none;
  border-radius:10px;
  cursor:pointer;
  box-shadow:0 0 22px var(--board-glow);
  transition:transform .12s ease, box-shadow .2s;
  font-weight:bold;
}
.btn:hover{box-shadow:0 0 30px var(--board-glow);}
.btn:active{transform:scale(.95);}
.btn.ghost{
  background:transparent;
  color:var(--ink-dim);
  border:1px solid var(--line);
  box-shadow:none;
}
.btn.ghost:hover{color:var(--ink); border-color:var(--ink-dim);}
.btn-row{display:flex; gap:8px; flex-wrap:wrap; justify-content:center;}

/* إحصائيات */
.stats{
  display:flex;
  gap:16px;
  margin:6px 0;
  font-size:10px;
  letter-spacing:1.5px;
  color:var(--ink-dim);
}
.stats > div{display:flex; flex-direction:column; align-items:center; gap:2px;}
.stats .v{
  font-size:18px;
  font-weight:bold;
  color:var(--ink);
}

/* ============================================================
   الشريط السفلي
   ============================================================ */
.status{
  display:flex;
  align-items:center;
  justify-content:space-between;
  padding:12px 4px 4px;
  gap:8px;
  flex-wrap:wrap;
}
.turn-indicator{
  display:flex;
  align-items:center;
  gap:6px;
  font-size:10px;
  letter-spacing:2px;
  color:var(--ink-dim);
  padding:6px 12px;
  border-radius:20px;
  border:1px solid var(--line);
  transition:.25s;
  flex:1;
  min-width:120px;
  justify-content:center;
}
.turn-indicator .dot{
  width:7px; height:7px;
  border-radius:50%;
  background:var(--p1);
  box-shadow:0 0 10px var(--glow-p1);
  transition:.25s;
}
.turn-indicator.player{
  color:var(--ink);
  border-color:var(--p1);
  box-shadow:0 0 14px var(--board-glow);
}
.turn-indicator.player .dot{
  background:var(--p1);
  animation:pulseDot 1.2s infinite;
}
.turn-indicator.cpu{
  color:var(--ink);
  border-color:var(--p2);
  box-shadow:0 0 14px var(--board-glow);
}
.turn-indicator.cpu .dot{
  background:var(--p2);
  box-shadow:0 0 10px var(--glow-p2);
  animation:pulseDot 0.8s infinite;
}
@keyframes pulseDot{
  0%,100%{opacity:1; transform:scale(1);}
  50%{opacity:.5; transform:scale(1.3);}
}

.hint-btn{
  font-family:inherit;
  font-size:10px;
  letter-spacing:1.5px;
  padding:7px 11px;
  border-radius:20px;
  background:transparent;
  color:var(--ink-dim);
  border:1px solid var(--line);
  cursor:pointer;
  display:inline-flex;
  align-items:center;
  gap:5px;
  transition:.15s;
}
.hint-btn:hover:not(:disabled){color:var(--accent); border-color:var(--accent);}
.hint-btn:disabled{opacity:.35; cursor:not-allowed;}
.hint-btn svg{display:block;}

.moves{
  font-size:9px;
  letter-spacing:1.5px;
  color:var(--ink-dim);
  text-align:center;
  padding:6px 10px;
  border-radius:20px;
  border:1px solid var(--line);
}
.moves .v{color:var(--ink); font-weight:bold;}

/* جزيئات الاحتفال */
.particle{
  position:absolute;
  width:8px; height:8px;
  border-radius:50%;
  pointer-events:none;
  z-index:50;
}

@media (max-width:480px){
  .cab{padding:10px;}
  .overlay{padding:16px 12px; gap:10px;}
  .overlay h1{font-size:20px; letter-spacing:4px;}
  .theme-card{width:72px;}
  .theme-preview{height:30px;}
  .turn-indicator{font-size:9px; padding:5px 10px; min-width:100px;}
  .hint-btn{font-size:9px; padding:6px 9px;}
  .moves{font-size:8px;}
}
</style>
</head>
<body data-theme="neon">
<div class="wrap">
  <div class="cab">

    <!-- الهيدر -->
    <div class="top">
      <div class="brand">HIURA <b>XO ARCADE</b></div>
      <div class="score-row">
        <div class="score p1" id="scoreBox1">
          <div class="tag">X</div>
          <div class="num" id="s1">0</div>
        </div>
        <div class="divider">:</div>
        <div class="score p2" id="scoreBox2">
          <div class="tag">O</div>
          <div class="num" id="s2">0</div>
        </div>
      </div>
      <div style="display:flex; gap:6px;">
        <button class="ctrl-btn" id="muteBtn" aria-label="صوت">
          <svg id="muteIcon" viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M4 10v4h4l5 4V6l-5 4H4z"/>
            <path d="M16.5 8.5a5 5 0 0 1 0 7"/>
          </svg>
        </button>
        <button class="ctrl-btn" id="exitBtn" aria-label="خروج">
          <svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round">
            <path d="M5 5 L19 19 M19 5 L5 19"/>
          </svg>
          <span>خروج</span>
        </button>
      </div>
    </div>

    <!-- مؤشر الجولات -->
    <div class="rounds" id="rounds">
      <div class="round-dot current" data-r="1"></div>
      <div class="round-dot" data-r="2"></div>
      <div class="round-dot" data-r="3"></div>
      <div class="round-dot" data-r="4"></div>
      <div class="round-dot" data-r="5"></div>
    </div>

    <!-- منطقة اللعب -->
    <div class="stage">

      <div class="board" id="board">
        <button class="cell" data-i="0" type="button"></button>
        <button class="cell" data-i="1" type="button"></button>
        <button class="cell" data-i="2" type="button"></button>
        <button class="cell" data-i="3" type="button"></button>
        <button class="cell" data-i="4" type="button"></button>
        <button class="cell" data-i="5" type="button"></button>
        <button class="cell" data-i="6" type="button"></button>
        <button class="cell" data-i="7" type="button"></button>
        <button class="cell" data-i="8" type="button"></button>
      </div>

      <div class="win-line" id="winLine"></div>

      <!-- قائمة البداية -->
      <div class="overlay" id="menuScreen">
        <h1>X<span class="o">O</span> <span class="sm">ARCADE</span></h1>
        <div class="subtitle">أفضل من 5 جولات · 4 ثيمات · 4 مستويات</div>

        <div class="row">
          <div class="lbl">الصعوبة</div>
          <button class="chip diff-btn" data-d="easy" type="button">سهل</button>
          <button class="chip diff-btn active" data-d="normal" type="button">عادي</button>
          <button class="chip diff-btn" data-d="hard" type="button">صعب</button>
          <button class="chip diff-btn" data-d="insane" type="button">جنوني</button>
        </div>

        <button class="btn" id="toThemeBtn" type="button">التالي: اختر الثيم</button>
      </div>

      <!-- قائمة الثيمات -->
      <div class="overlay hide" id="themeScreen">
        <h2>اختر ثيم اللوح</h2>
        <div class="theme-grid" id="themeGrid"></div>
        <div class="btn-row">
          <button class="btn ghost" id="backToMenuBtn" type="button">رجوع</button>
          <button class="btn" id="startBtn" type="button">ابدأ اللعب</button>
        </div>
      </div>

      <!-- شاشة نهاية المباراة -->
      <div class="overlay hide" id="endScreen">
        <div class="result" id="resultText">فزت!</div>
        <h1 id="endTitle">YOU WIN</h1>
        <div class="stats">
          <div><span class="v" id="statWins">0</span><span>فوز</span></div>
          <div><span class="v" id="statLosses">0</span><span>خسارة</span></div>
          <div><span class="v" id="statDraws">0</span><span>تعادل</span></div>
        </div>
        <div class="btn-row">
          <button class="btn ghost" id="exitToMenuBtn" type="button">القائمة</button>
          <button class="btn" id="restartBtn" type="button">إعادة</button>
        </div>
      </div>

      <!-- شاشة الإيقاف -->
      <div class="overlay hide" id="pauseScreen">
        <h1>PAUSE</h1>
        <div class="btn-row">
          <button class="btn ghost" id="pauseExitBtn" type="button">القائمة</button>
          <button class="btn" id="resumeBtn" type="button">استكمال</button>
        </div>
      </div>
    </div>

    <!-- الشريط السفلي -->
    <div class="status">
      <div class="turn-indicator player" id="turnIndicator">
        <span class="dot"></span>
        <span id="turnText">دورك X</span>
      </div>
      <button class="hint-btn" id="hintBtn" type="button">
        <svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M9 21h6"/>
          <path d="M12 17a5 5 0 0 0-5-5 5 5 0 0 1 10 0 5 5 0 0 0-5 5z"/>
          <line x1="12" y1="2" x2="12" y2="3"/>
        </svg>
        <span id="hintTxt">تلميح (1)</span>
      </button>
      <div class="moves">حركات <span class="v" id="moveCount">0</span></div>
    </div>

  </div>
</div>

<script>
(function(){
'use strict';

/* ============================================================
   المراجع
   ============================================================ */
var boardEl       = document.getElementById('board');
var winLineEl     = document.getElementById('winLine');
var s1El          = document.getElementById('s1');
var s2El          = document.getElementById('s2');
var scoreBox1     = document.getElementById('scoreBox1');
var scoreBox2     = document.getElementById('scoreBox2');
var menuScreen    = document.getElementById('menuScreen');
var themeScreen   = document.getElementById('themeScreen');
var endScreen     = document.getElementById('endScreen');
var pauseScreen   = document.getElementById('pauseScreen');
var themeGrid     = document.getElementById('themeGrid');
var turnIndicator = document.getElementById('turnIndicator');
var turnText      = document.getElementById('turnText');
var hintBtn       = document.getElementById('hintBtn');
var hintTxt       = document.getElementById('hintTxt');
var moveCountEl   = document.getElementById('moveCount');
var roundsEl      = document.getElementById('rounds');
var muteBtn       = document.getElementById('muteBtn');
var muteIcon      = document.getElementById('muteIcon');

/* ============================================================
   الثيمات
   ============================================================ */
var THEMES = [
  { id:'neon',   name:'نيون',  p1:'#5ee3ff', p2:'#ff5e9e' },
  { id:'ocean',  name:'محيط',  p1:'#22D3EE', p2:'#F472B6' },
  { id:'sunset', name:'غروب',  p1:'#FB923C', p2:'#FCD34D' },
  { id:'forest', name:'غابة',  p1:'#34D399', p2:'#FBBF24' }
];
var currentTheme = 'neon';

/* ============================================================
   الحالة
   ============================================================ */
var LINES = [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
var ORDER = [4,0,2,6,8,1,3,5,7];
var WIN_TARGET = 3;   /* أول من 3 جولات من أصل 5 */
var AI_DELAY = 480;

var board = ['','','','','','','','',''];
var score1 = 0, score2 = 0;
var roundWins = [];   /* مصفوفة نتائج الجولات السابقة: 'X' | 'O' | 'draw' */
var phase = 'idle';
var moveId = 0;
var lastTap = 0;
var moveCount = 0;
var hintUsed = false;
var difficulty = 'normal';
var running = false;
var paused = false;

/* ============================================================
   الصوت
   ============================================================ */
var audioCtx = null, muted = false;
var ICON_ON  = '<svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 10v4h4l5 4V6l-5 4H4z"/><path d="M16.5 8.5a5 5 0 0 1 0 7"/><path d="M19 6a8.5 8.5 0 0 1 0 12"/></svg>';
var ICON_OFF = '<svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 10v4h4l5 4V6l-5 4H4z"/><path d="M16 9l5 6M21 9l-5 6"/></svg>';
muteIcon.outerHTML = ICON_ON;

function ensureAudio(){
  if(!audioCtx){
    try{ audioCtx = new (window.AudioContext || window.webkitAudioContext)(); }catch(e){}
  } else if(audioCtx.state === 'suspended'){
    try{ audioCtx.resume(); }catch(e){}
  }
}
function tone(freq, dur, type, gain, glideTo){
  if(!audioCtx || muted) return;
  try{
    var o = audioCtx.createOscillator();
    var g = audioCtx.createGain();
    o.type = type || 'square';
    o.frequency.value = freq;
    if(glideTo) o.frequency.exponentialRampToValueAtTime(glideTo, audioCtx.currentTime + dur);
    g.gain.value = gain || 0.05;
    o.connect(g); g.connect(audioCtx.destination);
    var now = audioCtx.currentTime;
    g.gain.setValueAtTime(g.gain.value, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + dur);
    o.start(now); o.stop(now + dur);
  }catch(e){}
}
var sfx = {
  x: function(){ tone(720, 0.09, 'square', 0.07); },
  o: function(){ tone(460, 0.09, 'square', 0.07); },
  tick: function(){ tone(800, 0.04, 'sine', 0.04); },
  win: function(){ tone(660,0.1,'square',0.06); setTimeout(function(){tone(880,0.14,'square',0.06);},110); setTimeout(function(){tone(1100,0.2,'square',0.06);},240); },
  lose: function(){ tone(280,0.16,'sawtooth',0.05,140); setTimeout(function(){tone(180,0.3,'sawtooth',0.05,90);},160); },
  draw: function(){ tone(400,0.12,'triangle',0.05); setTimeout(function(){tone(320,0.15,'triangle',0.05);},130); },
  click: function(){ tone(520, 0.03, 'square', 0.03); },
  matchWin: function(){ tone(523,0.15,'square',0.07); setTimeout(function(){tone(659,0.15,'square',0.07);},150); setTimeout(function(){tone(784,0.15,'square',0.07);},300); setTimeout(function(){tone(1047,0.3,'square',0.07);},450); },
  matchLose: function(){ tone(440,0.2,'sawtooth',0.06,220); setTimeout(function(){tone(330,0.3,'sawtooth',0.06,165);},220); setTimeout(function(){tone(220,0.4,'sawtooth',0.06,110);},500); }
};

/* ============================================================
   ★★★ منطق اللعبة ★★★
   ============================================================ */
function checkWin(b){
  for(var i = 0; i < LINES.length; i++){
    var l = LINES[i];
    if(b[l[0]] && b[l[0]] === b[l[1]] && b[l[0]] === b[l[2]]){
      return { w: b[l[0]], line: l };
    }
  }
  for(var k = 0; k < 9; k++){ if(!b[k]) return null; }
  return { w: 'draw', line: [] };
}

function minimax(b, depth, isMax, alpha, beta, ai, hu){
  var r = checkWin(b);
  if(r){
    if(r.w === ai) return 10 - depth;
    if(r.w === hu) return depth - 10;
    return 0;
  }
  var i, v;
  if(isMax){
    var max = -1000;
    for(var k = 0; k < ORDER.length; k++){
      i = ORDER[k];
      if(!b[i]){
        b[i] = ai;
        v = minimax(b, depth+1, false, alpha, beta, ai, hu);
        b[i] = '';
        if(v > max) max = v;
        if(v > alpha) alpha = v;
        if(beta <= alpha) break;
      }
    }
    return max;
  } else {
    var min = 1000;
    for(var k2 = 0; k2 < ORDER.length; k2++){
      i = ORDER[k2];
      if(!b[i]){
        b[i] = hu;
        v = minimax(b, depth+1, true, alpha, beta, ai, hu);
        b[i] = '';
        if(v < min) min = v;
        if(v < beta) beta = v;
        if(beta <= alpha) break;
      }
    }
    return min;
  }
}

function findBest(b, ai, hu){
  var bestScore = -1000, mv = null;
  for(var k = 0; k < ORDER.length; k++){
    var i = ORDER[k];
    if(!b[i]){
      b[i] = ai;
      var sc = minimax(b, 0, false, -1000, 1000, ai, hu);
      b[i] = '';
      if(sc > bestScore){ bestScore = sc; mv = i; }
    }
  }
  return mv;
}

function winMove(b, p){
  for(var k = 0; k < ORDER.length; k++){
    var i = ORDER[k];
    if(!b[i]){
      b[i] = p;
      var r = checkWin(b);
      b[i] = '';
      if(r && r.w === p) return i;
    }
  }
  return null;
}

function pickAiMove(){
  var moves = [];
  for(var k = 0; k < ORDER.length; k++){
    var i = ORDER[k];
    if(!board[i]) moves.push(i);
  }
  if(!moves.length) return null;

  if(difficulty === 'easy'){
    return moves[Math.floor(Math.random() * moves.length)];
  }
  var w = winMove(board, 'O');
  if(w !== null) return w;
  var bl = winMove(board, 'X');
  if(bl !== null) return bl;
  if(difficulty === 'normal' && Math.random() < 0.45){
    return moves[Math.floor(Math.random() * moves.length)];
  }
  if(difficulty === 'hard' && Math.random() < 0.12){
    return moves[Math.floor(Math.random() * moves.length)];
  }
  return findBest(board.slice(), 'O', 'X');
}

/* ============================================================
   الرسم
   ============================================================ */
function renderCell(i){
  var el = boardEl.children[i];
  if(!el) return;
  var val = board[i];
  el.textContent = val;
  el.className = 'cell';
  if(val) el.classList.add(val.toLowerCase(), 'filled');
  if(!running || phase !== 'player') el.classList.add('locked');
}

function renderAll(){
  for(var i = 0; i < 9; i++) renderCell(i);
  moveCountEl.textContent = moveCount;
}

function bumpScore(which){
  var box = which === 1 ? scoreBox1 : scoreBox2;
  box.classList.remove('bump');
  void box.offsetWidth;
  box.classList.add('bump');
  setTimeout(function(){ box.classList.remove('bump'); }, 220);
}

function updateTurnIndicator(){
  turnIndicator.classList.remove('player', 'cpu');
  if(phase === 'player'){
    turnIndicator.classList.add('player');
    turnText.textContent = 'دورك X';
  } else if(phase === 'thinking'){
    turnIndicator.classList.add('cpu');
    turnText.textContent = 'CPU يفكر...';
  } else if(phase === 'ended'){
    turnText.textContent = 'انتهت الجولة';
  } else {
    turnText.textContent = 'استعد';
  }
}

function renderRounds(){
  var dots = roundsEl.querySelectorAll('.round-dot');
  for(var i = 0; i < dots.length; i++){
    dots[i].className = 'round-dot';
    if(i < roundWins.length){
      if(roundWins[i] === 'X') dots[i].classList.add('win-X');
      else if(roundWins[i] === 'O') dots[i].classList.add('win-O');
      else dots[i].classList.add('draw');
    } else if(i === roundWins.length && running){
      dots[i].classList.add('current');
    }
  }
}

/* ============================================================
   خط الفوز
   ============================================================ */
function showWinLine(line, winner){
  if(!line || line.length !== 3) return;
  var a = boardEl.children[line[0]].getBoundingClientRect();
  var b = boardEl.children[line[2]].getBoundingClientRect();
  var boardRect = boardEl.getBoundingClientRect();
  var ax = a.left + a.width/2 - boardRect.left;
  var ay = a.top + a.height/2 - boardRect.top;
  var bx = b.left + b.width/2 - boardRect.left;
  var by = b.top + b.height/2 - boardRect.top;
  var dx = bx - ax, dy = by - ay;
  var len = Math.sqrt(dx*dx + dy*dy);
  var ang = Math.atan2(dy, dx) * 180 / Math.PI;

  winLineEl.style.left = ax + 'px';
  winLineEl.style.top = ay + 'px';
  winLineEl.style.width = len + 'px';
  winLineEl.style.setProperty('--ang', ang + 'deg');
  winLineEl.style.transformOrigin = '0 50%';
  winLineEl.style.background = winner === 'X' ? 'var(--p1)' : 'var(--p2)';
  winLineEl.style.boxShadow = '0 0 20px ' + (winner === 'X' ? 'var(--glow-p1)' : 'var(--glow-p2)');

  winLineEl.classList.remove('show');
  void winLineEl.offsetWidth;
  winLineEl.classList.add('show');
}
function hideWinLine(){
  winLineEl.classList.remove('show');
  winLineEl.style.display = 'none';
  setTimeout(function(){ winLineEl.style.display = ''; }, 30);
}

/* ============================================================
   الجزيئات
   ============================================================ */
function spawnParticles(count, color){
  var boardRect = boardEl.getBoundingClientRect();
  var cx = boardRect.width / 2;
  var cy = boardRect.height / 2;
  for(var i = 0; i < count; i++){
    (function(){
      var p = document.createElement('div');
      p.className = 'particle';
      p.style.background = color;
      p.style.boxShadow = '0 0 12px ' + color;
      p.style.left = cx + 'px';
      p.style.top = cy + 'px';
      boardEl.appendChild(p);

      var ang = Math.random() * Math.PI * 2;
      var dist = 60 + Math.random() * 140;
      var dx = Math.cos(ang) * dist;
      var dy = Math.sin(ang) * dist;

      setTimeout(function(){
        p.style.transition = 'transform .9s cubic-bezier(.22,.9,.3,1), opacity .9s';
        p.style.transform = 'translate(' + dx + 'px, ' + dy + 'px) scale(0)';
        p.style.opacity = '0';
      }, 10);

      setTimeout(function(){
        if(p.parentNode) p.parentNode.removeChild(p);
      }, 1000);
    })();
  }
}

/* ============================================================
   ★★★ دالة اللعب — القفل الذكي ★★★
   ============================================================ */
function tryPlay(idx){
  /* حماية 1: الحالة */
  if(phase !== 'player') return false;
  if(!running || paused) return false;

  /* حماية 2: cooldown بسيط */
  var now = Date.now();
  if(now - lastTap < 80) return false;

  /* حماية 3: الخلية */
  if(idx < 0 || idx > 8) return false;
  if(board[idx]) return false;

  /* ★ قبول ★ */
  lastTap = now;
  var myMoveId = ++moveId;
  phase = 'thinking';
  updateTurnIndicator();

  board[idx] = 'X';
  moveCount++;
  renderCell(idx);
  renderAll();
  sfx.x();

  var afterPlayer = checkWin(board);
  if(afterPlayer){
    setTimeout(function(){ endRound(afterPlayer); }, 250);
    return true;
  }

  /* جدولة حركة الـ AI */
  setTimeout(function(){
    if(myMoveId !== moveId) return;
    if(phase !== 'thinking') return;

    var mv = pickAiMove();
    if(mv === null){
      phase = 'player';
      updateTurnIndicator();
      renderAll();
      return;
    }

    board[mv] = 'O';
    moveCount++;
    renderCell(mv);
    renderAll();
    sfx.o();

    var afterAi = checkWin(board);
    if(afterAi){
      setTimeout(function(){ endRound(afterAi); }, 250);
      return;
    }

    /* ★★ فتح الدور ★★ */
    phase = 'player';
    updateTurnIndicator();
    renderAll();

  }, AI_DELAY);

  return true;
}

/* ============================================================
   نهاية الجولة
   ============================================================ */
function endRound(r){
  phase = 'ended';
  moveId++;
  updateTurnIndicator();

  if(r.w === 'X'){
    score1++;
    s1El.textContent = score1;
    bumpScore(1);
    roundWins.push('X');
    if(r.line.length === 3) showWinLine(r.line, 'X');
    setTimeout(function(){ spawnParticles(30, getComputedStyle(document.body).getPropertyValue('--p1').trim()); }, 120);
    sfx.win();
  } else if(r.w === 'O'){
    score2++;
    s2El.textContent = score2;
    bumpScore(2);
    roundWins.push('O');
    if(r.line.length === 3) showWinLine(r.line, 'O');
    setTimeout(function(){ spawnParticles(30, getComputedStyle(document.body).getPropertyValue('--p2').trim()); }, 120);
    sfx.lose();
  } else {
    roundWins.push('draw');
    sfx.draw();
  }
  renderRounds();

  /* فحص نهاية المباراة */
  if(score1 >= WIN_TARGET || score2 >= WIN_TARGET || roundWins.length >= 5){
    setTimeout(endMatch, 1200);
    return;
  }

  /* جولة جديدة */
  setTimeout(function(){
    if(phase !== 'ended') return;
    resetBoard();
    phase = 'player';
    updateTurnIndicator();
    renderAll();
    renderRounds();
    hintUsed = false;
    hintTxt.textContent = 'تلميح (1)';
    hintBtn.disabled = false;
    hideWinLine();
  }, 1400);
}

function resetBoard(){
  board = ['','','','','','','','',''];
  moveCount = 0;
  moveId++;
}

function endMatch(){
  var playerWon = score1 > score2;
  var drew = score1 === score2;
  resultText.textContent = playerWon ? 'انتصار' : (drew ? 'تعادل' : 'خسارة');
  resultText.className = 'result ' + (playerWon ? 'win' : (drew ? 'draw' : 'lose'));
  endTitle.textContent = playerWon ? 'YOU WIN' : (drew ? 'DRAW' : 'GAME OVER');
  document.getElementById('statWins').textContent = score1;
  document.getElementById('statLosses').textContent = score2;
  document.getElementById('statDraws').textContent = roundWins.filter(function(x){return x==='draw';}).length;
  endScreen.classList.remove('hide');
  running = false;

  if(playerWon){
    sfx.matchWin();
    spawnParticles(60, getComputedStyle(document.body).getPropertyValue('--p1').trim());
    setTimeout(function(){ spawnParticles(60, getComputedStyle(document.body).getPropertyValue('--p2').trim()); }, 300);
  } else if(!drew){
    sfx.matchLose();
  }
}

/* ============================================================
   بدء / إعادة / قائمة
   ============================================================ */
function startMatch(){
  ensureAudio();
  score1 = 0; score2 = 0;
  s1El.textContent = 0;
  s2El.textContent = 0;
  roundWins = [];
  resetBoard();
  hintUsed = false;
  hintTxt.textContent = 'تلميح (1)';
  hintBtn.disabled = false;
  hideWinLine();
  renderAll();
  renderRounds();
  phase = 'player';
  running = true;
  paused = false;
  updateTurnIndicator();
  var labels = { easy:'سهل', normal:'عادي', hard:'صعب', insane:'جنوني' };
  document.getElementById('modeBadge') /* just to be safe */;
  themeScreen.classList.add('hide');
  endScreen.classList.add('hide');
  pauseScreen.classList.add('hide');
}

function goMenu(){
  sfx.click();
  running = false;
  paused = false;
  phase = 'idle';
  moveId++;
  endScreen.classList.add('hide');
  pauseScreen.classList.add('hide');
  themeScreen.classList.add('hide');
  menuScreen.classList.remove('hide');
  hideWinLine();
}

function togglePause(){
  if(!running) return;
  paused = !paused;
  pauseScreen.classList.toggle('hide', !paused);
}

/* ============================================================
   التلميح
   ============================================================ */
function doHint(){
  if(hintUsed) return;
  if(phase !== 'player') return;
  if(!running || paused) return;
  var mv = findBest(board.slice(), 'X', 'O');
  if(mv === null) return;
  hintUsed = true;
  hintTxt.textContent = 'تلميح (0)';
  hintBtn.disabled = true;
  var el = boardEl.children[mv];
  if(el){
    el.style.borderColor = getComputedStyle(document.body).getPropertyValue('--p1').trim();
    el.style.boxShadow = '0 0 20px ' + getComputedStyle(document.body).getPropertyValue('--p1').trim();
    setTimeout(function(){
      el.style.borderColor = '';
      el.style.boxShadow = '';
    }, 1200);
  }
}

/* ============================================================
   ★★★ المستمع الوحيد — delegation على البورد ★★★
   ============================================================
   نستخدم pointerdown + click معًا:
   - pointerdown: الأسرع (يشتغل فورًا على اللمس)
   - click: fallback مضمون في كل البيئات
   - الـ phase يحمينا من التكرار (لو pointerdown قبل click
     على نفس اللمسة، الثاني هيلاقي phase مش 'player' فيرفض)
   ============================================================ */
function handleBoardEvent(e){
  /* تجاهل لو في overlay مفتوح */
  if(!menuScreen.classList.contains('hide') ||
     !themeScreen.classList.contains('hide') ||
     !endScreen.classList.contains('hide') ||
     !pauseScreen.classList.contains('hide')){
    return;
  }

  var target = e.target;
  while(target && target !== boardEl){
    if(target.classList && target.classList.contains('cell')){
      var idx = parseInt(target.getAttribute('data-i'), 10);
      if(!isNaN(idx)){
        tryPlay(idx);
        /* نمنع السلوك الافتراضي وانتشار الحدث */
        if(e.preventDefault) e.preventDefault();
        if(e.stopPropagation) e.stopPropagation();
        if(e.stopImmediatePropagation) e.stopImmediatePropagation();
      }
      return;
    }
    target = target.parentNode;
  }
}

boardEl.addEventListener('pointerdown', handleBoardEvent, true);
boardEl.addEventListener('touchstart', handleBoardEvent, { capture: true, passive: false });
boardEl.addEventListener('mousedown', handleBoardEvent, true);
boardEl.addEventListener('click', handleBoardEvent, true);

/* ============================================================
   بناء الثيمات
   ============================================================ */
function buildThemes(){
  THEMES.forEach(function(t){
    var card = document.createElement('div');
    card.className = 'theme-card' + (t.id === currentTheme ? ' active' : '');
    card.setAttribute('data-theme-id', t.id);
    card.style.setProperty('--prev-p1', t.p1);
    card.style.setProperty('--prev-p2', t.p2);

    var prev = document.createElement('div');
    prev.className = 'theme-preview';
    card.appendChild(prev);

    var name = document.createElement('div');
    name.className = 'name';
    name.textContent = t.name;
    card.appendChild(name);

    card.addEventListener('click', function(){
      currentTheme = t.id;
      document.body.setAttribute('data-theme', t.id);
      var cards = themeGrid.querySelectorAll('.theme-card');
      for(var i = 0; i < cards.length; i++) cards[i].classList.remove('active');
      card.classList.add('active');
      sfx.click();
    });

    themeGrid.appendChild(card);
  });
}

/* ============================================================
   ربط الأزرار
   ============================================================ */
document.getElementById('toThemeBtn').addEventListener('click', function(){
  sfx.click();
  menuScreen.classList.add('hide');
  themeScreen.classList.remove('hide');
});
document.getElementById('backToMenuBtn').addEventListener('click', function(){
  sfx.click();
  themeScreen.classList.add('hide');
  menuScreen.classList.remove('hide');
});
document.getElementById('startBtn').addEventListener('click', function(){
  sfx.click();
  startMatch();
});
document.getElementById('restartBtn').addEventListener('click', function(){
  sfx.click();
  endScreen.classList.add('hide');
  startMatch();
});
document.getElementById('resumeBtn').addEventListener('click', function(){
  sfx.click();
  togglePause();
});
document.getElementById('exitBtn').addEventListener('click', goMenu);
document.getElementById('exitToMenuBtn').addEventListener('click', goMenu);
document.getElementById('pauseExitBtn').addEventListener('click', goMenu);
hintBtn.addEventListener('click', doHint);
muteBtn.addEventListener('click', function(){
  muted = !muted;
  muteIcon.outerHTML = muted ? ICON_OFF : ICON_ON;
});

/* اختيار الصعوبة */
var diffBtns = document.querySelectorAll('.diff-btn');
for(var i = 0; i < diffBtns.length; i++){
  (function(btn){
    btn.addEventListener('click', function(){
      difficulty = btn.getAttribute('data-d');
      for(var k = 0; k < diffBtns.length; k++) diffBtns[k].classList.remove('active');
      btn.classList.add('active');
      sfx.click();
    });
  })(diffBtns[i]);
}

/* مفاتيح الكيبورد */
window.addEventListener('keydown', function(e){
  if(e.code === 'Space'){ e.preventDefault(); if(running) togglePause(); }
  if(e.code === 'Escape'){ if(running) goMenu(); }
});

/* منع الزووم المزدوج */
document.addEventListener('gesturestart', function(e){ e.preventDefault(); });

/* ============================================================
   التهيئة
   ============================================================ */
buildThemes();
renderAll();
renderRounds();
updateTurnIndicator();

})();
</script>
</body>
</html>`;

    const unifiedResponse = {
      response_id: '2e139bcf-de37-4fad-a30c-01524776e17a',
      sections: [
        {
          __typename: 'GenAIUnifiedResponseSection',
          view_model: {
            __typename: 'GenAISingleLayoutViewModel',
            primitive: {
              __typename: 'GenAIaeacdsnwHtmlPrimitive',
              payload: xoHtml,
              trusted_sources: ['nixel.dev', 'kangwifi.eu.org']
            }
          }
        }
      ],
      embedded_screens: [
        {
          id: 'steam-xo-arcade',
          title: 'اللعبة',
          content: [
            {
              __typename: 'FOAEmbeddedScreenContentTabbed',
              tabs: [
                {
                  id: 'xo-game',
                  tab_header: 'اللعبة',
                  sections: [
                    {
                      __typename: 'GenAIUnifiedResponseSection',
                      view_model: {
                        __typename: 'GenAISingleLayoutViewModel',
                        primitive: {
                          __typename: 'GenAIaeacdsnwHtmlPrimitive',
                          payload: xoHtml,
                          trusted_sources: ['nixel.dev', 'kangwifi.eu.org']
                        }
                      }
                    }
                  ]
                }
              ]
            }
          ]
        }
      ]
    };

    try {
      await sock.relayMessage(
        message.chatId,
        {
          senderKeyDistributionMessage: {
            groupId: message.chatId,
            axolotlSenderKeyDistributionMessage: '[STRIPPED 108 bytes]'
          },
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2,
            botMetadata: {
              messageDisclaimerText: '',
              botResponseId: '90ab3989-9597-4bde-9593-4786925f1c97',
              verificationMetadata: {
                proofs: [
                  {
                    version: 1,
                    useCase: 1,
                    signature: '[STRIPPED 88 bytes]',
                    certificateChain: [
                      '[STRIPPED 912 bytes]',
                      '[STRIPPED 1192 bytes]'
                    ]
                  }
                ]
              }
            }
          },
          botForwardedMessage: {
            message: {
              richResponseMessage: {
                messageType: 1,
                submessages: [
                  {
                    messageType: 2,
                    messageText: '❌⭕ XO ARCADE — أفضل من 5'
                  }
                ],
                unifiedResponse: {
                  data: Buffer.from(JSON.stringify(unifiedResponse)).toString('base64')
                },
                contextInfo: {
                  forwardingScore: 1,
                  isForwarded: true,
                  forwardedAiBotMessageInfo: {
                    botJid: '867051314767696@bot'
                  },
                  forwardOrigin: 4
                }
              }
            }
          }
        },
        {
          additionalNodes: [
            {
              tag: 'biz',
              attrs: {
                actual_actors: '2',
                host_storage: '2',
                privacy_mode_ts: '1788095961'
              },
              content: [
                {
                  tag: 'interactive',
                  attrs: {
                    type: 'native_flow',
                    v: '1'
                  },
                  content: [
                    {
                      tag: 'native_flow',
                      attrs: {
                        v: '9',
                        name: 'mixed'
                      }
                    }
                  ]
                }
              ]
            }
          ]
        }
      );

      return true;
    } catch (error) {
      console.error('[STEAM XO] HTML window failed:', error);
      try {
        return await message.reply(
          '❌ تعذر إرسال نافذة XO.\n' +
          'السبب: ' + (error?.message || error)
        );
      } catch {
        return false;
      }
    }
  }
};