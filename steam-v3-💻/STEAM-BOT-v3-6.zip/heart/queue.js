const chains = new Map();

export function runSerial(key, task) {
  const previous = chains.get(key) || Promise.resolve();
  const next = previous.catch(() => {}).then(task);

  const tracked = next.then(
    () => { if (chains.get(key) === tracked) chains.delete(key); },
    () => { if (chains.get(key) === tracked) chains.delete(key); }
  );

  chains.set(key, tracked);
  return next;
}

export function clearSerial(key) {
  if (key == null) return;
  chains.delete(key);
}
