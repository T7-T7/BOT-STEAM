import {
  execFile
} from 'child_process';

import {
  promisify
} from 'util';

import fs from 'fs/promises';
import os from 'os';
import path from 'path';

import dns from 'dns/promises';
import net from 'net';

import config from '../config.js';

const exec =
  promisify(execFile);

const HIDENFREE =
  'https://2b.hidenfree.com';

const ENGEZ =
  'https://engez.a7a.online/api/v1';

let INVIDIOUS = [
  'https://inv.nadeko.net',
  'https://invidious.nerdvpn.de',
  'https://yt.chocolatemoo53.com',
  'https://invidious.tiekoetter.com'
];

let PIPED = [
  'https://pipedapi.kavin.rocks',
  'https://pipedapi.tokhmi.xyz',
  'https://pipedapi.moomoo.me',
  'https://pipedapi.syncpundit.io',
  'https://api-piped.mha.fi'
];

let instanceRefreshAt = 0;

/*
 * =========================
 * CONTENT FILTER
 * =========================
 */

const blocked = [
  /اغنيه|اغنية|أغنية|اغاني|أغاني|موسيقى|موسيق|music|song|songs|remix|ريمكس|راب|rap/i,

  /كليب|clip|حفله|حفلة|concert|dj|lyrics|lyric/i,

  /البوم|ألبوم|album|سينجل|single|مطرب|مطربة|مغني|مغنية/i,

  /كلمات\s*(الأغنية|اغنيه|أغنية)/i
];

export function forbidden(text) {
  return blocked.some(
    regex =>
      regex.test(
        String(text || '')
      )
  );
}

/*
 * =========================
 * BASIC HELPERS
 * =========================
 */

function clean(value) {
  return String(value || '')
    .replace(/\s+/g, ' ')
    .trim();
}

function timeoutSignal(ms) {
  return AbortSignal.timeout(
    Math.max(
      1000,
      Number(ms) || 10000
    )
  );
}

async function requestText(
  url,
  params = {},
  timeout = 10000
) {
  const u =
    new URL(url);

  for (
    const [key, value]
      of Object.entries(params)
  ) {
    if (
      value !== undefined &&
      value !== null
    ) {
      u.searchParams.set(
        key,
        String(value)
      );
    }
  }

  const response =
    await fetch(u, {
      headers: {
        accept:
          'application/json,text/plain,*/*',

        'user-agent':
          'STEAM-BOT/4.0'
      },

      signal:
        timeoutSignal(timeout)
    });

  const text =
    await response.text();

  if (!response.ok) {
    throw new Error(
      `HTTP ${response.status}`
    );
  }

  return text;
}

async function getJson(
  url,
  params = {},
  timeout = 10000
) {
  const text =
    await requestText(
      url,
      params,
      timeout
    );

  if (
    /^\s*<!doctype\s+html/i.test(text) ||
    /^\s*<html/i.test(text)
  ) {
    throw new Error(
      'الخادم أعاد HTML بدل JSON'
    );
  }

  try {
    return JSON.parse(text);
  } catch {
    throw new Error(
      `استجابة JSON غير صالحة: ${text.slice(0, 120)}`
    );
  }
}

/*
 * =========================
 * INSTANCE REFRESH
 * =========================
 */

async function refreshInstances() {
  if (
    Date.now() <
    instanceRefreshAt
  ) {
    return;
  }

  instanceRefreshAt =
    Date.now() +
    6 * 60 * 60 * 1000;

  const tasks = [
    (async () => {
      try {
        const data =
          await getJson(
            'https://api.invidious.io/instances.json',
            {},
            7000
          );

        const list =
          Object.entries(
            data || {}
          )
            .filter(
              ([, meta]) =>
                meta?.api &&
                meta?.type ===
                  'https'
            )
            .map(
              ([host]) =>
                `https://${host}`
            );

        if (list.length) {
          INVIDIOUS = [
            ...new Set([
              ...list,
              ...INVIDIOUS
            ])
          ].slice(0, 12);
        }
      } catch {}
    })(),

    (async () => {
      try {
        const text =
          await requestText(
            'https://raw.githubusercontent.com/TeamPiped/Piped/main/.github/instances.json',
            {},
            7000
          );

        const data =
          JSON.parse(text);

        const list =
          (
            Array.isArray(data)
              ? data
              : []
          )
            .map(
              x =>
                x.api_url ||
                x.apiUrl ||
                x.api
            )
            .filter(
              x =>
                /^https:\/\//i.test(
                  x || ''
                )
            );

        if (list.length) {
          PIPED = [
            ...new Set([
              ...list,
              ...PIPED
            ])
          ].slice(0, 15);
        }
      } catch {}
    })()
  ];

  await Promise.allSettled(
    tasks
  );
}

/*
 * =========================
 * DURATION
 * =========================
 */

function parseDuration(value) {
  if (
    Number.isFinite(
      Number(value)
    )
  ) {
    return Number(value);
  }

  const text =
    String(value || '')
      .trim();

  if (!text) {
    return null;
  }

  const sec =
    text.match(
      /^(\d+(?:\.\d+)?)\s*(?:ث|ثانيه|ثانية|ثواني|sec|secs|second|seconds)$/iu
    );

  if (sec) {
    return Number(sec[1]);
  }

  const min =
    text.match(
      /^(\d+(?:\.\d+)?)\s*(?:د|دقيقه|دقيقة|دقائق|min|mins|minute|minutes)$/iu
    );

  if (min) {
    return (
      Number(min[1]) *
      60
    );
  }

  const parts =
    text
      .split(':')
      .map(Number);

  if (
    parts.some(
      x =>
        !Number.isFinite(x)
    )
  ) {
    return null;
  }

  if (
    parts.length === 3
  ) {
    return (
      parts[0] * 3600 +
      parts[1] * 60 +
      parts[2]
    );
  }

  if (
    parts.length === 2
  ) {
    return (
      parts[0] * 60 +
      parts[1]
    );
  }

  return null;
}

function formatDuration(
  seconds
) {
  const n =
    Number(seconds);

  if (
    !Number.isFinite(n) ||
    n < 0
  ) {
    return '?';
  }

  const h =
    Math.floor(
      n / 3600
    );

  const m =
    Math.floor(
      (n % 3600) / 60
    );

  const s =
    Math.floor(n % 60);

  return h
    ? `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`
    : `${m}:${String(s).padStart(2, '0')}`;
}

export function parseDurationIntent(
  input
) {
  const text =
    clean(input);

  const patterns = [
    /(?:مدته|مدت|مده)\s*(\d+)\s*(?:ثانية|ثواني|ثانيه|ث|دقيقة|دقائق|دقيقه|د)/iu,

    /(\d+)\s*(?:ثانية|ثواني|ثانيه|ث|دقيقة|دقائق|دقيقه|د)/iu
  ];

  for (
    const regex of patterns
  ) {
    const match =
      text.match(regex);

    if (!match) {
      continue;
    }

    const n =
      Number(match[1]);

    if (
      !Number.isFinite(n) ||
      n <= 0
    ) {
      continue;
    }

    const matched =
      match[0];

    const seconds =
      /دقيقة|دقائق|دقيقه|\bد\b/u.test(
        matched
      )
        ? n * 60
        : n;

    return {
      seconds,

      query:
        clean(
          text.replace(
            matched,
            ' '
          )
        )
    };
  }

  return {
    seconds: null,
    query: text
  };
}

/*
 * =========================
 * RESULT NORMALIZATION
 * =========================
 */

function normalizeResult(v) {
  const title =
    clean(
      v.title ||
      v.name
    );

  const channel =
    clean(
      v.channel ||
      v.author ||
      v.uploaderName ||
      v.uploader
    );

  const url =
    v.url ||
    v.webpage_url ||
    (
      v.videoId
        ? `https://www.youtube.com/watch?v=${v.videoId}`
        : v.id
          ? `https://www.youtube.com/watch?v=${v.id}`
          : ''
    );

  const durationSeconds =
    parseDuration(
      v.durationSeconds ??
      v.lengthSeconds ??
      v.duration ??
      v.duration_string
    );

  const thumbnail =
    v.thumbnail ||
    v.image ||
    v.thumb ||
    v.videoThumbnails?.[0]?.url ||
    '';

  return {
    title,

    channel:
      channel ||
      'غير معروف',

    url,

    thumbnail,

    durationSeconds,

    duration_string:
      durationSeconds == null
        ? (
            v.duration_string ||
            '?'
          )
        : formatDuration(
            durationSeconds
          )
  };
}

function filterResults(rows) {
  return (
    Array.isArray(rows)
      ? rows
      : []
  )
    .map(normalizeResult)
    .filter(
      item =>
        item.title &&
        item.url &&
        !forbidden(
          `${item.title} ${item.channel}`
        )
    );
}

/*
 * =========================
 * SEARCH PROVIDERS
 * =========================
 */

async function engezSearch(
  query,
  limit
) {
  const d =
    await getJson(
      `${ENGEZ}/search/youtube`,
      {
        q: query
      },
      10000
    );

  return filterResults(
    (
      d.results || []
    ).slice(
      0,
      Math.max(
        limit,
        8
      )
    )
  ).slice(
    0,
    limit
  );
}

async function hidenfreeSearch(
  query,
  limit
) {
  const d =
    await getJson(
      `${HIDENFREE}/api/youtube/search`,
      {
        q: query,
        limit
      },
      9000
    );

  return filterResults(
    d.results || []
  ).slice(
    0,
    limit
  );
}

async function invidiousSearch(
  query,
  limit
) {
  await refreshInstances();

  const attempts =
    INVIDIOUS
      .slice(0, 6)
      .map(
        async base => {
          const d =
            await getJson(
              `${base}/api/v1/search`,
              {
                q: query,
                type: 'video',
                page: 1,
                sort_by: 'relevance'
              },
              7000
            );

          const rows =
            (
              Array.isArray(d)
                ? d
                : []
            )
              .filter(
                v =>
                  v.type ===
                  'video'
              )
              .map(v => ({
                title: v.title,

                author:
                  v.author,

                videoId:
                  v.videoId,

                lengthSeconds:
                  v.lengthSeconds,

                videoThumbnails:
                  v.videoThumbnails
              }));

          const results =
            filterResults(
              rows
            ).slice(
              0,
              limit
            );

          if (!results.length) {
            throw new Error(
              'لا توجد نتائج'
            );
          }

          return results;
        }
      );

  return await Promise.any(
    attempts
  );
}

async function pipedSearch(
  query,
  limit
) {
  await refreshInstances();

  const attempts =
    PIPED
      .slice(0, 8)
      .map(
        async base => {
          const d =
            await getJson(
              `${base}/search`,
              {
                q: query,
                filter: 'videos'
              },
              7000
            );

          const rows =
            (
              d.items || []
            ).filter(
              v =>
                v.type ===
                  'stream' ||
                v.url?.includes(
                  '/watch?v='
                )
            );

          const results =
            filterResults(
              rows
            ).slice(
              0,
              limit
            );

          if (!results.length) {
            throw new Error(
              'لا توجد نتائج'
            );
          }

          return results;
        }
      );

  return await Promise.any(
    attempts
  );
}

/*
 * =========================
 * YT-DLP
 * =========================
 */

let ytDlpAvailable = null;

async function hasYtDlp() {
  if (
    ytDlpAvailable !== null
  ) {
    return ytDlpAvailable;
  }

  try {
    await exec(
      'yt-dlp',
      ['--version'],
      {
        timeout: 2500
      }
    );

    ytDlpAvailable =
      true;

    return true;
  } catch {
    ytDlpAvailable =
      false;

    return false;
  }
}

async function ytDlpSearch(
  query,
  limit
) {
  if (
    !(await hasYtDlp())
  ) {
    throw new Error(
      'غير مثبت'
    );
  }

  const { stdout } =
    await exec(
      'yt-dlp',
      [
        '--flat-playlist',
        '--dump-single-json',
        '--no-warnings',
        '--skip-download',
        `ytsearch${Math.max(
          8,
          limit
        )}:${query}`
      ],
      {
        timeout: 15000,

        maxBuffer:
          8 * 1024 * 1024
      }
    );

  const data =
    JSON.parse(stdout);

  return filterResults(
    data.entries || []
  ).slice(
    0,
    limit
  );
}

/*
 * =========================
 * SEARCH
 * =========================
 */

export async function search(
  query,
  limit = 8
) {
  const q =
    clean(query);

  if (!q) {
    return {
      blocked: false,
      results: []
    };
  }

  if (
    forbidden(q)
  ) {
    return {
      blocked: true,
      results: []
    };
  }

  const providers = [
    [
      'hidenfree',
      () =>
        hidenfreeSearch(
          q,
          limit
        )
    ],

    [
      'engez',
      () =>
        engezSearch(
          q,
          limit
        )
    ],

    [
      'invidious',
      () =>
        invidiousSearch(
          q,
          limit
        )
    ],

    [
      'piped',
      () =>
        pipedSearch(
          q,
          limit
        )
    ],

    [
      'yt-dlp',
      () =>
        ytDlpSearch(
          q,
          limit
        )
    ]
  ];

  /*
   * تشغيل كل محركات البحث
   * بالتوازي.
   */

  const tasks =
    providers.map(
      async ([name, fn]) => {
        try {
          const rows =
            await fn();

          return {
            name,

            rows:
              Array.isArray(rows)
                ? rows
                : []
          };
        } catch (error) {
          return {
            name,

            rows: [],

            error:
              error?.message ||
              String(error)
          };
        }
      }
    );

  const results =
    await Promise.all(
      tasks
    );

  const merged = [];
  const seen = new Set();
  const errors = [];

  /*
   * دمج النتائج.
   */

  for (
    const result of results
  ) {
    if (result.error) {
      errors.push(
        `${result.name}: ${result.error}`
      );
    }

    for (
      const item of
        result.rows
    ) {
      const key =
        item.url ||
        `${item.title}|${item.channel}`;

      if (
        seen.has(key)
      ) {
        continue;
      }

      seen.add(key);

      merged.push(item);

      if (
        merged.length >=
        limit
      ) {
        break;
      }
    }

    if (
      merged.length >=
      limit
    ) {
      break;
    }
  }

  if (merged.length) {
    const source =
      results.find(
        x =>
          x.rows?.length
      )?.name ||
      'multi';

    return {
      blocked: false,

      source,

      results:
        merged.slice(
          0,
          limit
        )
    };
  }

  const error =
    new Error(
      `تعذر البحث في يوتيوب: ${errors.join(' / ')}`
    );

  error.code =
    'YOUTUBE_SEARCH_FAILED';

  throw error;
}

export async function searchSmart(
  input,
  limit = 8
) {
  const intent =
    parseDurationIntent(
      input
    );

  const result =
    await search(
      intent.query,
      limit
    );

  if (
    result.blocked ||
    intent.seconds == null
  ) {
    return result;
  }

  const target =
    intent.seconds;

  const ranked =
    [...result.results]
      .map(item => ({
        ...item,

        durationDelta:
          item.durationSeconds ==
          null
            ? Number.POSITIVE_INFINITY
            : Math.abs(
                item.durationSeconds -
                target
              ),

        exactDuration:
          item.durationSeconds ===
          target
      }))
      .sort(
        (a, b) => {
          if (
            a.exactDuration !==
            b.exactDuration
          ) {
            return (
              Number(
                b.exactDuration
              ) -
              Number(
                a.exactDuration
              )
            );
          }

          return (
            a.durationDelta -
            b.durationDelta
          );
        }
      );

  return {
    ...result,

    requestedDuration:
      target,

    results:
      ranked.slice(
        0,
        3
      )
  };
}

/*
 * =========================
 * INFO
 * =========================
 */

export async function info(
  url
) {
  if (
    forbidden(url)
  ) {
    return {
      blocked: true
    };
  }

  try {
    const d =
      await getJson(
        `${HIDENFREE}/api/youtube/info`,
        {
          url
        },
        8000
      );

    if (
      forbidden(
        `${d.title || ''} ${
          d.uploader ||
          d.channel ||
          ''
        }`
      )
    ) {
      return {
        blocked: true
      };
    }

    const duration =
      parseDuration(
        d.duration
      );

    return {
      blocked: false,

      url,

      title:
        clean(
          d.title ||
          'فيديو يوتيوب'
        ),

      thumbnail:
        d.thumbnail || '',

      durationSeconds:
        duration,

      duration_string:
        formatDuration(
          duration
        ),

      channel:
        clean(
          d.uploader ||
          d.channel ||
          ''
        )
    };
  } catch {}

  if (
    await hasYtDlp()
  ) {
    try {
      const {
        stdout
      } = await exec(
        'yt-dlp',
        [
          '--dump-single-json',
          '--no-warnings',
          '--skip-download',
          url
        ],
        {
          timeout: 15000,

          maxBuffer:
            4 * 1024 * 1024
        }
      );

      const d =
        JSON.parse(stdout);

      const item =
        normalizeResult(d);

      if (
        forbidden(
          `${item.title} ${item.channel}`
        )
      ) {
        return {
          blocked: true
        };
      }

      return {
        blocked: false,

        ...item,

        url
      };
    } catch {}
  }

  return {
    blocked: false,

    url,

    title:
      'فيديو يوتيوب',

    thumbnail: '',

    duration_string: '?',

    durationSeconds: null,

    channel: ''
  };
}

/*
 * =========================
 * YOUTUBE ID
 * =========================
 */

function videoId(url) {
  try {
    const u =
      new URL(url);

    if (
      u.hostname ===
        'youtu.be' ||
      u.hostname.endsWith(
        '.youtu.be'
      )
    ) {
      return u.pathname
        .slice(1)
        .split('/')[0];
    }

    return (
      u.searchParams.get(
        'v'
      ) ||
      null
    );
  } catch {
    return null;
  }
}

/*
 * =========================
 * SSRF
 * =========================
 */

function isPrivateIp(ip) {
  if (
    net.isIPv4(ip)
  ) {
    const [
      a,
      b
    ] =
      ip
        .split('.')
        .map(Number);

    return (
      a === 10 ||
      a === 127 ||
      a === 0 ||
      (
        a === 169 &&
        b === 254
      ) ||
      (
        a === 172 &&
        b >= 16 &&
        b <= 31
      ) ||
      (
        a === 192 &&
        b === 168
      )
    );
  }

  if (
    net.isIPv6(ip)
  ) {
    const v =
      ip.toLowerCase();

    return (
      v === '::1' ||
      v === '::' ||
      v.startsWith('fc') ||
      v.startsWith('fd') ||
      v.startsWith('fe80:')
    );
  }

  return true;
}

async function assertSafeUrl(
  raw
) {
  let url;

  try {
    url =
      new URL(raw);
  } catch {
    throw new Error(
      'رابط التحميل غير صالح.'
    );
  }

  if (
    url.protocol !==
    'https:'
  ) {
    throw new Error(
      'رابط التحميل غير آمن.'
    );
  }

  const host =
    url.hostname.toLowerCase();

  if (
    host ===
      'localhost' ||
    host.endsWith(
      '.localhost'
    ) ||
    host.endsWith(
      '.local'
    ) ||
    (
      net.isIP(host) &&
      isPrivateIp(host)
    )
  ) {
    throw new Error(
      'تم رفض رابط داخلي غير آمن.'
    );
  }

  if (
    !net.isIP(host)
  ) {
    try {
      const addresses =
        await dns.lookup(
          host,
          {
            all: true
          }
        );

      if (
        addresses.some(
          x =>
            isPrivateIp(
              x.address
            )
        )
      ) {
        throw new Error(
          'رابط التحميل يشير إلى شبكة داخلية.'
        );
      }
    } catch (error) {
      if (
        error?.message?.includes(
          'شبكة داخلية'
        )
      ) {
        throw error;
      }

      /*
       * DNS غير متاح مؤقتًا.
       * لا نرفض الرابط هنا.
       */
    }
  }

  return url;
}

/*
 * =========================
 * SAFE MEDIA DOWNLOAD
 * =========================
 */

async function downloadLimited(
  rawUrl,
  maxBytes,
  timeout = 45000
) {
  let current =
    await assertSafeUrl(
      rawUrl
    );

  for (
    let redirect = 0;
    redirect <= 3;
    redirect++
  ) {
    const response =
      await fetch(
        current,
        {
          redirect: 'manual',

          headers: {
            'user-agent':
              'STEAM-BOT/4.0',

            accept:
              'audio/*,video/*,application/octet-stream,*/*'
          },

          signal:
            timeoutSignal(
              timeout
            )
        }
      );

    if (
      response.status >= 300 &&
      response.status < 400
    ) {
      const location =
        response.headers.get(
          'location'
        );

      if (!location) {
        throw new Error(
          'إعادة توجيه بدون رابط.'
        );
      }

      current =
        await assertSafeUrl(
          new URL(
            location,
            current
          ).href
        );

      continue;
    }

    if (
      !response.ok
    ) {
      throw new Error(
        `تنزيل الوسائط HTTP ${response.status}`
      );
    }

    const contentType =
      String(
        response.headers.get(
          'content-type'
        ) || ''
      ).toLowerCase();

    /*
     * رفض HTML و JSON.
     *
     * هذه كانت من أسباب إرسال
     * ملفات غير صالحة على هيئة صوت.
     */

    if (
      contentType.includes(
        'text/html'
      ) ||
      contentType.includes(
        'application/json'
      ) ||
      contentType.includes(
        'text/plain'
      )
    ) {
      throw new Error(
        `الخادم لم يرجع ملفًا صوتيًا (${contentType || 'نوع غير معروف'})`
      );
    }

    const length =
      Number(
        response.headers.get(
          'content-length'
        ) || 0
      );

    if (
      length > maxBytes
    ) {
      throw new Error(
        'حجم الوسائط أكبر من الحد المسموح.'
      );
    }

    if (
      !response.body
    ) {
      throw new Error(
        'الخادم لم يُرجع تدفق الوسائط.'
      );
    }

    const reader =
      response.body.getReader();

    const chunks = [];

    let total = 0;

    try {
      while (true) {
        const {
          done,
          value
        } =
          await reader.read();

        if (done) {
          break;
        }

        if (
          !value ||
          !value.byteLength
        ) {
          continue;
        }

        total +=
          value.byteLength;

        if (
          total > maxBytes
        ) {
          throw new Error(
            'حجم الوسائط أكبر من الحد المسموح.'
          );
        }

        chunks.push(
          Buffer.from(value)
        );
      }
    } finally {
      try {
        reader.releaseLock();
      } catch {}
    }

    if (
      total < 1024
    ) {
      throw new Error(
        'الملف الصوتي فارغ أو صغير بشكل غير صالح.'
      );
    }

    return Buffer.concat(
      chunks,
      total
    );
  }

  throw new Error(
    'عدد إعادة التوجيه كبير جدًا.'
  );
}

/*
 * =========================
 * DURATION LIMIT
 * =========================
 */

async function enforceDuration(
  data
) {
  const max =
    Number(
      data?.type === 'audio'
        ? config.limits
            ?.maxAudioDuration
        : config.limits
            ?.maxVideoDuration
    ) ||
    (
      data?.type === 'audio'
        ? 900
        : 1800
    );

  let duration =
    Number(
      data?.durationSeconds
    );

  if (
    !Number.isFinite(duration)
  ) {
    const details =
      await info(
        data.url
      );

    if (
      details?.blocked
    ) {
      throw new Error(
        'هذا المحتوى محظور حسب فلتر STEAM.'
      );
    }

    duration =
      Number(
        details?.durationSeconds
      );
  }

  if (
    Number.isFinite(duration) &&
    duration > max
  ) {
    throw new Error(
      `مدة الوسائط تتجاوز الحد المسموح (${Math.floor(max / 60)} دقيقة).`
    );
  }

  return duration;
}

/*
 * =========================
 * YT-DLP DOWNLOAD
 * =========================
 */

async function ytdlpDownload(
  url,
  type,
  quality
) {
  if (
    !(await hasYtDlp())
  ) {
    throw new Error(
      'غير مثبت'
    );
  }

  const dir =
    await fs.mkdtemp(
      path.join(
        os.tmpdir(),
        'steam-yt-'
      )
    );

  try {
    const output =
      path.join(
        dir,

        type === 'audio'
          ? 'audio.%(ext)s'
          : 'video.%(ext)s'
      );

    const args =
      type === 'audio'
        ? [
            '--no-warnings',

            '--no-playlist',

            '--match-filter',
            `duration <= ${
              Number(
                config.limits
                  ?.maxAudioDuration
              ) || 900
            }`,

            '-f',
            'bestaudio/best',

            '-o',
            output,

            url
          ]
        : [
            '--no-warnings',

            '--no-playlist',

            '--match-filter',
            `duration <= ${
              Number(
                config.limits
                  ?.maxVideoDuration
              ) || 1800
            }`,

            '-f',
            `bv*[height<=${Number(
              quality
            ) || 720}]+ba/b[height<=${Number(
              quality
            ) || 720}]/b`,

            '--merge-output-format',
            'mp4',

            '-o',
            output,

            url
          ];

    await exec(
      'yt-dlp',
      args,
      {
        timeout:
          120000,

        maxBuffer:
          4 * 1024 * 1024
      }
    );

    const files =
      await fs.readdir(
        dir
      );

    const media =
      files.find(
        file =>
          /\.(mp4|m4a|webm|mp3|opus|aac)$/i.test(
            file
          )
      );

    if (!media) {
      throw new Error(
        'yt-dlp لم ينتج ملف وسائط'
      );
    }

    const mediaPath =
      path.join(
        dir,
        media
      );

    const stat =
      await fs.stat(
        mediaPath
      );

    const maxBytes =
      Number(
        config.limits
          ?.maxMediaBytes
      ) ||
      64 *
        1024 *
        1024;

    if (
      stat.size > maxBytes
    ) {
      throw new Error(
        'حجم الوسائط أكبر من الحد المسموح.'
      );
    }

    if (
      stat.size < 1024
    ) {
      throw new Error(
        'yt-dlp أنتج ملفًا فارغًا.'
      );
    }

    const buffer =
      await fs.readFile(
        mediaPath
      );

    if (
      !buffer.length
    ) {
      throw new Error(
        'ملف yt-dlp فارغ.'
      );
    }

    return {
      buffer,

      filename:
        `steam-${Date.now()}${path.extname(media)}`
    };
  } finally {
    await fs.rm(
      dir,
      {
        recursive: true,
        force: true
      }
    ).catch(
      () => {}
    );
  }
}

/*
 * =========================
 * ENGEZ DOWNLOAD
 * =========================
 */

async function engezDownload(
  url,
  type
) {
  const endpoints = [
    '/download/youtubev2',
    '/download/ytdl',
    '/download/youtube'
  ];

  let last;

  for (
    const endpoint of
      endpoints
  ) {
    try {
      const d =
        await getJson(
          `${ENGEZ}${endpoint}`,
          {
            url,
            type
          },
          18000
        );

      const payload =
        d?.response ||
        d?.data ||
        d;

      const direct =
        payload?.download_url ||
        payload?.downloadUrl ||
        payload?.url;

      if (!direct) {
        throw new Error(
          payload?.error ||
          'لم يرجع رابط تحميل'
        );
      }

      const safe =
        await assertSafeUrl(
          direct
        );

      const buffer =
        await downloadLimited(
          safe.href,

          Number(
            config.limits
              ?.maxMediaBytes
          ) ||
            64 *
              1024 *
              1024,

          35000
        );

      if (
        !buffer ||
        buffer.length < 1024
      ) {
        throw new Error(
          'ملف Engez فارغ'
        );
      }

      return {
        buffer,

        filename:
          payload.filename ||
          `steam-${Date.now()}.${
            type === 'audio'
              ? 'm4a'
              : 'mp4'
          }`
      };
    } catch (error) {
      last =
        error;
    }
  }

  throw (
    last ||
    new Error(
      'فشل التحميل من Engez'
    )
  );
}

/*
 * =========================
 * PIPED DOWNLOAD
 * =========================
 */

async function pipedDownload(
  url,
  type,
  quality
) {
  const id =
    videoId(url);

  if (!id) {
    throw new Error(
      'رابط يوتيوب غير صالح'
    );
  }

  await refreshInstances();

  const instances =
    PIPED.slice(
      0,
      8
    );

  const attempts =
    instances.map(
      async base => {
        const d =
          await getJson(
            `${base}/streams/${encodeURIComponent(id)}`,
            {},
            7000
          );

        /*
         * للصوت نأخذ audioStreams فقط.
         * لا نرسل video stream على أنه audio.
         */

        const streams =
          type === 'audio'
            ? (
                d.audioStreams ||
                []
              )
            : (
                d.videoStreams ||
                []
              );

        const usable =
          streams.filter(
            stream =>
              stream?.url &&
              /^https:\/\//i.test(
                stream.url
              )
          );

        if (
          !usable.length
        ) {
          throw new Error(
            'لا توجد وسائط قابلة للتحميل'
          );
        }

        const target =
          Number(quality) ||
          (
            type === 'audio'
              ? 128
              : 720
          );

        const chosen =
          [...usable].sort(
            (a, b) => {
              const av =
                type === 'audio'
                  ? Number(
                      a.bitrate ||
                      0
                    )
                  : Number(
                      a.height ||
                      0
                    );

              const bv =
                type === 'audio'
                  ? Number(
                      b.bitrate ||
                      0
                    )
                  : Number(
                      b.height ||
                      0
                    );

              const targetValue =
                type === 'audio'
                  ? target *
                    1000
                  : target;

              return (
                Math.abs(
                  av -
                    targetValue
                ) -
                Math.abs(
                  bv -
                    targetValue
                )
              );
            }
          )[0];

        if (
          !chosen?.url
        ) {
          throw new Error(
            'تعذر اختيار مسار الوسائط'
          );
        }

        /*
         * بعض Piped instances ترجع روابط
         * داخلية/ميتة. assertSafeUrl
         * يتحقق منها قبل التحميل.
         */

        const safe =
          await assertSafeUrl(
            chosen.url
          );

        const buffer =
          await downloadLimited(
            safe.href,

            Number(
              config.limits
                ?.maxMediaBytes
            ) ||
              64 *
                1024 *
                1024,

            30000
          );

        if (
          !buffer ||
          buffer.length < 1024
        ) {
          throw new Error(
            'Piped أرجع ملفًا صوتيًا فارغًا'
          );
        }

        /*
         * نحدد الامتداد بناءً على
         * نوع المسار قدر الإمكان.
         */

        let extension =
          'm4a';

        const mime =
          String(
            chosen.mimeType ||
            chosen.mime ||
            ''
          ).toLowerCase();

        if (
          mime.includes(
            'webm'
          )
        ) {
          extension =
            'webm';
        } else if (
          mime.includes(
            'opus'
          )
        ) {
          extension =
            'opus';
        } else if (
          mime.includes(
            'mp4'
          ) ||
          mime.includes(
            'm4a'
          )
        ) {
          extension =
            'm4a';
        }

        return {
          buffer,

          filename:
            `steam-${id}.${extension}`,

          mimetype:
            mime || undefined
        };
      }
    );

  return await Promise.any(
    attempts
  );
}

/*
 * =========================
 * PUBLIC DOWNLOAD
 * =========================
 */

export async function download(
  data
) {
  if (!data?.url) {
    throw new Error(
      'رابط يوتيوب غير موجود'
    );
  }

  let u;

  try {
    u =
      new URL(
        data.url
      );

    const host =
      u.hostname.toLowerCase();

    if (
      !(
        host ===
          'youtu.be' ||
        host ===
          'youtube.com' ||
        host ===
          'www.youtube.com' ||
        host.endsWith(
          '.youtube.com'
        )
      )
    ) {
      throw new Error(
        'رابط يوتيوب غير صالح.'
      );
    }
  } catch (error) {
    throw new Error(
      error?.message ||
      'رابط يوتيوب غير صالح.'
    );
  }

  await enforceDuration(
    data
  );

  if (
    forbidden(
      `${data.title || ''} ${
        data.channel || ''
      }`
    )
  ) {
    throw new Error(
      'هذا المحتوى محظور حسب فلتر STEAM.'
    );
  }

  const errors = [];

  /*
   * yt-dlp:
   * لو غير مثبت، hasYtDlp()
   * يرجع false فورًا.
   *
   * Piped و Engez يعملان بالتوازي.
   */

  const providers =
    data.type === 'audio'
      ? [
          [
            'yt-dlp',
            () =>
              ytdlpDownload(
                data.url,
                'audio',
                data.quality ||
                  128
              )
          ],

          [
            'piped',
            () =>
              pipedDownload(
                data.url,
                'audio',
                data.quality ||
                  128
              )
          ],

          [
            'engez',
            () =>
              engezDownload(
                data.url,
                'audio'
              )
          ]
        ]
      : [
          [
            'yt-dlp',
            () =>
              ytdlpDownload(
                data.url,
                'video',
                data.quality ||
                  720
              )
          ],

          [
            'piped',
            () =>
              pipedDownload(
                data.url,
                'video',
                data.quality ||
                  720
              )
          ],

          [
            'engez',
            () =>
              engezDownload(
                data.url,
                'video'
              )
          ]
        ];

  const attempts =
    providers.map(
      async ([name, fn]) => {
        try {
          const result =
            await fn();

          if (
            !result?.buffer ||
            !Buffer.isBuffer(
              result.buffer
            ) ||
            result.buffer.length <
              1024
          ) {
            throw new Error(
              'المزود أرجع ملفًا فارغًا'
            );
          }

          return {
            name,
            result
          };
        } catch (error) {
          throw new Error(
            `${name}: ${
              error?.message ||
              String(error)
            }`
          );
        }
      }
    );

  try {
    const winner =
      await Promise.any(
        attempts
      );

    return winner.result;
  } catch (aggregate) {
    for (
      const error of
        aggregate?.errors ||
        []
    ) {
      errors.push(
        error?.message ||
        String(error)
      );
    }

    throw new Error(
      `فشل تحميل الوسائط: ${errors.join(' / ')}`
    );
  }
}