const promoteAdmin = {
  name: 'رفع ادمن',
  aliases: ['رفع-ادمن', 'رفع_ادمن'],
  category: 'Tools',
  requiredRole: 'user',
  async execute(ctx) {
    const { updateAdmin } = await import('../services/group-admin.js');
    return updateAdmin(ctx, 'promote');
  }
};

const demoteAdmin = {
  name: 'ازل ادمن',
  aliases: ['إزل ادمن', 'ازل-ادمن', 'ازل_ادمن'],
  category: 'Tools',
  requiredRole: 'user',
  async execute(ctx) {
    const { updateAdmin } = await import('../services/group-admin.js');
    return updateAdmin(ctx, 'demote');
  }
};

export default {
  commands: [promoteAdmin, demoteAdmin]
};
