import assert from 'node:assert/strict';

import {
  parseExactSurahQuery,
  parseExactVerseQuery
} from '../services/dorar.js';

import { Jimp } from 'jimp';

import spotifyCommand from '../commands/سبوتي.js';

assert.deepEqual(
  parseExactSurahQuery('سورة الفاتحة'),
  {
    surahId: 1,
    surahName: 'الفاتحة'
  }
);

assert.equal(
  parseExactVerseQuery('سورة الفاتحة 2')?.ayah,
  2
);

assert.equal(
  parseExactVerseQuery('سورة البقرة آية 255')?.ayah,
  255
);

assert.equal(
  parseExactVerseQuery('آية الكرسي')?.ayah,
  255
);

assert.equal(
  parseExactVerseQuery('آية 255'),
  null
);

assert.equal(
  parseExactVerseQuery('سورة الفرقان 11')?.surahId,
  25
);

// Jimp
assert.equal(
  typeof Jimp.read,
  'function'
);

// Spotify command
assert.equal(
  spotifyCommand?.name,
  'سبوتي'
);

console.log(
  'STEAM V3 smoke tests: PASS'
);
