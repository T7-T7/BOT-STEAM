# STEAM V2 — Phase 2 hotfix: Developer LID identity

- Bare developer phone numbers normalize to `@s.whatsapp.net`.
- PN/LID mappings are direction-independent.
- PN/LID mappings persist in `data/identities.json`.
- Incoming group messages register participant/participantAlt mappings.
- `.خروج` remains developer-only and group-only.

Tests: syntax PASS, smoke PASS, identity mapping PASS.

## Phase 6 fixes
- Developer authorization for group-management commands does not require the developer to be a WhatsApp group admin; the bot itself must still be a group admin.
- Owner/LID resolution is centralized in `security/owner.js` and supports `@sgintokic/baileys` USync with a Baileys fallback.
- Developer numbers are no longer hard-coded in source; configure `DEVELOPERS`/`MAIN_OWNERS`.
- Identity persistence is debounced and asynchronous.
- Database/archive updates are serialized per key.
- Message backlog is bounded.
- YouTube downloads have duration/size/URL safety limits.
- Project packs exclude plugins, credentials and secret-like files.
- Plugin reload reports load errors and command deletion reloads the registry.
- Group parser no longer depends on the original spacing of multi-word commands.
