export default {
  name: 'رستر',
  aliases: ['restart', 'ريستارت'],
  category: 'نظام',
  requiredRole: 'developer',

  async execute(ctx) {
    const { message, sock } = ctx;

    try {
      await sock.sendMessage(
        message.chatId,
        {
          text: '♻️ جارٍ إعادة تشغيل البوت...'
        },
        {
          quoted: message.raw || message
        }
      );
    } catch {}

    setTimeout(() => {
      process.exit(0);
    }, 500);
  }
};