import { ownerService } from './owner.js';

export function register(first, second) {
  return ownerService.register(first, second);
}

export function resolve(id) {
  return ownerService.resolve(id);
}

export function number(id) {
  return ownerService.number(id);
}

export function lidOf(id) {
  return ownerService.lidOf(id);
}

export function isJid(value) {
  return /@(?:s\.whatsapp\.net|g\.us|lid)$/i.test(String(value || '').trim());
}

export function clear() {
  ownerService.clear();
}
