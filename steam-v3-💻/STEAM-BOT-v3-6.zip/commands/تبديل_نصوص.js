import fs from 'fs/promises';
import path from 'path';

import {
  isSensitivePath
} from '../services/system-files.js';

const root = path.resolve('.');

const EXCLUDED_DIRECTORIES = new Set([
  'node_modules',
  '.git',
  '.cache',
  'cache',
  'coverage',
  'session',
  '.session',
  'auth',
  'tmp',
  'temp',
  '.tmp',
  '.temp'
]);

const ALLOWED_EXTENSIONS = new Set([
  '.js',
  '.mjs',
  '.cjs',
  '.json',
  '.ts',
  '.tsx',
  '.jsx',
  '.css',
  '.html',
  '.md',
  '.txt'
]);

function normalizeRel(value) {
  return String(value || '')
    .replace(/\\/g, '/')
    .replace(/^\.\//, '');
}

function isExcludedDirectory(name) {
  return EXCLUDED_DIRECTORIES.has(
    String(name || '').toLowerCase()
  );
}

function isAllowedFile(fileName) {
  return ALLOWED_EXTENSIONS.has(
    path.extname(fileName).toLowerCase()
  );
}

async function walkProject(dir = root) {
  const result = [];

  let entries;

  try {
    entries = await fs.readdir(
      dir,
      {
        withFileTypes: true
      }
    );
  } catch {
    return result;
  }

  for (const entry of entries) {
    const fullPath =
      path.join(
        dir,
        entry.name
      );

    const relativePath =
      normalizeRel(
        path.relative(
          root,
          fullPath
        )
      );

    if (entry.isDirectory()) {
      if (
        isExcludedDirectory(
          entry.name
        )
      ) {
        continue;
      }

      if (
        isSensitivePath(
          relativePath
        )
      ) {
        continue;
      }

      result.push(
        ...await walkProject(
          fullPath
        )
      );

      continue;
    }

    if (!entry.isFile()) {
      continue;
    }

    if (
      !isAllowedFile(
        entry.name
      )
    ) {
      continue;
    }

    if (
      isSensitivePath(
        relativePath
      )
    ) {
      continue;
    }

    result.push({
      fullPath,
      relativePath
    });
  }

  return result;
}

function parseReplacement(args) {
  const input =
    String(
      args?.join(' ') || ''
    ).trim();

  const separator =
    input.indexOf('|');

  if (separator === -1) {
    return null;
  }

  const oldText =
    input
      .slice(0, separator)
      .trim();

  const newText =
    input
      .slice(separator + 1)
      .trim();

  if (!oldText || !newText) {
    return null;
  }

  return {
    oldText,
    newText
  };
}

function escapeRegExp(value) {
  return value.replace(
    /[.*+?^${}()|[\]\\]/g,
    '\\$&'
  );
}

export default {
  name: 'بدل',

  aliases: [
    'استبدال',
    'replace'
  ],

  category: 'نظام',

  requiredRole:
    'developer',

  async execute(ctx) {
    const {
      message,
      args
    } = ctx;

    const parsed =
      parseReplacement(args);

    if (!parsed) {
      return message.reply(
        '⚡ *طريقة الاستخدام:*\n\n' +
        '`.بدل النص القديم | النص الجديد`\n\n' +
        'مثال:\n' +
        '`.بدل Cheon | Raiden`'
      );
    }

    const {
      oldText,
      newText
    } = parsed;

    const files =
      await walkProject();

    if (!files.length) {
      return message.reply(
        '⚠️ لم يتم العثور على ملفات قابلة للفحص.'
      );
    }

    const regex =
      new RegExp(
        escapeRegExp(oldText),
        'g'
      );

    const changedFiles = [];
    let totalReplacements = 0;

    for (const file of files) {
      let source;

      try {
        source =
          await fs.readFile(
            file.fullPath,
            'utf8'
          );
      } catch {
        continue;
      }

      if (!source.includes(oldText)) {
        continue;
      }

      const matches =
        source.match(regex);

      if (!matches?.length) {
        continue;
      }

      const updated =
        source.replace(
          regex,
          newText
        );

      if (updated === source) {
        continue;
      }

      try {
        await fs.writeFile(
          file.fullPath,
          updated,
          'utf8'
        );

        changedFiles.push(
          file.relativePath
        );

        totalReplacements +=
          matches.length;

      } catch (error) {
        console.error(
          '[REPLACE WRITE]',
          file.relativePath,
          error
        );
      }
    }

    if (!changedFiles.length) {
      return message.reply(
        `ℹ️ لم يتم العثور على:\n\n` +
        `"${oldText}"\n\n` +
        `📁 تم فحص ${files.length} ملف.`
      );
    }

    const fileList =
      changedFiles
        .map(
          file =>
            `📄 ${file}`
        )
        .join('\n');

    await message.reply(
      `✅ *تم الاستبدال بنجاح*\n\n` +
      `🔍 *القديم:* ${oldText}\n` +
      `🔄 *الجديد:* ${newText}\n` +
      `📁 *الملفات:* ${changedFiles.length}\n` +
      `🔢 *عدد الاستبدالات:* ${totalReplacements}\n\n` +
      `📄 *الملفات التي تم تعديلها:*\n` +
      fileList
    );

    return true;
  }
};