import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';

const ROOT =
  path.resolve(
    path.dirname(
      fileURLToPath(
        import.meta.url
      )
    ),
    '../data/archives'
  );

const locks = new Map();

export function cleanArchiveName(value) {
  return String(value || '')
    .replace(
      /[\\/:*?"<>|]/g,
      ' '
    )
    .replace(
      /\s+/g,
      ' '
    )
    .trim();
}

function fileFor(name) {
  const safe =
    cleanArchiveName(name);

  if (!safe) {
    throw new Error(
      'اسم الأرشيف غير صالح.'
    );
  }

  return path.join(
    ROOT,
    `${safe}.json`
  );
}

export async function readArchive(name) {
  const safe =
    cleanArchiveName(name);

  if (!safe) {
    throw new Error(
      'اسم الأرشيف غير صالح.'
    );
  }

  try {
    const data =
      JSON.parse(
        await fs.readFile(
          fileFor(safe),
          'utf8'
        )
      );

    return {
      name: safe,
      entries:
        Array.isArray(data?.entries)
          ? data.entries
          : []
    };

  } catch {
    return {
      name: safe,
      entries: []
    };
  }
}

export async function writeArchive(archive) {
  const safe =
    cleanArchiveName(
      archive?.name
    );

  if (!safe) {
    throw new Error(
      'اسم الأرشيف غير صالح.'
    );
  }

  await fs.mkdir(
    ROOT,
    {
      recursive: true
    }
  );

  const file =
    fileFor(safe);

  const tmp =
    `${file}.${process.pid}.${Date.now()}.tmp`;

  await fs.writeFile(
    tmp,
    JSON.stringify(
      {
        name: safe,
        entries:
          Array.isArray(archive.entries)
            ? archive.entries
            : []
      },
      null,
      2
    ),
    'utf8'
  );

  await fs.rename(
    tmp,
    file
  );
}

export async function updateArchive(
  name,
  fn
) {
  const safe =
    cleanArchiveName(name);

  if (!safe) {
    throw new Error(
      'اسم الأرشيف غير صالح.'
    );
  }

  const previous =
    locks.get(safe) ||
    Promise.resolve();

  let release;

  const gate =
    new Promise(
      resolve => {
        release = resolve;
      }
    );

  const chain =
    previous
      .catch(() => {})
      .then(
        () => gate
      );

  locks.set(
    safe,
    chain
  );

  try {
    await previous.catch(
      () => {}
    );

    const current =
      await readArchive(
        safe
      );

    const next =
      (await fn(current)) ||
      current;

    await writeArchive(
      next
    );

    return next;

  } finally {
    release();

    if (
      locks.get(safe) ===
      chain
    ) {
      locks.delete(
        safe
      );
    }
  }
}

export function quotedText(ctx) {
  const q =
    ctx?.message?.quoted;

  return (
    q?.message?.conversation ||
    q?.message
      ?.extendedTextMessage
      ?.text ||
    q?.message
      ?.imageMessage
      ?.caption ||
    q?.message
      ?.videoMessage
      ?.caption ||
    q?.message
      ?.documentMessage
      ?.caption ||
    q?.text ||
    ''
  ).trim();
}

/*
 * يدعم:
 *
 * جدول-[شخبارك..]
 * جدول - [شخبارك..]
 *
 * ويقبل أي محتوى داخل الأقواس.
 */
export function parseDirectAdd(value) {
  const match =
    String(value || '')
      .trim()
      .match(
        /^(.+?)\s*-\s*\[([\s\S]*)\]\s*$/u
      );

  if (!match) {
    return null;
  }

  const name =
    cleanArchiveName(
      match[1]
    );

  const content =
    String(
      match[2] || ''
    )
      .replace(
        /\r/g,
        ''
      )
      .trim();

  if (
    !name ||
    !content
  ) {
    return null;
  }

  return {
    name,
    content
  };
}

/*
 * استخراج محتوى أمر الأرشيف.
 *
 * يدعم:
 *
 * .اضف ...
 * .اضافة ...
 * .إضافة ...
 * .أضف ...
 * .ضيف ...
 * .ارشيف ...
 * .ت ...
 *
 * كما يدعم وجود "-" مباشرة بعد اسم الأمر:
 *
 * .اضافة-جدول-[هلا]
 * .اضف-جدول-[هلا]
 */
export function commandPayload(ctx) {
  const text =
    String(
      ctx?.message?.text ||
      ctx?.text ||
      ''
    ).trim();

  if (!text) {
    return '';
  }

  /*
   * نحذف اسم الأمر فقط.
   *
   * لاحظ:
   * لا نحذف محتوى ما بعد "-"
   * حتى تصل الصيغة:
   *
   * .اضافة-جدول-[هلا]
   *
   * إلى parseDirectAdd() بالشكل:
   *
   * جدول-[هلا]
   */

  const commandPattern =
    /^\.?(?:اضف|أضف|اضافة|إضافة|ضيف|ارشيف|ت)(?=\s|-|$)/iu;

  return text
    .replace(
      commandPattern,
      ''
    )
    .replace(
      /^\s+/u,
      ''
    )
    .trim();
}
