import {
  downloadMediaMessage
} from '@whiskeysockets/baileys';

/* =========================================================
 * VIEW ONCE
 * =========================================================
 *
 * الاستخدام:
 *
 * .ع
 * .عرض
 *
 * يجب تنفيذ الأمر بالرد على:
 * - صورة View Once
 * - فيديو View Once
 * - صوت View Once
 *
 * ========================================================= */

function getQuotedMessage(message) {
  const raw = message?.raw;

  if (!raw?.message) {
    return null;
  }

  /*
   * الرسالة الحالية يجب أن تحتوي
   * على contextInfo.quotedMessage
   */

  const messageTypes = [
    'extendedTextMessage',
    'imageMessage',
    'videoMessage',
    'audioMessage',
    'conversation'
  ];

  for (const type of messageTypes) {
    const current =
      raw.message?.[type];

    if (
      current?.contextInfo?.quotedMessage
    ) {
      return current
        .contextInfo
        .quotedMessage;
    }
  }

  /*
   * بحث عام احتياطي داخل الرسالة.
   */

  for (
    const value
    of Object.values(raw.message)
  ) {
    if (
      value?.contextInfo?.quotedMessage
    ) {
      return value
        .contextInfo
        .quotedMessage;
    }
  }

  return null;
}

/* =========================================================
 * UNWRAP VIEW ONCE
 * ========================================================= */

function unwrapViewOnce(message) {
  if (!message) {
    return null;
  }

  /*
   * ViewOnceMessage
   */

  if (
    message.viewOnceMessage?.message
  ) {
    return (
      message
        .viewOnceMessage
        .message
    );
  }

  /*
   * ViewOnceMessageV2
   */

  if (
    message.viewOnceMessageV2?.message
  ) {
    return (
      message
        .viewOnceMessageV2
        .message
    );
  }

  /*
   * ViewOnceMessageV2Extension
   */

  if (
    message
      .viewOnceMessageV2Extension
      ?.message
  ) {
    return (
      message
        .viewOnceMessageV2Extension
        .message
    );
  }

  /*
   * أحيانًا تكون الرسالة نفسها
   * هي mediaMessage لكن عليها
   * viewOnceMessage = true.
   */

  return message;
}

/* =========================================================
 * FIND MEDIA
 * ========================================================= */

function getMediaType(message) {
  if (!message) {
    return null;
  }

  const supported = [
    'imageMessage',
    'videoMessage',
    'audioMessage'
  ];

  for (
    const type
    of supported
  ) {
    if (message[type]) {
      return type;
    }
  }

  return null;
}

/* =========================================================
 * DOWNLOAD
 * ========================================================= */

async function downloadMedia(
  sock,
  mediaType,
  mediaMessage
) {
  /*
   * نستخدم downloadMediaMessage
   * بالطريقة المتوافقة مع Baileys.
   */

  return downloadMediaMessage(
    {
      message: {
        [mediaType]:
          mediaMessage
      }
    },
    'buffer',
    {},
    {
      logger: console,

      reuploadRequest:
        sock.updateMediaMessage
    }
  );
}

/* =========================================================
 * COMMAND
 * ========================================================= */

export default {
  name: 'عرض',

  aliases: [
    'ع',
    'عرض',
    'viewonce',
    'view-once'
  ],

  category: 'وسائط',

  requiredRole: 'user',

  async execute(ctx) {
    const {
      message,
      sock
    } = ctx;

    if (
      !message?.chatId ||
      !sock
    ) {
      return false;
    }

    try {
      /* ===================================================
       * استخراج الرسالة المقتبس منها
       * =================================================== */

      const quoted =
        getQuotedMessage(
          message
        );

      if (!quoted) {
        await message.reply(
          '⚠️ *الرجاء الرد على صورة أو فيديو أو صوت View Once بالأمر:*\n\n' +
          '`.ع`'
        );

        return true;
      }

      /* ===================================================
       * إزالة غلاف View Once
       * =================================================== */

      const target =
        unwrapViewOnce(
          quoted
        );

      if (!target) {
        await message.reply(
          '❌ تعذر قراءة رسالة View Once.'
        );

        return true;
      }

      /* ===================================================
       * معرفة نوع الوسائط
       * =================================================== */

      const mediaType =
        getMediaType(
          target
        );

      if (!mediaType) {
        await message.reply(
          '❌ الرسالة التي ترد عليها ليست صورة أو فيديو أو صوت.'
        );

        return true;
      }

      /* ===================================================
       * تحميل الوسائط
       * =================================================== */

      await message.react?.(
        '⏳'
      ).catch?.(
        () => {}
      );

      const media =
        target[
          mediaType
        ];

      const buffer =
        await downloadMedia(
          sock,
          mediaType,
          media
        );

      if (
        !Buffer.isBuffer(
          buffer
        ) ||
        !buffer.length
      ) {
        throw new Error(
          'تعذر تحميل الوسائط.'
        );
      }

      /* ===================================================
       * إعادة إرسال الصورة
       * =================================================== */

      if (
        mediaType ===
        'imageMessage'
      ) {
        await message.reply({
          image:
            buffer,

          caption:
            media.caption ||
            ''
        });

        await message.react?.(
          '✅'
        ).catch?.(
          () => {}
        );

        return true;
      }

      /* ===================================================
       * إعادة إرسال الفيديو
       * =================================================== */

      if (
        mediaType ===
        'videoMessage'
      ) {
        await message.reply({
          video:
            buffer,

          mimetype:
            media.mimetype ||
            'video/mp4',

          caption:
            media.caption ||
            ''
        });

        await message.react?.(
          '✅'
        ).catch?.(
          () => {}
        );

        return true;
      }

      /* ===================================================
       * إعادة إرسال الصوت
       * =================================================== */

      if (
        mediaType ===
        'audioMessage'
      ) {
        const isVoiceNote =
          Boolean(
            media.ptt
          );

        await message.reply({
          audio:
            buffer,

          mimetype:
            isVoiceNote
              ? 'audio/ogg; codecs=opus'
              : (
                  media.mimetype ||
                  'audio/mp4'
                ),

          ptt:
            isVoiceNote
        });

        await message.react?.(
          '✅'
        ).catch?.(
          () => {}
        );

        return true;
      }

      return true;

    } catch (error) {
      console.error(
        '[عرض / VIEW-ONCE]',
        error
      );

      await message.react?.(
        '❌'
      ).catch?.(
        () => {}
      );

      await message.reply(
        [
          '❌ *تعذر عرض الوسائط.*',
          '',
          `السبب: ${
            error?.message ||
            'خطأ غير معروف'
          }`
        ].join('\n')
      );

      return true;
    }
  }
};