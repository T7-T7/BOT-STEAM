import fs from 'fs/promises';
import path from 'path';

import { get } from '../heart/registry.js';

import { isSensitivePath } from './system-files.js';

const ROOT = path.resolve('.');

const PROTECTED_COMMANDS = new Set([
  'd',
  'e',
  'o',
  'مطور',
  'برا'
]);

function normalize(value) {
  return String(value || '')
    .trim()
    .toLowerCase();
}

function normalizeRole(role) {
  const value = normalize(role);

  if (
    value === 'user' ||
    value === 'elite' ||
    value === 'developer'
  ) {
    return value;
  }

  return null;
}

function insideRoot(file) {
  const absolute = path.resolve(file);

  return (
    absolute === ROOT ||
    absolute.startsWith(`${ROOT}${path.sep}`)
  );
}

/*
 * إيجاد أزواج الأقواس مع تجاهل:
 * - strings
 * - comments
 */
function bracePairs(source) {
  const stack = [];
  const pairs = new Map();

  let mode = 'code';
  let quote = '';
  let escaped = false;

  for (let i = 0; i < source.length; i += 1) {
    const ch = source[i];
    const next = source[i + 1];

    if (mode === 'line-comment') {
      if (ch === '\n') {
        mode = 'code';
      }

      continue;
    }

    if (mode === 'block-comment') {
      if (ch === '*' && next === '/') {
        mode = 'code';
        i += 1;
      }

      continue;
    }

    if (mode === 'string') {
      if (escaped) {
        escaped = false;
        continue;
      }

      if (ch === '\\') {
        escaped = true;
        continue;
      }

      if (ch === quote) {
        mode = 'code';
      }

      continue;
    }

    if (ch === '/' && next === '/') {
      mode = 'line-comment';
      i += 1;
      continue;
    }

    if (ch === '/' && next === '*') {
      mode = 'block-comment';
      i += 1;
      continue;
    }

    if (
      ch === '\'' ||
      ch === '"' ||
      ch === '`'
    ) {
      mode = 'string';
      quote = ch;
      escaped = false;
      continue;
    }

    if (ch === '{') {
      stack.push(i);
      continue;
    }

    if (ch === '}') {
      const open = stack.pop();

      if (open !== undefined) {
        pairs.set(open, i);
      }
    }
  }

  return pairs;
}

function findCommandObject(
  source,
  commandName
) {
  const wanted = normalize(
    commandName
  );

  const nameRe =
    /\bname\s*:\s*(['"`])([^'"`]+)\1/gu;

  const pairs =
    bracePairs(source);

  let match;

  while (
    (match =
      nameRe.exec(source))
  ) {
    if (
      normalize(match[2]) !==
      wanted
    ) {
      continue;
    }

    const nameIndex =
      match.index;

    let objectStart = -1;
    let objectEnd = -1;

    for (
      const [open, close]
      of pairs
    ) {
      if (
        open < nameIndex &&
        nameIndex < close &&
        open > objectStart
      ) {
        objectStart = open;
        objectEnd = close;
      }
    }

    if (
      objectStart !== -1
    ) {
      return {
        objectStart,
        objectEnd,
        nameStart: match.index,
        nameEnd: nameRe.lastIndex
      };
    }
  }

  return null;
}

function readRequiredRole(
  source,
  object
) {
  const objectSource =
    source.slice(
      object.objectStart,
      object.objectEnd + 1
    );

  return (
    objectSource.match(
      /\brequiredRole\s*:\s*(['"`])(user|elite|developer)\1/iu
    )?.[2]?.toLowerCase() ||
    null
  );
}

function updateRequiredRole(
  source,
  object,
  role
) {
  const objectSource =
    source.slice(
      object.objectStart,
      object.objectEnd + 1
    );

  const roleRe =
    /\brequiredRole\s*:\s*(['"`])(?:user|elite|developer)\1/iu;

  const existing =
    roleRe.exec(objectSource);

  /*
   * requiredRole موجود بالفعل
   */
  if (existing) {
    const absoluteStart =
      object.objectStart +
      existing.index;

    const absoluteEnd =
      absoluteStart +
      existing[0].length;

    const quote =
      existing[1];

    return (
      source.slice(
        0,
        absoluteStart
      ) +
      `requiredRole: ${quote}${role}${quote}` +
      source.slice(
        absoluteEnd
      )
    );
  }

  /*
   * requiredRole غير موجود.
   * نضيفه بعد name.
   */
  const nameLineEnd =
    source.indexOf(
      '\n',
      object.nameEnd
    );

  const insertAt =
    nameLineEnd === -1
      ? object.nameEnd
      : nameLineEnd + 1;

  const lineIndent =
    source
      .slice(
        0,
        object.nameStart
      )
      .match(
        /(^|\n)([ \t]*)[^\n]*$/u
      )?.[2] ??
    '  ';

  return (
    source.slice(
      0,
      insertAt
    ) +
    `${lineIndent}requiredRole: '${role}',\n` +
    source.slice(
      insertAt
    )
  );
}

function assertEditableCommand(
  command
) {
  if (!command) {
    throw new Error(
      'الأمر غير موجود.'
    );
  }

  if (
    PROTECTED_COMMANDS.has(
      normalize(command.name)
    )
  ) {
    throw new Error(
      'لا يمكن تغيير صلاحية أوامر إدارة الصلاحيات نفسها.'
    );
  }

  const file =
    path.resolve(
      command.file || ''
    );

  if (
    !insideRoot(file)
  ) {
    throw new Error(
      'ملف الأمر خارج مجلد البوت.'
    );
  }

  const relative =
    path
      .relative(
        ROOT,
        file
      )
      .replaceAll(
        path.sep,
        '/'
      );

  if (
    !relative ||
    isSensitivePath(relative)
  ) {
    throw new Error(
      'ملف الأمر محمي ولا يمكن تعديل صلاحيته.'
    );
  }

  if (
    !file.endsWith('.js')
  ) {
    throw new Error(
      'ملف الأمر ليس JavaScript.'
    );
  }

  return {
    file,
    relative
  };
}

async function updateSingleCommand(
  command,
  role
) {
  const {
    file,
    relative
  } =
    assertEditableCommand(
      command
    );

  const source =
    await fs.readFile(
      file,
      'utf8'
    );

  const object =
    findCommandObject(
      source,
      command.name
    );

  if (!object) {
    throw new Error(
      `تعذر تحديد تعريف الأمر "${command.name}" داخل الملف.`
    );
  }

  const previousRole =
    readRequiredRole(
      source,
      object
    ) ||
    normalize(
      command.requiredRole
    ) ||
    'user';

  const nextSource =
    updateRequiredRole(
      source,
      object,
      role
    );

  /*
   * لم يحدث تغيير.
   */
  if (
    nextSource === source
  ) {
    return {
      type: 'command',
      changed: false,
      command: command.name,
      role,
      previousRole,
      file: relative,
      count: 1
    };
  }

  await fs.writeFile(
    file,
    nextSource,
    'utf8'
  );

  /*
   * مهم جدًا:
   * type: 'command'
   *
   * هذا هو الإصلاح الرئيسي
   * للرسالة:
   * "نوع نتيجة غير معروف"
   */
  return {
    type: 'command',
    changed: true,
    command: command.name,
    role,
    previousRole,
    file: relative,
    count: 1
  };
}

export async function setCommandRole(
  commandName,
  role
) {
  const normalizedRole =
    normalizeRole(role);

  if (!normalizedRole) {
    throw new Error(
      'الصلاحية المطلوبة غير صالحة.'
    );
  }

  const input =
    String(
      commandName || ''
    ).trim();

  if (!input) {
    throw new Error(
      'يجب تحديد اسم الأمر.'
    );
  }

  /*
   * هنا يتم البحث عن الأمر فقط.
   * لا يوجد أي تعامل مع الأقسام.
   */
  const command =
    get(input);

  if (!command) {
    throw new Error(
      `الأمر "${input}" غير موجود.`
    );
  }

  if (
    PROTECTED_COMMANDS.has(
      normalize(command.name)
    ) ||
    PROTECTED_COMMANDS.has(
      normalize(input)
    )
  ) {
    throw new Error(
      'لا يمكن تغيير صلاحية أوامر إدارة الصلاحيات نفسها.'
    );
  }

  const change =
    await updateSingleCommand(
      command,
      normalizedRole
    );

  /*
   * لا توجد إعادة تحميل تلقائية.
   * التعديل يُحفظ داخل ملف الأمر نفسه،
   * ويصبح فعالًا بعد إعادة تشغيل البوت يدويًا.
   */
  return change;
}