import { read, write } from '../database/index.js';
import config from '../config.js';

let usyncClassesPromise = null;

async function getUSyncClasses() {
  if (!usyncClassesPromise) {
    usyncClassesPromise = (async () => {
      try {
        const mod = await import('@sgintokic/baileys');
        if (mod?.USyncQuery && mod?.USyncUser) return mod;
      } catch {}

      // Backward-compatible fallback when the fork is not installed.
      try {
        const mod = await import('@whiskeysockets/baileys');
        if (mod?.USyncQuery && mod?.USyncUser) return mod;
      } catch {}

      return null;
    })();
  }
  return usyncClassesPromise;
}

function normalizeNumber(value) {
  return String(value || '').replace(/\D/g, '');
}

function normalizeJid(value) {
  if (!value) return '';
  const raw = String(value).trim();
  if (!raw) return '';
  if (/^\d+$/.test(raw)) return `${raw}@s.whatsapp.net`;
  const at = raw.indexOf('@');
  if (at > 0) {
    const user = raw.slice(0, at).split(':')[0];
    const server = raw.slice(at + 1);
    if (server === 'c.us') return `${user}@s.whatsapp.net`;
    return `${user}@${server}`;
  }
  return raw;
}

function isPn(value) {
  return String(value || '').endsWith('@s.whatsapp.net');
}

function isLid(value) {
  return String(value || '').endsWith('@lid');
}

function normalizeList(value) {
  return (Array.isArray(value) ? value : [])
    .map(item => typeof item === 'string'
      ? { number: normalizeNumber(item), type: 'number' }
      : { number: normalizeNumber(item?.number), type: item?.type || 'number' })
    .filter(item => item.number);
}

function configuredLists() {
  const main = [
    ...normalizeList(config.mainOwners),
    ...normalizeList(config.developers)
  ];
  const owners = normalizeList(config.owners);

  const unique = list => {
    const seen = new Set();
    return list.filter(item => {
      if (seen.has(item.number)) return false;
      seen.add(item.number);
      return true;
    });
  };

  return { mainOwners: unique(main), owners: unique(owners) };
}

class OwnerService {
  constructor() {
    this._resolving = false;
    this._gintoki = null;
    this._records = new Map();
    this._loaded = false;
    this._saveTimer = null;
    this._dirty = false;
  }

  async init(gintoki) {
    if (gintoki) this._gintoki = gintoki;
    await this._load();

    const { mainOwners, owners } = configuredLists();
    const pending = [
      ...mainOwners.map(owner => ({ ...owner, isMain: true })),
      ...owners.map(owner => ({ ...owner, isMain: false }))
    ].filter(owner => !this._hasChecked(owner.number, owner.isMain));

    if (!pending.length || !this._gintoki) return;
    await this._resolvePending(pending);
  }

  setSocket(gintoki) {
    this._gintoki = gintoki || null;
  }

  async _load() {
    if (this._loaded) return;
    this._loaded = true;
    const data = await read('owners.json', {});
    for (const [jid, record] of Object.entries(data || {})) {
      if (jid && record && typeof record === 'object') {
        this._records.set(jid, record);
      }
    }
  }

  _scheduleSave() {
    this._dirty = true;
    if (this._saveTimer) return;
    this._saveTimer = setTimeout(async () => {
      this._saveTimer = null;
      if (!this._dirty) return;
      this._dirty = false;
      try {
        await write('owners.json', Object.fromEntries(this._records));
      } catch (error) {
        this._dirty = true;
        console.error('[OwnerService] SAVE ERROR:', error);
      }
    }, 250);
    this._saveTimer.unref?.();
  }

  _hasChecked(number, isMain) {
    const pn = `${normalizeNumber(number)}@s.whatsapp.net`;
    for (const [jid, rec] of this._records) {
      if (!rec?.checked || Boolean(rec.isMain) !== Boolean(isMain)) continue;
      if (jid === pn || rec.pn === pn) return true;
    }
    return false;
  }

  async _checkWhatsApp(pnJid) {
    const gintoki = this._gintoki;
    if (!gintoki || typeof gintoki.onWhatsApp !== 'function') return null;
    try {
      const result = await gintoki.onWhatsApp(pnJid);
      if (!Array.isArray(result) || !result.length) return false;
      const entry = result.find(x => x?.jid === pnJid) || result[0];
      return entry ? { exists: entry.exists === true, jid: entry.jid || pnJid } : false;
    } catch (error) {
      console.error('[OwnerService] onWhatsApp ERROR:', error);
      return null;
    }
  }

  async _resolveLidFromPn(pnJid) {
    const gintoki = this._gintoki;
    if (!gintoki || typeof gintoki.executeUSyncQuery !== 'function') return null;

    const classes = await getUSyncClasses();
    if (!classes) {
      console.error('[OwnerService] USyncQuery/USyncUser غير متاحين. ثبّت @sgintokic/baileys أو استخدم نسخة تدعم USync.');
      return null;
    }

    try {
      const { USyncQuery, USyncUser } = classes;
      const q = new USyncQuery().withLIDProtocol();
      q.withUser(new USyncUser().withId(pnJid));
      const res = await gintoki.executeUSyncQuery(q);
      const entry = res?.list?.find(item => item?.id === pnJid) || res?.list?.[0];
      return entry?.lid || null;
    } catch (error) {
      console.error('[OwnerService] USync ERROR:', error);
      return null;
    }
  }

  _removePnRecords(pn, keepJid = null) {
    let changed = false;
    for (const [jid, rec] of this._records) {
      if (jid === keepJid) continue;
      if (jid === pn || rec?.pn === pn) {
        this._records.delete(jid);
        changed = true;
      }
    }
    return changed;
  }

  async _processOwner(owner) {
    const digits = normalizeNumber(owner.number);
    if (!digits) return;
    const pn = `${digits}@s.whatsapp.net`;
    const wa = await this._checkWhatsApp(pn);
    if (wa === null) return;

    if (!wa.exists) {
      this._removePnRecords(pn);
      this._records.set(pn, {
        isMain: Boolean(owner.isMain),
        checked: true,
        exists: false,
        type: 'pn',
        pn,
        addedAt: this._records.get(pn)?.addedAt || Date.now()
      });
      this._scheduleSave();
      return;
    }

    const lid = await this._resolveLidFromPn(pn);
    if (!lid) return;

    const oldRecord = this._records.get(lid)
      || [...this._records.values()].find(rec => rec?.pn === pn)
      || {};

    this._removePnRecords(pn, lid);
    this._records.set(lid, {
      ...oldRecord,
      ...this._records.get(lid),
      isMain: Boolean(owner.isMain),
      checked: true,
      exists: true,
      type: 'lid',
      pn,
      lid,
      addedAt: oldRecord.addedAt || Date.now()
    });
    this._scheduleSave();
  }

  async _resolvePending(pending) {
    if (this._resolving) return;
    this._resolving = true;
    try {
      for (const owner of pending) {
        try {
          await this._processOwner(owner);
        } catch (error) {
          console.error('[OwnerService] PROCESS ERROR:', owner, error);
        }
      }
    } finally {
      this._resolving = false;
    }
  }

  _triggerBackgroundCheck() {
    if (this._resolving || !this._gintoki) return;
    const { mainOwners, owners } = configuredLists();
    const pending = [
      ...mainOwners.map(owner => ({ ...owner, isMain: true })),
      ...owners.map(owner => ({ ...owner, isMain: false }))
    ].filter(owner => !this._hasChecked(owner.number, owner.isMain));
    if (pending.length) void this._resolvePending(pending);
  }

  _recordFor(senderId) {
    const normalized = normalizeJid(senderId);
    if (!normalized) return null;
    const direct = this._records.get(normalized);
    if (direct) return direct;

    const numberValue = normalizeNumber(normalized);
    if (!numberValue) return null;
    for (const record of this._records.values()) {
      if (normalizeNumber(record?.pn) === numberValue) return record;
    }
    return null;
  }

  isMainOwner(senderId) {
    const normalized = normalizeJid(senderId);
    if (!normalized) return false;

    const botLid = normalizeJid(this._gintoki?.user?.lid);
    if (botLid && normalized === botLid) return true;

    const record = this._recordFor(normalized);
    if (record?.isMain && record.checked && record.exists !== false) return true;

    const numberValue = normalizeNumber(normalized);
    if (numberValue && configuredLists().mainOwners.some(x => x.number === numberValue)) {
      this._triggerBackgroundCheck();
      return true;
    }

    this._triggerBackgroundCheck();
    return false;
  }

  isOwner(senderId) {
    if (this.isMainOwner(senderId)) return true;
    const record = this._recordFor(senderId);
    if (record?.checked && record.exists !== false) return true;

    const numberValue = normalizeNumber(senderId);
    if (numberValue && configuredLists().owners.some(x => x.number === numberValue)) {
      this._triggerBackgroundCheck();
      return true;
    }

    return false;
  }

  resolve(id) {
    const normalized = normalizeJid(id);
    if (!normalized) return '';
    if (isLid(normalized)) {
      return this._records.get(normalized)?.pn || normalized;
    }
    return normalized;
  }

  number(id) {
    return normalizeNumber(this.resolve(id));
  }

  lidOf(id) {
    const normalized = normalizeJid(id);
    if (!normalized) return '';
    if (isLid(normalized)) return normalized;
    for (const [lid, record] of this._records) {
      if (record?.pn === normalized) return lid;
    }
    return '';
  }

  register(first, second) {
    const a = normalizeJid(first);
    const b = normalizeJid(second);
    if (!a || !b || a === b) return false;

    let pn = '';
    let lid = '';
    if (isPn(a) && isLid(b)) [pn, lid] = [a, b];
    else if (isLid(a) && isPn(b)) [pn, lid] = [b, a];
    else return false;

    for (const [existingLid, record] of this._records) {
      if (existingLid !== lid && record?.pn === pn) this._records.delete(existingLid);
    }
    for (const [existingJid, record] of this._records) {
      if (existingJid !== lid && existingJid !== pn && record?.lid === lid) this._records.delete(existingJid);
    }

    const current = this._records.get(lid) || this._records.get(pn) || {};
    this._records.set(lid, {
      ...current,
      pn,
      lid,
      type: 'lid',
      checked: current.checked ?? true,
      exists: current.exists ?? true,
      addedAt: current.addedAt || Date.now()
    });
    this._records.delete(pn);
    this._scheduleSave();
    return true;
  }

  clear() {
    this._records.clear();
    this._loaded = false;
  }
}

export const ownerService = new OwnerService();
export default ownerService;
