import fs from 'fs/promises';
import path from 'path';

const ROOT = path.resolve('.');

const SENSITIVE_NAMES = new Set([
  'session', '.git', '.npm', 'node_modules',
  '.env', '.env.local', '.env.production', '.env.development', '.npmrc',
  'credentials.json', 'credentials.json5', 'token.json', 'tokens.json',
  'secrets.json', 'secret.json', 'private.key', 'private.pem',
  'identity.json', 'identities.json', 'auth_info_multi.json', 'creds.json',
  'service-account.json', 'serviceaccountkey.json',
  // Owner/elite data contains bot identity information and must not be exposed
  // through system file browsing/deletion.
  'owners.json', 'elite.json'
]);

const SENSITIVE_EXTENSIONS = new Set(['.pem', '.key', '.p12', '.pfx', '.crt', '.cer', '.der']);
const SENSITIVE_PARTS = ['session', 'secret', 'credential', 'token', 'private-key', 'private_key', 'auth-info', 'auth_info', 'identity'];

const PROJECT_PACK_EXCLUDED = new Set([
  'node_modules', '.git', '.npm', 'session', 'plugins', '.cache', 'coverage',
  'proto.json'
]);

function normalizeRel(value) {
  return String(value || '').replaceAll(path.sep, '/').replace(/^\.\//, '');
}

export function isProjectPackExcluded(relativePath) {
  const rel = normalizeRel(relativePath);
  if (!rel) return false;
  const parts = rel.split('/').filter(Boolean);
  if (parts.some(part => PROJECT_PACK_EXCLUDED.has(part))) return true;
  if (rel.endsWith('.zip') || rel.endsWith('.tmp')) return true;
  return false;
}

export function isSensitivePath(relativePath) {
  const rel = normalizeRel(relativePath);
  if (!rel) return false;
  for (const part of rel.split('/').filter(Boolean)) {
    const lower = part.toLowerCase();
    if (SENSITIVE_NAMES.has(lower)) return true;
    if (SENSITIVE_EXTENSIONS.has(path.extname(lower))) return true;
    if (SENSITIVE_PARTS.some(x => lower.includes(x))) return true;
  }
  return false;
}

export async function walkProject() {
  const files = [];
  const dirs = [];

  async function walk(abs, rel = '') {
    let list;
    try { list = await fs.readdir(abs, { withFileTypes: true }); } catch { return; }
    list.sort((a, b) => a.name.localeCompare(b.name));
    for (const entry of list) {
      const childRel = normalizeRel(path.join(rel, entry.name));
      if (isSensitivePath(childRel)) continue;
      const childAbs = path.join(abs, entry.name);
      if (entry.isDirectory()) {
        dirs.push(childRel);
        await walk(childAbs, childRel);
      } else if (entry.isFile()) {
        files.push(childRel);
      }
    }
  }

  await walk(ROOT);
  return { files, dirs };
}

async function dependencyTree(abs, seen = new Set()) {
  const rel = normalizeRel(path.relative(ROOT, abs));
  if (!rel || isSensitivePath(rel) || seen.has(rel)) return seen;
  seen.add(rel);

  let source;
  try { source = await fs.readFile(abs, 'utf8'); } catch { return seen; }

  const re = /(?:import\s+(?:[\s\S]*?\s+from\s+)?|export\s+[\s\S]*?\s+from\s+|import\s*\()(['"])(\.\.?\/[^'"\n]+)\1/g;
  let match;
  while ((match = re.exec(source))) {
    const base = path.resolve(path.dirname(abs), match[2]);
    const candidates = [base, `${base}.js`, `${base}.mjs`, `${base}.json`, path.join(base, 'index.js')];
    for (const candidate of candidates) {
      if (!candidate.startsWith(ROOT + path.sep)) continue;
      try {
        const stat = await fs.stat(candidate);
        if (!stat.isFile()) continue;
        const depRel = normalizeRel(path.relative(ROOT, candidate));
        if (!isSensitivePath(depRel)) await dependencyTree(candidate, seen);
        break;
      } catch {}
    }
  }
  return seen;
}

export async function commandDependencyFiles(commandFile) {
  const rel = normalizeRel(commandFile);
  if (!rel || isSensitivePath(rel)) return [];
  const abs = path.resolve(ROOT, rel);
  if (!abs.startsWith(ROOT + path.sep)) return [];
  return [...await dependencyTree(abs)];
}

export async function readSafeFile(relativePath) {
  const rel = normalizeRel(relativePath);
  if (!rel || isSensitivePath(rel)) throw new Error('هذا الملف محمي ولا يمكن عرضه.');
  const abs = path.resolve(ROOT, rel);
  if (!abs.startsWith(ROOT + path.sep)) throw new Error('مسار الملف غير صالح.');
  return fs.readFile(abs);
}
