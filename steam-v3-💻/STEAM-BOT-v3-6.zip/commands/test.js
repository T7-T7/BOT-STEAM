import { sendInteractive, urlButton } from '../services/interactive.js';
import config from '../config.js';

export default {
  name: 'تست',
  aliases: ['test'],
  category: 'عام',
  requiredRole: 'user',
  async execute({ message, sock }) {
    const started = Date.now();
    await message.react('🧪').catch(() => {});
    const elapsed = Date.now() - started;

    try {
      await sendInteractive(sock, message.chatId, {
        text:
          `┊⌔💾︙ النظام : *يعمل بنجاح*\n` +
          `┊⌔⏱️︙ زمن الإستجابة : *${elapsed}ms*`,
        title: '⚜️ *S T E A M B O T ♖*',
        footer: '𓂃 ࣪˖ ִֶָ⚜️ 𝑺𝑻𝑬𝑨𝑴 𝑩𝑶𝑻 ♖ ִֶָ ˖ ࣪',
        buttons: [
          urlButton('عرض القناة', config.testChannel)
        ],
        quoted: message.raw
      });
    } catch {
      await message.reply(
        `┊⌔💾︙ النظام : *يعمل بنجاح*\n` +
        `┊⌔⏱️︙ زمن الإستجابة : *${elapsed}ms*\n\n` +
        `عرض القناة :\n${config.testChannel}`
      );
    }
  }
};