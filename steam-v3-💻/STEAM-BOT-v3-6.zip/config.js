const csv = value => String(value || '')
  .split(',')
  .map(x => x.trim().replace(/\D/g, ''))
  .filter(Boolean);

const envDevelopers = csv(process.env.DEVELOPERS);
const envMainOwners = csv(process.env.MAIN_OWNERS);
const envOwners = csv(process.env.OWNERS);
const developers = [...new Set([...envDevelopers, ...envMainOwners])];

const config = {
  name: 'STEAM BOT v3',
  version: '2.0.0',
  prefix: '.',
  sessionDir: './session',
  dataDir: './data',
  developers,
  mainOwners: [...new Set([...envMainOwners, ...developers])],
  owners: [...new Set(envOwners)],
  behaviour: { autoRead: false },
  pairing: { phoneNumber: process.env.PHONE_NUMBER || '' },
  console: { enabled: true },
  database: { saveInterval: 10000 },
  limits: {
    maxPendingMessages: 128,
    maxMediaBytes: 64 * 1024 * 1024,
    maxAudioDuration: 15 * 60,
    maxVideoDuration: 30 * 60,
    maxYoutubeDownloadSeconds: 300_000
  },
  testChannel: 'https://whatsapp.com/channel/0029Vb82GRL0AgW61X3c3d0M'
};

export const cfg = config;
export default config;
