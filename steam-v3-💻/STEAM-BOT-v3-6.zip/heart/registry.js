import fs from 'fs/promises';
import path from 'path';
import { pathToFileURL } from 'url';
import { normalizeRole } from '../security/roles.js';

const registry = new Map();
const commandSources = new Map();

function normalizeName(value) {
  return String(value || '')
    .trim()
    .toLowerCase();
}

function normalizeCommand(command, file) {
  if (!command || typeof command !== 'object') return null;
  if (!command.name || typeof command.execute !== 'function') return null;

  const requiredRole = normalizeRole(command.requiredRole || 'user');

  if (!requiredRole) {
    console.error(
      `[COMMAND LOAD] ${file}: invalid requiredRole for ${command.name}`
    );
    return null;
  }

  return {
    ...command,
    requiredRole,
    aliases: Array.isArray(command.aliases)
      ? command.aliases.filter(Boolean)
      : [],
    file
  };
}

function registerKey(key, command, file) {
  const normalized = normalizeName(key);
  if (!normalized) return true;

  const existing = registry.get(normalized);

  if (existing) {
    if (existing.name === command.name && existing.file === file) {
      return true;
    }

    console.error(
      `[COMMAND COLLISION] "${key}" already belongs to "${existing.name}" (${existing.file}); skipped "${command.name}" (${file}).`
    );
    return false;
  }

  registry.set(normalized, command);
  commandSources.set(normalized, file);
  return true;
}

function registerCommand(command, file) {
  const normalized = normalizeCommand(command, file);
  if (!normalized) return false;

  const keys = [...new Set([normalized.name, ...normalized.aliases].map(normalizeName).filter(Boolean))];
  const collisions = keys.filter(key => {
    const existing = registry.get(key);
    return existing && !(existing.name === normalized.name && existing.file === file);
  });

  if (collisions.length) {
    console.error(`[COMMAND COLLISION] ${file} skipped completely; conflicts: ${collisions.join(', ')}`);
    return false;
  }

  for (const key of keys) {
    registry.set(key, normalized);
    commandSources.set(key, file);
  }
  return true;
}

export function list() {
  return [
    ...new Map(
      [...registry.values()].map(command => [command.name, command])
    ).values()
  ].map(command => command.name);
}

export function entries() {
  return [
    ...new Map(
      [...registry.values()].map(command => [command.name, command])
    ).values()
  ];
}

export function get(name) {
  return registry.get(
    normalizeName(name)
  );
}

export function clear() {
  registry.clear();
  commandSources.clear();
}

export async function loadCommands(dir = './commands') {
  clear();
  const errors = [];
  await scan(path.resolve(dir), errors);
  await scan(path.resolve('./plugins'), errors);
  return { names: list(), errors };
}

async function scan(dir, errors = []) {
  let files;

  try {
    files = await fs.readdir(dir, { withFileTypes: true });
  } catch (error) {
    console.error(`[COMMAND SCAN] ${dir}:`, error?.message || error);
    return;
  }

  files.sort((a, b) => a.name.localeCompare(b.name));

  for (const entry of files) {
    const fullPath = path.join(dir, entry.name);

    if (entry.isDirectory()) {
      await scan(fullPath, errors);
      continue;
    }

    if (
      entry.isFile() &&
      entry.name.endsWith('.js') &&
      !entry.name.startsWith('_')
    ) {
      await loadOne(fullPath, errors);
    }
  }
}

async function loadOne(file, errors = []) {
  try {
    const mod = await import(
      `${pathToFileURL(file).href}?v=${Date.now()}`
    );

    const exported = mod.default;
    if (!exported) return;

    if (Array.isArray(exported.commands)) {
      for (const command of exported.commands) {
        registerCommand(command, file);
      }
      return;
    }

    registerCommand(exported, file);
  } catch (error) {
    const message = error?.message || String(error);
    errors.push({ file, error: message });
    console.error(`[COMMAND LOAD] ${file}:`, message);
  }
}
