import fs from 'fs/promises';
import os from 'os';
import path from 'path';
import { execFile } from 'child_process';
import { promisify } from 'util';

const exec = promisify(execFile);

const ROOT = path.resolve('.');

let activePack = null;

/* =========================================================
 * RELEASE EXCLUSIONS
 * ========================================================= */

const EXCLUDED_NAMES = new Set([
  'node_modules',
  '.npm',
  '.git',
  '.cache',
  'cache',
  'coverage',
  'session',
  '.session',
  'tmp',
  'temp',
  '.tmp',
  '.temp'
]);

const RESET_DATA_NAMES = new Set([
  'owners.json',
  'elite.json',
  'group-backups.json',
  'settings.json'
]);

const RESET_DATA_DIRECTORIES = new Set([
  'archives'
]);

const EXCLUDED_EXTENSIONS = new Set([
  '.zip',
  '.tar',
  '.gz',
  '.tgz',
  '.tar.gz',
  '.rar',
  '.7z',
  '.tmp',
  '.bak',
  '.log'
]);

const EXCLUDED_FILES = new Set([
  '.env',
  '.env.local',
  '.env.production',
  '.env.development',
  '.DS_Store',
  'Thumbs.db',
  'npm-debug.log',
  'yarn-debug.log',
  'yarn-error.log'
]);

/* =========================================================
 * DEFAULT DATA
 * ========================================================= */

const DEFAULT_SETTINGS = {
  mode: 'public',
  console: true,
  bot: 'user'
};

const DEFAULT_OWNERS = {};
const DEFAULT_ELITE = [];
const DEFAULT_GROUP_BACKUPS = {};

/* =========================================================
 * ENV FILE CONTENT
 * ========================================================= */

const ENV_EXAMPLE = `DEVELOPERS=
`;

/* =========================================================
 * PATH HELPERS
 * ========================================================= */

function normalizeRelative(relativePath) {
  return String(relativePath || '')
    .replace(/\\/g, '/')
    .replace(/^\.\/+/, '');
}

function isExcludedName(name) {
  return EXCLUDED_NAMES.has(
    String(name || '').toLowerCase()
  );
}

function isExcludedFile(fileName) {
  const name = String(fileName || '');

  if (EXCLUDED_FILES.has(name)) {
    return true;
  }

  const lower = name.toLowerCase();

  for (const extension of EXCLUDED_EXTENSIONS) {
    if (lower.endsWith(extension)) {
      return true;
    }
  }

  return false;
}

function isArchiveFile(fileName) {
  const lower =
    String(fileName || '').toLowerCase();

  return (
    lower.endsWith('.zip') ||
    lower.endsWith('.tar') ||
    lower.endsWith('.tar.gz') ||
    lower.endsWith('.tgz') ||
    lower.endsWith('.rar') ||
    lower.endsWith('.7z')
  );
}

/* =========================================================
 * SHOULD COPY
 * ========================================================= */

function shouldCopy(relativePath, entry) {
  const rel =
    normalizeRelative(relativePath);

  if (!rel) {
    return true;
  }

  const parts =
    rel.split('/').filter(Boolean);

  if (!parts.length) {
    return true;
  }

  const first = parts[0];

  if (isExcludedName(first)) {
    return false;
  }

  if (
    entry?.isFile?.() &&
    isExcludedFile(entry.name)
  ) {
    return false;
  }

  if (
    entry?.isFile?.() &&
    isArchiveFile(entry.name)
  ) {
    return false;
  }

  if (first === 'data') {
    return false;
  }

  if (
    entry?.isFile?.() &&
    (
      entry.name.startsWith('steam-clean-') ||
      entry.name.startsWith('steam-project-')
    )
  ) {
    return false;
  }

  return true;
}

/* =========================================================
 * WRITE JSON
 * ========================================================= */

async function writeJson(file, value) {
  await fs.mkdir(
    path.dirname(file),
    {
      recursive: true
    }
  );

  await fs.writeFile(
    file,
    JSON.stringify(
      value,
      null,
      2
    ) + '\n',
    'utf8'
  );
}

/* =========================================================
 * BUILD FRESH DATA
 * ========================================================= */

async function createFreshData(destination) {
  const dataDir =
    path.join(
      destination,
      'data'
    );

  await fs.mkdir(
    dataDir,
    {
      recursive: true
    }
  );

  await writeJson(
    path.join(
      dataDir,
      'owners.json'
    ),
    DEFAULT_OWNERS
  );

  await writeJson(
    path.join(
      dataDir,
      'elite.json'
    ),
    DEFAULT_ELITE
  );

  await writeJson(
    path.join(
      dataDir,
      'group-backups.json'
    ),
    DEFAULT_GROUP_BACKUPS
  );

  await writeJson(
    path.join(
      dataDir,
      'settings.json'
    ),
    DEFAULT_SETTINGS
  );

  await fs.mkdir(
    path.join(
      dataDir,
      'archives'
    ),
    {
      recursive: true
    }
  );
}

/* =========================================================
 * CREATE ENV FILE
 * ========================================================= */

async function createEnvFile(destination) {
  const file =
    path.join(
      destination,
      '.env'
    );

  await fs.writeFile(
    file,
    ENV_EXAMPLE,
    'utf8'
  );
}

/* =========================================================
 * CREATE PROJECT ZIP
 * ========================================================= */

export async function createProjectZip() {
  if (activePack) {
    return activePack;
  }

  activePack = (async () => {
    const temporaryDirectory =
      await fs.mkdtemp(
        path.join(
          os.tmpdir(),
          'steam-project-'
        )
      );

    let outputZip = null;

    try {
      await fs.cp(
        ROOT,
        temporaryDirectory,
        {
          recursive: true,

          filter(source) {
            const relativePath =
              path.relative(
                ROOT,
                source
              );

            if (!relativePath) {
              return true;
            }

            const relativeNormalized =
              normalizeRelative(
                relativePath
              );

            const baseName =
              path.basename(source);

            const parts =
              relativeNormalized
                .split('/')
                .filter(Boolean);

            if (
              parts.some(
                part =>
                  isExcludedName(part)
              )
            ) {
              return false;
            }

            if (
              parts[0] === 'data'
            ) {
              return false;
            }

            if (
              isExcludedFile(
                baseName
              )
            ) {
              return false;
            }

            if (
              isArchiveFile(
                baseName
              )
            ) {
              return false;
            }

            if (
              baseName.startsWith(
                'steam-clean-'
              ) ||
              baseName.startsWith(
                'steam-project-'
              )
            ) {
              return false;
            }

            return true;
          }
        }
      );

      await createFreshData(
        temporaryDirectory
      );

      await createEnvFile(
        temporaryDirectory
      );

      outputZip =
        path.join(
          os.tmpdir(),
          `steam-clean-${Date.now()}-${process.pid}.zip`
        );

      await exec(
        'zip',
        [
          '-qr',
          outputZip,
          '.'
        ],
        {
          cwd:
            temporaryDirectory,
          timeout:
            120_000
        }
      );

      const buffer =
        await fs.readFile(
          outputZip
        );

      return buffer;

    } finally {
      await fs.rm(
        temporaryDirectory,
        {
          recursive: true,
          force: true
        }
      ).catch(() => {});

      if (outputZip) {
        await fs.rm(
          outputZip,
          {
            force: true
          }
        ).catch(() => {});
      }
    }
  })();

  try {
    return await activePack;
  } finally {
    activePack = null;
  }
}