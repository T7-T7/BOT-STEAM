'use strict';

import {
  prepareWAMessageMedia,
  generateWAMessageFromContent
} from '@whiskeysockets/baileys';

/* =========================================================
 * CONFIG
 * ========================================================= */

const IMAGE_URL =
  'https://cdn.ornzora.eu.cc/a6a1e8f4-b83d-4694-9bba-0f22a58bfd4f-FIORA.jpg';

const VIDEO_URL =
  'https://cdn.ornzora.eu.cc/ed7ebb66-9bf4-44b6-858a-b6b7405e53c5-FIORA.mp4';

/* =========================================================
 * COMMAND
 * ========================================================= */

export default {
  name: 'فيورا',

  aliases: [
    'فيورا',
    'fiora'
  ],

  category: 'وسائط',

  requiredRole: 'user',

  async execute(ctx) {
    const {
      message,
      sock
    } = ctx;

    if (
      !message?.chatId ||
      !sock
    ) {
      return false;
    }

    try {
      /* ===================================================
       * REACTION
       * =================================================== */

      await message.react?.(
        '⏳'
      ).catch?.(
        () => {}
      );

      /* ===================================================
       * PREPARE IMAGE
       * =================================================== */

      const image =
        await prepareWAMessageMedia(
          {
            image: {
              url: IMAGE_URL
            }
          },
          {
            upload:
              sock.waUploadToServer
          }
        );

      /* ===================================================
       * PREPARE VIDEO
       * =================================================== */

      const video =
        await prepareWAMessageMedia(
          {
            video: {
              url: VIDEO_URL
            }
          },
          {
            upload:
              sock.waUploadToServer
          }
        );

      /* ===================================================
       * CREATE IMAGE MESSAGE
       * =================================================== */

      const imageMessage =
        generateWAMessageFromContent(
          message.chatId,
          {
            imageMessage: {
              ...image.imageMessage,

              contextInfo: {
                pairedMediaType: 5,
                statusSourceType: 0
              }
            }
          },
          {
            userJid:
              sock.user?.id,

            quoted:
              message.raw
          }
        );

      /* ===================================================
       * SEND IMAGE
       * =================================================== */

      await sock.relayMessage(
        message.chatId,
        imageMessage.message,
        {
          messageId:
            imageMessage.key.id
        }
      );

      /* ===================================================
       * SEND PAIRED VIDEO
       * =================================================== */

      await sock.relayMessage(
        message.chatId,
        {
          videoMessage: {
            ...video.videoMessage,

            contextInfo: {
              pairedMediaType: 6,
              statusSourceType: 0
            }
          },

          messageContextInfo: {
            messageAssociation: {
              associationType: 12,

              parentMessageKey:
                imageMessage.key
            }
          }
        },
        {}
      );

      /* ===================================================
       * SUCCESS
       * =================================================== */

      await message.react?.(
        '✅'
      ).catch?.(
        () => {}
      );

      return true;

    } catch (error) {
      console.error(
        '[FIORA]',
        error
      );

      await message.react?.(
        '❌'
      ).catch?.(
        () => {}
      );

      await message.reply(
        [
          '❌ *تعذر إرسال فيورا.*',
          '',
          `السبب: ${
            error?.message ||
            'خطأ غير معروف.'
          }`
        ].join('\n')
      );

      return true;
    }
  }
};