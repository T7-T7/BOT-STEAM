import {
  setCommandRole
} from '../services/command-role.js';

function target(ctx) {
  return String(
    ctx.args?.join(' ') || ''
  ).trim();
}

function roleName(role) {
  if (role === 'developer') {
    return 'المطور';
  }

  if (role === 'elite') {
    return 'النخبة';
  }

  return 'المستخدم';
}

function buildUsage(prefix) {
  return [
    '⚠️ استخدم الأمر بالشكل الصحيح:',
    '',
    `• .${prefix} صوت`,
    `• .${prefix} اوامر`,
    '',
    'أمثلة:',
    '`.d صوت` → مطور',
    '`.e صوت` → نخبة',
    '`.o صوت` → مستخدم'
  ].join('\n');
}

async function change(
  ctx,
  role,
  prefix
) {
  const input =
    target(ctx);

  if (!input) {
    return ctx.message.reply(
      buildUsage(prefix)
    );
  }

  try {
    const result =
      await setCommandRole(
        input,
        role
      );

    /*
     * الأمر كان بالفعل على نفس الصلاحية.
     */
    if (!result.changed) {
      return ctx.message.reply(
        [
          `ℹ️ الأمر *${result.command}* بالفعل بصلاحية *${roleName(role)}*.`,
          '',
          `🔐 الصلاحية الحالية: *${role}*`
        ].join('\n')
      );
    }

    /*
     * نجاح حقيقي.
     */
    return ctx.message.reply(
      [
        '✅ *تم تعديل صلاحية الأمر بنجاح.*',
        '',
        `📌 الأمر: *${result.command}*`,
        `🔐 الصلاحية الجديدة: *${roleName(role)}*`,
        `📄 الملف: *${result.file}*`,
        '',
        '📁 تم تعديل `requiredRole` داخل ملف الأمر نفسه.',
        '🔄 تمت إعادة تحميل Registry وتفعيل التعديل فورًا.'
      ].join('\n')
    );
  } catch (error) {
    /*
     * هنا فقط يظهر ❌ عندما يكون هناك
     * خطأ حقيقي بالفعل.
     */
    return ctx.message.reply(
      [
        '❌ *تعذر تعديل الصلاحية.*',
        '',
        `السبب: ${error?.message || error}`
      ].join('\n')
    );
  }
}

/*
 * =========================================================
 * .d
 *
 * Developer
 * =========================================================
 */

const developerCommand = {
  name: 'd',

  aliases: [
    'd'
  ],

  category: 'نظام',

  requiredRole: 'developer',

  async execute(ctx) {
    return change(
      ctx,
      'developer',
      'd'
    );
  }
};

/*
 * =========================================================
 * .e
 *
 * Elite
 * =========================================================
 */

const eliteCommand = {
  name: 'e',

  aliases: [
    'e'
  ],

  category: 'نظام',

  requiredRole: 'developer',

  async execute(ctx) {
    return change(
      ctx,
      'elite',
      'e'
    );
  }
};

/*
 * =========================================================
 * .o
 *
 * User
 * =========================================================
 */

const userCommand = {
  name: 'o',

  aliases: [
    'o'
  ],

  category: 'نظام',

  requiredRole: 'developer',

  async execute(ctx) {
    return change(
      ctx,
      'user',
      'o'
    );
  }
};

export default {
  commands: [
    developerCommand,
    eliteCommand,
    userCommand
  ]
};