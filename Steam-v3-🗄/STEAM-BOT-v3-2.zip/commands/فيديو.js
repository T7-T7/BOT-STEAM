import fs from 'fs/promises';
import os from 'os';
import path from 'path';
import { execFile } from 'child_process';
import { promisify } from 'util';

const execFileAsync =
    promisify(execFile);

/* =========================================================
 * CONFIG
 * ========================================================= */

const API_BASE =
    'https://engez.a7a.online/api/v1';

const DOWNLOAD_APIS = [
    `${API_BASE}/download/youtubev2`,
    `${API_BASE}/download/ytdl`,
    `${API_BASE}/download/youtube`
];

const PIPED_APIS = [
    'https://pipedapi.kavin.rocks',
    'https://pipedapi.tokhmi.xyz',
    'https://pipedapi.moomoo.me',
    'https://pipedapi.syncpundit.io',
    'https://api-piped.mha.fi'
];

const MAX_FILE_SIZE =
    64 * 1024 * 1024;

const MAX_VIDEO_DURATION =
    900;

const USER_AGENT =
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) ' +
    'AppleWebKit/537.36 (KHTML, like Gecko) ' +
    'Chrome/131.0.0.0 Safari/537.36';

/* =========================================================
 * HELPERS
 * ========================================================= */

const clean = value =>
    String(value ?? '')
        .replace(/\s+/g, ' ')
        .trim();

function timeoutSignal(ms) {
    return AbortSignal.timeout(
        Math.max(
            1000,
            Number(ms) || 10000
        )
    );
}

function isYoutubeUrl(value) {
    try {
        const url =
            new URL(
                String(value || '').trim()
            );

        const host =
            url.hostname.toLowerCase();

        return (
            host === 'youtu.be' ||
            host === 'youtube.com' ||
            host === 'www.youtube.com' ||
            host.endsWith('.youtube.com')
        );
    } catch {
        return false;
    }
}

function youtubeId(value) {
    try {
        const url =
            new URL(
                String(value || '').trim()
            );

        const host =
            url.hostname.toLowerCase();

        if (
            host === 'youtu.be' ||
            host.endsWith('.youtu.be')
        ) {
            return (
                url.pathname
                    .slice(1)
                    .split('/')[0] ||
                null
            );
        }

        /*
         * يدعم:
         * youtube.com/watch?v=
         * youtube.com/shorts/
         * youtube.com/embed/
         */
        const queryId =
            url.searchParams.get('v');

        if (queryId) {
            return queryId;
        }

        const parts =
            url.pathname
                .split('/')
                .filter(Boolean);

        if (
            parts[0] === 'shorts' ||
            parts[0] === 'embed' ||
            parts[0] === 'live'
        ) {
            return parts[1] || null;
        }

        return null;
    } catch {
        return null;
    }
}

/* =========================================================
 * JSON REQUEST
 * ========================================================= */

async function getJson(
    url,
    params = {},
    timeout = 30000
) {
    const target =
        new URL(url);

    for (
        const [key, value]
        of Object.entries(params)
    ) {
        if (
            value !== undefined &&
            value !== null
        ) {
            target.searchParams.set(
                key,
                String(value)
            );
        }
    }

    const response =
        await fetch(
            target,
            {
                headers: {
                    accept:
                        'application/json,text/plain,*/*',

                    'user-agent':
                        USER_AGENT
                },

                signal:
                    timeoutSignal(
                        timeout
                    )
            }
        );

    const text =
        await response.text();

    if (!response.ok) {
        throw new Error(
            `HTTP ${response.status}`
        );
    }

    if (
        /^\s*</.test(text)
    ) {
        throw new Error(
            'الخادم أعاد HTML بدل JSON.'
        );
    }

    try {
        return JSON.parse(text);
    } catch {
        throw new Error(
            'استجابة JSON غير صالحة.'
        );
    }
}

/* =========================================================
 * MEDIA VALIDATION
 * ========================================================= */

function mediaLike(
    buffer,
    mime = ''
) {
    if (
        !Buffer.isBuffer(buffer) ||
        buffer.length < 1024
    ) {
        return false;
    }

    const header =
        buffer.subarray(0, 64);

    const text =
        header
            .toString('utf8')
            .trimStart()
            .toLowerCase();

    if (
        text.startsWith('<!doctype') ||
        text.startsWith('<html') ||
        text.startsWith('{')
    ) {
        return false;
    }

    /*
     * MP4 / MOV
     */
    if (
        header.includes(
            Buffer.from('ftyp')
        )
    ) {
        return true;
    }

    /*
     * AVI / WebM / OGG
     */
    if (
        header.subarray(0, 4)
            .toString() === 'RIFF'
    ) {
        return true;
    }

    if (
        header.subarray(0, 4)
            .toString() === 'OggS'
    ) {
        return true;
    }

    /*
     * EBML / WebM / MKV
     */
    if (
        header[0] === 0x1A &&
        header[1] === 0x45 &&
        header[2] === 0xDF &&
        header[3] === 0xA3
    ) {
        return true;
    }

    return /video\/|audio\/|application\/octet-stream/i.test(
        mime
    );
}

/* =========================================================
 * DOWNLOAD BYTES
 * ========================================================= */

async function downloadBytes(
    rawUrl,
    timeout = 90000
) {
    let url =
        new URL(rawUrl);

    for (
        let attempt = 0;
        attempt < 5;
        attempt++
    ) {
        const response =
            await fetch(
                url,
                {
                    redirect:
                        'manual',

                    headers: {
                        'user-agent':
                            USER_AGENT,

                        accept:
                            'video/*,audio/*,application/octet-stream,*/*'
                    },

                    signal:
                        timeoutSignal(
                            timeout
                        )
                }
            );

        /*
         * Manual redirect
         */
        if (
            response.status >= 300 &&
            response.status < 400
        ) {
            const location =
                response.headers.get(
                    'location'
                );

            if (!location) {
                throw new Error(
                    'إعادة توجيه بدون رابط.'
                );
            }

            url =
                new URL(
                    location,
                    url
                );

            continue;
        }

        if (!response.ok) {
            throw new Error(
                `تنزيل الفيديو HTTP ${response.status}`
            );
        }

        const mime =
            String(
                response.headers.get(
                    'content-type'
                ) || ''
            ).toLowerCase();

        if (
            /text\/html|application\/json|^text\/plain/.test(
                mime
            )
        ) {
            throw new Error(
                'الخادم لم يرجع ملف فيديو.'
            );
        }

        const length =
            Number(
                response.headers.get(
                    'content-length'
                ) || 0
            );

        if (
            length > MAX_FILE_SIZE
        ) {
            throw new Error(
                'حجم الفيديو أكبر من 64MB.'
            );
        }

        if (!response.body) {
            throw new Error(
                'الخادم لم يرجع تدفق الفيديو.'
            );
        }

        const reader =
            response.body.getReader();

        const chunks = [];

        let total = 0;

        try {
            while (true) {
                const {
                    done,
                    value
                } =
                    await reader.read();

                if (done) {
                    break;
                }

                if (
                    !value?.byteLength
                ) {
                    continue;
                }

                total +=
                    value.byteLength;

                if (
                    total >
                    MAX_FILE_SIZE
                ) {
                    throw new Error(
                        'حجم الفيديو أكبر من 64MB.'
                    );
                }

                chunks.push(
                    Buffer.from(value)
                );
            }
        } finally {
            try {
                reader.releaseLock();
            } catch {}
        }

        const buffer =
            Buffer.concat(
                chunks,
                total
            );

        if (
            !mediaLike(
                buffer,
                mime
            )
        ) {
            throw new Error(
                'المزود أرجع ملفًا غير صالح.'
            );
        }

        return {
            buffer,

            mimetype:
                mime || 'video/mp4'
        };
    }

    throw new Error(
        'عدد إعادة التوجيه كبير جدًا.'
    );
}

/* =========================================================
 * ENGEZ
 * ========================================================= */

async function downloadFromEngez(
    youtubeUrl
) {
    let lastError = null;

    for (
        const endpoint
        of DOWNLOAD_APIS
    ) {
        try {
            const data =
                await getJson(
                    endpoint,
                    {
                        url:
                            youtubeUrl,

                        type:
                            'video'
                    },
                    90000
                );

            const payload =
                data?.response ||
                data?.data ||
                data;

            const downloadUrl =
                payload?.download_url ||
                payload?.downloadUrl ||
                payload?.url;

            if (!downloadUrl) {
                throw new Error(
                    'Engez لم يرجع رابط فيديو.'
                );
            }

            return await downloadBytes(
                downloadUrl,
                90000
            );
        } catch (error) {
            lastError =
                error;
        }
    }

    throw (
        lastError ||
        new Error(
            'فشل التحميل من Engez.'
        )
    );
}

/* =========================================================
 * PIPED
 * ========================================================= */

async function downloadFromPiped(
    youtubeUrl
) {
    const id =
        youtubeId(
            youtubeUrl
        );

    if (!id) {
        throw new Error(
            'تعذر استخراج YouTube ID.'
        );
    }

    let lastError = null;

    /*
     * نجرب خوادم Piped واحدًا واحدًا.
     * لا نعتبر فشل خادم واحد فشلًا للمصدر بالكامل.
     */
    for (
        const base
        of PIPED_APIS
    ) {
        try {
            const data =
                await getJson(
                    `${base}/streams/${encodeURIComponent(id)}`,
                    {},
                    12000
                );

            const streams =
                Array.isArray(
                    data?.videoStreams
                )
                    ? data.videoStreams
                    : [];

            const valid =
                streams.filter(
                    item =>
                        item?.url &&
                        /^https?:\/\//i.test(
                            item.url
                        )
                );

            if (!valid.length) {
                throw new Error(
                    'لا توجد وسائط فيديو.'
                );
            }

            /*
             * الأفضلية:
             *
             * 1. MP4
             * 2. فيديو يحتوي على صوت
             * 3. جودة لا تتجاوز 720p
             */
            const mp4 =
                valid.filter(
                    item =>
                        /mp4/i.test(
                            String(
                                item.mimeType ||
                                item.format ||
                                ''
                            )
                        )
                );

            const withAudio =
                (mp4.length
                    ? mp4
                    : valid
                ).filter(
                    item =>
                        item.audioUrl ||
                        item.hasAudio ||
                        /audio/i.test(
                            String(
                                item.mimeType ||
                                ''
                            )
                        )
                );

            const candidates =
                withAudio.length
                    ? withAudio
                    : (
                        mp4.length
                            ? mp4
                            : valid
                    );

            const sorted =
                candidates.sort(
                    (a, b) =>
                        Number(
                            b.width || 0
                        ) -
                        Number(
                            a.width || 0
                        )
                );

            /*
             * نحاول المرشح الأفضل،
             * وإذا كان الملف غير صالح
             * نجرب التالي.
             */
            let lastStreamError =
                null;

            for (
                const source
                of sorted
            ) {
                try {
                    return await downloadBytes(
                        source.url,
                        90000
                    );
                } catch (error) {
                    lastStreamError =
                        error;
                }
            }

            throw (
                lastStreamError ||
                new Error(
                    'تعذر تنزيل أي تدفق فيديو.'
                )
            );
        } catch (error) {
            lastError =
                error;
        }
    }

    throw (
        lastError ||
        new Error(
            'فشل الاتصال بخوادم Piped.'
        )
    );
}

/* =========================================================
 * YT-DLP
 * ========================================================= */

let ytDlpAvailable = null;

async function hasYtDlp() {
    if (
        ytDlpAvailable !== null
    ) {
        return ytDlpAvailable;
    }

    try {
        await execFileAsync(
            'yt-dlp',
            [
                '--version'
            ],
            {
                timeout:
                    3000
            }
        );

        ytDlpAvailable = true;
    } catch {
        ytDlpAvailable = false;
    }

    return ytDlpAvailable;
}

async function downloadFromYtDlp(
    youtubeUrl
) {
    const available =
        await hasYtDlp();

    if (!available) {
        throw new Error(
            'yt-dlp غير مثبت على السيرفر.'
        );
    }

    const directory =
        await fs.mkdtemp(
            path.join(
                os.tmpdir(),
                'steam-video-'
            )
        );

    const output =
        path.join(
            directory,
            'video.%(ext)s'
        );

    try {
        await execFileAsync(
            'yt-dlp',
            [
                '--no-warnings',

                '--no-playlist',

                '--match-filter',
                `duration <= ${MAX_VIDEO_DURATION}`,

                '-f',
                'best[ext=mp4][height<=720]/best[height<=720]/best',

                '--merge-output-format',
                'mp4',

                '-o',
                output,

                youtubeUrl
            ],
            {
                timeout:
                    240000,

                maxBuffer:
                    8 *
                    1024 *
                    1024
            }
        );

        const files =
            await fs.readdir(
                directory
            );

        const video =
            files.find(
                file =>
                    /\.(mp4|webm|mkv)$/i.test(
                        file
                    )
            );

        if (!video) {
            throw new Error(
                'yt-dlp لم ينتج ملف فيديو.'
            );
        }

        const filePath =
            path.join(
                directory,
                video
            );

        const stat =
            await fs.stat(
                filePath
            );

        if (
            stat.size >
            MAX_FILE_SIZE
        ) {
            throw new Error(
                'حجم الفيديو أكبر من 64MB.'
            );
        }

        const buffer =
            await fs.readFile(
                filePath
            );

        if (
            !mediaLike(
                buffer,
                'video/mp4'
            )
        ) {
            throw new Error(
                'yt-dlp أنتج ملف فيديو غير صالح.'
            );
        }

        return {
            buffer,

            mimetype:
                'video/mp4'
        };
    } finally {
        await fs.rm(
            directory,
            {
                recursive:
                    true,

                force:
                    true
            }
        ).catch(
            () => {}
        );
    }
}

/* =========================================================
 * DOWNLOAD ENGINE
 * ========================================================= */

async function downloadVideo(
    youtubeUrl
) {
    const errors = [];

    /*
     * =====================================================
     * 1. ENGEZ
     * =====================================================
     */
    try {
        console.log(
            '[فيديو] محاولة التحميل من Engez...'
        );

        const result =
            await downloadFromEngez(
                youtubeUrl
            );

        console.log(
            '[فيديو] تم التحميل من Engez.'
        );

        return result;
    } catch (error) {
        errors.push({
            source:
                'Engez',

            error:
                error?.message ||
                String(error)
        });

        console.error(
            '[فيديو:Engez]',
            error?.message ||
            error
        );
    }

    /*
     * =====================================================
     * 2. PIPED
     * =====================================================
     */
    try {
        console.log(
            '[فيديو] محاولة التحميل من Piped...'
        );

        const result =
            await downloadFromPiped(
                youtubeUrl
            );

        console.log(
            '[فيديو] تم التحميل من Piped.'
        );

        return result;
    } catch (error) {
        errors.push({
            source:
                'Piped',

            error:
                error?.message ||
                String(error)
        });

        console.error(
            '[فيديو:Piped]',
            error?.message ||
            error
        );
    }

    /*
     * =====================================================
     * 3. YT-DLP
     * =====================================================
     */
    try {
        console.log(
            '[فيديو] محاولة التحميل من yt-dlp...'
        );

        const result =
            await downloadFromYtDlp(
                youtubeUrl
            );

        console.log(
            '[فيديو] تم التحميل من yt-dlp.'
        );

        return result;
    } catch (error) {
        errors.push({
            source:
                'yt-dlp',

            error:
                error?.message ||
                String(error)
        });

        console.error(
            '[فيديو:yt-dlp]',
            error?.message ||
            error
        );
    }

    /*
     * =====================================================
     * كل المصادر فشلت
     * =====================================================
     */

    const details =
        errors
            .map(
                item =>
                    `• ${item.source}: ${item.error}`
            )
            .join('\n');

    throw new Error(
        `فشلت جميع طرق التحميل:\n${details}`
    );
}

/* =========================================================
 * COMMAND
 * ========================================================= */

export default {
    name:
        'فيديو',

    aliases: [
        'تحميل_فيديو',
        'تحميل فيديو',
        'video'
    ],

    category:
        'وسائط',

    requiredRole:
        'user',

    async execute(ctx) {
        const {
            message
        } = ctx;

        const args =
            Array.isArray(
                ctx.args
            )
                ? ctx.args
                : [];

        /*
         * =================================================
         * QUERY
         * =================================================
         */

        const query =
            clean(
                args.join(' ')
            );

        if (!query) {
            return message.reply(
                [
                    '📘 *تحميل فيديو من YouTube*',
                    '',
                    '🎥 `.فيديو <رابط YouTube>`',
                    '',
                    'مثال:',
                    '`.فيديو https://youtu.be/...`',
                    '',
                    '⎋ STEAM BOT'
                ].join('\n')
            );
        }

        /*
         * =================================================
         * URL VALIDATION
         * =================================================
         */

        if (
            !isYoutubeUrl(
                query
            )
        ) {
            return message.reply(
                [
                    '❌ *رابط غير صالح*',
                    '',
                    'أمر `.فيديو` يحتاج رابط YouTube صحيح.',
                    '',
                    'مثال:',
                    '`.فيديو https://youtu.be/HKoU4Q9DhaQ`'
                ].join('\n')
            );
        }

        /*
         * =================================================
         * START
         * =================================================
         */

        await message.react?.(
            '🎥'
        ).catch?.(
            () => {}
        );

        try {
            const result =
                await downloadVideo(
                    query
                );

            /*
             * حماية إضافية قبل الإرسال
             */
            if (
                !result?.buffer ||
                !Buffer.isBuffer(
                    result.buffer
                ) ||
                !result.buffer.length
            ) {
                throw new Error(
                    'تم الحصول على استجابة فارغة من مزود التحميل.'
                );
            }

            /*
             * إرسال الفيديو
             */
            await message.reply({
                video:
                    result.buffer,

                mimetype:
                    result.mimetype ||
                    'video/mp4',

                fileName:
                    'steam-video.mp4',

                caption:
                    '🎥 *YouTube Video*\n\n' +
                    '⎋ STEAM BOT'
            });

            await message.react?.(
                '✅'
            ).catch?.(
                () => {}
            );

            return true;
        } catch (error) {
            console.error(
                '[فيديو]',
                error?.message ||
                error
            );

            await message.react?.(
                '❌'
            ).catch?.(
                () => {}
            );

            return message.reply(
                [
                    '❌ *تعذر تحميل الفيديو.*',
                    '',
                    `السبب: ${
                        error?.message ||
                        String(error)
                    }`,
                    '',
                    '⎋ STEAM BOT'
                ].join('\n')
            );
        }
    }
};