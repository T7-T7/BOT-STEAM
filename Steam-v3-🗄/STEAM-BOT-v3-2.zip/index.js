import fs from 'fs/promises';
import config from './config.js';
import { init as dbInit, read } from './database/index.js';
import { loadCommands, get, list, dispatch } from './heart/index.js';
import { connect } from './whatsapp/connection.js';
import { normalize } from './whatsapp/message.js';
import { resolve, roleOf, register } from './security/index.js';
import { hasRole } from './security/roles.js';
import { setGroupMetadata } from './services/group-cache.js';
import { setBotDeveloperMode } from './services/bot-mode.js';
import {
  system,
  loaded,
  incoming,
  command,
  error,
  setEnabled
} from './console/index.js';

const seenMessages = new Map();
const SEEN_TTL = 120_000;

const MAX_MESSAGE_CONCURRENCY = 8;
let activeMessages = 0;
const pendingMessages = [];

let currentSocket = null;

const MAX_PENDING_MESSAGES =
  Number(config.limits?.maxPendingMessages) || 128;

async function withMessageSlot(task) {
  if (activeMessages >= MAX_MESSAGE_CONCURRENCY) {
    if (pendingMessages.length >= MAX_PENDING_MESSAGES) {
      return false;
    }

    await new Promise(resolve =>
      pendingMessages.push(resolve)
    );
  }

  activeMessages += 1;

  try {
    return await task();
  } finally {
    activeMessages -= 1;

    const next = pendingMessages.shift();

    if (next) {
      next();
    }
  }
}

function cleanCommandText(value) {
  return String(value || '')
    .replace(/[\u200B-\u200D\uFEFF]/g, '')
    .trimStart();
}

function tokenize(value) {
  const tokens = [];

  const re =
    /"([^"\\]*(?:\\.[^"\\]*)*)"|'([^'\\]*(?:\\.[^'\\]*)*)'|(\S+)/gu;

  let match;

  while ((match = re.exec(value))) {
    tokens.push(
      match[1] ??
      match[2] ??
      match[3]
    );
  }

  return tokens;
}

function normalizeCommandName(value) {
  return String(value || '')
    .trim()
    .toLowerCase()
    .replace(/[-_]+/g, ' ')
    .replace(/\s+/g, ' ');
}

function parseCommand(text) {
  const normalized =
    cleanCommandText(text);

  if (!normalized.startsWith(config.prefix)) {
    return null;
  }

  const body =
    normalized
      .slice(config.prefix.length)
      .trim();

  if (!body) {
    return null;
  }

  /*
   * نبحث عن أطول اسم أمر أولًا.
   */
  const names =
    list()
      .filter(Boolean)
      .sort(
        (a, b) =>
          String(b).length -
          String(a).length
      );

  for (const commandName of names) {
    const normalizedName =
      normalizeCommandName(
        commandName
      );

    if (!normalizedName) {
      continue;
    }

    const re =
      new RegExp(
        `^${String(normalizedName)
          .split(' ')
          .map(part =>
            part.replace(
              /[.*+?^${}()|[\]\\]/g,
              '\\$&'
            )
          )
          .join('\\s+')}(?:\\s+|$)`,
        'iu'
      );

    const match =
      body.match(re);

    if (!match) {
      continue;
    }

    const remaining =
      body
        .slice(match[0].length)
        .trim();

    return {
      name: commandName,
      args: remaining
        ? tokenize(remaining)
        : []
    };
  }

  /*
   * الصيغة العادية:
   *
   * .اضف شيء
   * .اضافة شيء
   * .ضيف شيء
   */
  const tokens =
    tokenize(body);

  if (!tokens.length) {
    return null;
  }

  return {
    name: tokens[0],
    args: tokens.slice(1)
  };
}

function cleanupSeen() {
  const now = Date.now();

  for (
    const [id, time]
    of seenMessages
  ) {
    if (
      now - time >
      SEEN_TTL
    ) {
      seenMessages.delete(id);
    }
  }
}

setInterval(
  cleanupSeen,
  SEEN_TTL
).unref?.();

async function boot() {
  await fs.mkdir(
    './data/archives',
    {
      recursive: true
    }
  );

  await fs.mkdir(
    './plugins',
    {
      recursive: true
    }
  );

  await dbInit();

  const settings =
    await read(
      'settings.json',
      {
        console: true,
        mode: 'public',
        bot: 'user'
      }
    );

  setEnabled(
    settings.console !== false
  );

  setBotDeveloperMode(
    settings.bot
  );

  const loadResult =
    await loadCommands();

  const names =
    Array.isArray(loadResult)
      ? loadResult
      : (
          loadResult?.names ||
          []
        );

  loaded(names);

  system({
    loaded: names.length,

    status: 'ready',

    mode:
      settings.mode === 'private'
        ? 'الوضع الخاص'
        : 'الوضع العام',

    bot:
      settings.bot === 'developer'
        ? 'البوت مطور'
        : 'البوت ليس مطور',

    permissions: 'working',

    connection: 'connecting'
  });

  await connect(onSocket);
}

async function processIncomingMessage(
  raw,
  sock
) {
  try {
    if (
      !String(
        raw.key?.remoteJid || ''
      ).endsWith('@g.us')
    ) {
      return;
    }

    const settings =
      await read(
        'settings.json',
        {
          mode: 'public',
          console: true,
          bot: 'user'
        }
      );

    if (
      settings.mode === 'private'
    ) {
      const senderRaw =
        raw.key?.participant ||
        raw.key?.participantAlt ||
        '';

      const senderRole =
        await roleOf(senderRaw);

      if (
        senderRole !==
        'developer'
      ) {
        return;
      }
    }

    if (raw.key?.id) {
      const messageKey =
        `${raw.key.remoteJid || ''}:${raw.key.id}`;

      if (
        seenMessages.has(
          messageKey
        )
      ) {
        return;
      }

      seenMessages.set(
        messageKey,
        Date.now()
      );
    }

    if (
      raw.key?.participant &&
      raw.key?.participantAlt
    ) {
      register(
        raw.key.participant,
        raw.key.participantAlt
      );
    }

    if (
      raw.key?.remoteJid &&
      raw.key?.remoteJidAlt
    ) {
      register(
        raw.key.remoteJidAlt,
        raw.key.remoteJid
      );
    }

    const m =
      normalize(
        raw,
        sock
      );

    incoming({
      sender: m.sender,
      group: m.chatId,
      type: m.type,
      content: m.text
    });

    const cleanText =
      cleanCommandText(
        m.text
      );

    const parsed =
      parseCommand(
        cleanText
      );

    if (!parsed) {
      return;
    }

    let {
      name,
      args
    } = parsed;

    /*
     * دعم الصيغ:
     *
     * .اضف-جدول-[...]
     * .اضافة-جدول-[...]
     * .إضافة-جدول-[...]
     *
     * كلها تصبح:
     *
     * command = ضيف
     *
     * args = جدول-[...]
     */

    const compactName =
      String(name || '');

    if (
      compactName.startsWith(
        'ارشيف-'
      )
    ) {
      args = [
        compactName.slice(
          'ارشيف-'.length
        ),
        ...args
      ];

      name = 'ارشيف';

    } else if (
      compactName.startsWith(
        'اضف-'
      ) ||
      compactName.startsWith(
        'اضافة-'
      ) ||
      compactName.startsWith(
        'إضافة-'
      ) ||
      compactName.startsWith(
        'أضف-'
      )
    ) {
      let prefix;

      if (
        compactName.startsWith(
          'اضافة-'
        )
      ) {
        prefix = 'اضافة-';

      } else if (
        compactName.startsWith(
          'إضافة-'
        )
      ) {
        prefix = 'إضافة-';

      } else if (
        compactName.startsWith(
          'أضف-'
        )
      ) {
        prefix = 'أضف-';

      } else {
        prefix = 'اضف-';
      }

      args = [
        compactName.slice(
          prefix.length
        ),
        ...args
      ];

      /*
       * الاسم الحقيقي للأمر في Registry
       * هو "ضيف".
       */
      name = 'ضيف';
    }

    const cmd =
      get(name);

    if (!cmd) {
      return;
    }

    const role =
      await roleOf(
        m.sender
      );

    if (
      !hasRole(
        role,
        cmd.requiredRole ||
        'user'
      )
    ) {
      await m.reply(
        '❌ هذا الأمر غير متاح لصلاحيتك.'
      );

      return;
    }

    command({
      role,

      number:
        String(
          resolve(
            m.sender
          ) || ''
        ).split('@')[0],

      group: 'group',

      command: name
    });

    await dispatch(
      {
        message: m,
        sock,
        args,
        text: args.join(' '),
        role
      },
      cmd
    );

  } catch (e) {
    error(
      'MESSAGE',
      e
    );

    try {
      if (
        raw?.key?.remoteJid &&
        !raw.key.fromMe
      ) {
        await sock.sendMessage(
          raw.key.remoteJid,
          {
            text:
              '❌ تعذر تنفيذ الأمر. حاول مرة أخرى أو تواصل مع المطور.'
          },
          {
            quoted: raw
          }
        );
      }
    } catch {}
  }
}

function onSocket(sock) {
  currentSocket = sock;

  sock.ev.on(
    'groups.upsert',
    groups => {
      for (
        const group
        of groups || []
      ) {
        setGroupMetadata(
          group
        );
      }
    }
  );

  sock.ev.on(
    'groups.update',
    updates => {
      void updates;
    }
  );

  sock.ev.on(
    'contacts.update',
    updates => {
      for (
        const item
        of updates || []
      ) {
        if (
          item.id &&
          item.lid
        ) {
          register(
            item.id,
            item.lid
          );
        }
      }
    }
  );

  sock.ev.on(
    'messages.upsert',
    async up => {
      if (
        sock !== currentSocket
      ) {
        return;
      }

      if (
        up.type !== 'notify'
      ) {
        return;
      }

      const messages =
        (up.messages || [])
          .filter(
            raw =>
              raw?.message &&
              !raw?.key?.fromMe
          );

      await Promise.allSettled(
        messages.map(
          raw =>
            withMessageSlot(
              () =>
                processIncomingMessage(
                  raw,
                  sock
                )
            )
        )
      );
    }
  );
}

boot().catch(e => {
  error(
    'BOOT',
    e
  );

  process.exitCode = 1;
});