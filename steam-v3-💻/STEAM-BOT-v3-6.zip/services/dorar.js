const API = 'https://dorar.net/dorar_api.json';
const SITE = 'https://dorar.net';

const SECTIONS = Object.freeze({
  حديث: 'hadith', أحاديث: 'hadith', حديثية: 'hadith',
  تفسير: 'tafseer', فقه: 'feqhia', فقهية: 'feqhia',
  عقيدة: 'aqeeda', عقدية: 'aqeeda', أديان: 'adyan', دين: 'adyan',
  فرق: 'frq', فرقة: 'frq', أصول: 'usul', أصول_الفقه: 'usul',
  قواعد: 'qfiqhia', قواعد_فقهية: 'qfiqhia', أخلاق: 'alakhlaq', سلوك: 'alakhlaq',
  آداب: 'aadab', أداب: 'aadab', تاريخ: 'history', تاريخية: 'history',
  لغة: 'arabia', عربي: 'arabia', منتشر: 'fake-hadith', أحاديث_منتشرة: 'fake-hadith'
});

const SECTION_TITLES = Object.freeze({
  hadith: 'حديث', tafseer: 'تفسير', feqhia: 'فقه', aqeeda: 'عقيدة', adyan: 'أديان', frq: 'فرق',
  usul: 'أصول الفقه', qfiqhia: 'قواعد فقهية', alakhlaq: 'أخلاق وسلوك', aadab: 'آداب',
  history: 'تاريخ', arabia: 'لغة عربية', 'fake-hadith': 'أحاديث منتشرة'
});

const SURAH_ALIASES = Object.freeze({
  'الفاتحة': 1, 'فاتحة': 1, 'البقرة': 2, 'بقرة': 2, 'ال عمران': 3, 'آل عمران': 3,
  'النساء': 4, 'نساء': 4, 'المائدة': 5, 'مائدة': 5, 'الانعام': 6, 'أنعام': 6,
  'الاعراف': 7, 'أعراف': 7, 'الانفال': 8, 'أنفال': 8, 'التوبة': 9, 'توبة': 9,
  'يونس': 10, 'هود': 11, 'يوسف': 12, 'الرعد': 13, 'ابراهيم': 14, 'إبراهيم': 14,
  'الحجر': 15, 'النحل': 16, 'الاسراء': 17, 'الإسراء': 17, 'الكهف': 18, 'مريم': 19,
  'طه': 20, 'الانبياء': 21, 'الأنبياء': 21, 'الحج': 22, 'المؤمنون': 23, 'النور': 24,
  'الفرقان': 25, 'الشعراء': 26, 'النمل': 27, 'القصص': 28, 'العنكبوت': 29, 'الروم': 30,
  'لقمان': 31, 'السجدة': 32, 'الاحزاب': 33, 'الأحزاب': 33, 'سبا': 34, 'سبأ': 34,
  'فاطر': 35, 'يس': 36, 'الصافات': 37, 'ص': 38, 'الزمر': 39, 'غافر': 40,
  'فصلت': 41, 'الشورى': 42, 'الزخرف': 43, 'الدخان': 44, 'الجاثية': 45, 'الاحقاف': 46,
  'الأحقاف': 46, 'محمد': 47, 'الفتح': 48, 'الحجرات': 49, 'ق': 50, 'الذاريات': 51,
  'الطور': 52, 'النجم': 53, 'القمر': 54, 'الرحمن': 55, 'الواقعة': 56, 'الحديد': 57,
  'المجادلة': 58, 'الحشر': 59, 'الممتحنة': 60, 'الصف': 61, 'الجمعة': 62, 'المنافقون': 63,
  'التغابن': 64, 'الطلاق': 65, 'التحريم': 66, 'الملك': 67, 'القلم': 68, 'الحاقة': 69,
  'المعارج': 70, 'نوح': 71, 'الجن': 72, 'المزمل': 73, 'المدثر': 74, 'القيامة': 75,
  'الانسان': 76, 'الإنسان': 76, 'المرسلات': 77, 'النبأ': 78, 'النازعات': 79, 'عبس': 80,
  'التكوير': 81, 'الانفطار': 82, 'المطففين': 83, 'الانشقاق': 84, 'البروج': 85, 'الطارق': 86,
  'الاعلى': 87, 'الأعلى': 87, 'الغاشية': 88, 'الفجر': 89, 'البلد': 90, 'الشمس': 91,
  'الليل': 92, 'الضحى': 93, 'الشرح': 94, 'التين': 95, 'العلق': 96, 'القدر': 97,
  'البينة': 98, 'الزلزلة': 99, 'العاديات': 100, 'القارعة': 101, 'التكاثر': 102,
  'العصر': 103, 'الهمزة': 104, 'الفيل': 105, 'قريش': 106, 'الماعون': 107,
  'الكوثر': 108, 'الكافرون': 109, 'النصر': 110, 'المسد': 111, 'الاخلاص': 112,
  'الإخلاص': 112, 'الفلق': 113, 'الناس': 114
});

const CACHE = new Map();
const CACHE_TTL = 60_000;
const CACHE_MAX = 500;

function htmlToText(value) {
  return String(value || '')
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<h[1-6][^>]*>/gi, '\n##### ')
    .replace(/<\/h[1-6]>/gi, '\n')
    .replace(/<br\s*\/?>(?=.)/gi, '\n')
    .replace(/<\/p>|<\/div>|<\/li>|<\/section>/gi, '\n')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/gi, ' ')
    .replace(/&amp;/gi, '&')
    .replace(/&quot;/gi, '"')
    .replace(/&#39;|&#x27;/gi, "'")
    .replace(/&lt;/gi, '<')
    .replace(/&gt;/gi, '>')
    .replace(/&#(?:x[0-9a-f]+|\d+);/gi, ' ')
    .replace(/[ \t]+/g, ' ')
    .replace(/\n[ \t]+/g, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

function cleanInline(value) {
  return String(value || '').replace(/\s+/g, ' ').trim();
}

function stripSquareBrackets(value) {
  return cleanInline(value).replace(/[\[\]]/g, '').trim();
}

function normalizeArabic(value) {
  return cleanInline(value)
    .replace(/[إأآٱ]/g, 'ا')
    .replace(/ى/g, 'ي')
    .replace(/ة/g, 'ه')
    .replace(/[ًٌٍَُِّْـ]/g, '')
    .replace(/[“”„«»]/g, '"')
    .replace(/[^\p{L}\p{N}\s]/gu, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .toLowerCase();
}

async function request(url) {
  const response = await fetch(url, {
    headers: {
      'user-agent': 'STEAM-BOT/2.0',
      accept: 'text/html,application/json;q=0.9,*/*;q=0.8',
      'accept-language': 'ar,en;q=0.8'
    },
    signal: AbortSignal.timeout(35_000)
  });
  const text = await response.text();
  if (!response.ok) throw new Error(`الدرر السنية أعادت HTTP ${response.status}`);
  return text;
}

function parseJsonp(raw) {
  const text = String(raw || '').replace(/^\uFEFF/, '').trim();
  try { return JSON.parse(text); } catch {}
  const match = text.match(/^[A-Za-z_$][\w$]*(?:\.[A-Za-z_$][\w$]*)*\s*\(([\s\S]*)\)\s*;?$/);
  if (match) return JSON.parse(match[1]);
  const a = text.indexOf('{'), b = text.lastIndexOf('}');
  if (a >= 0 && b > a) return JSON.parse(text.slice(a, b + 1));
  throw new Error('استجابة الدرر السنية ليست JSON صالحًا');
}

function extractHadithLinks(html) {
  const out = [], seen = new Set();
  const re = /href\s*=\s*["'](\/h\/[A-Za-z0-9_-]+(?:\?[^"']*)?)["']/gi;
  let m;
  while ((m = re.exec(String(html || ''))) && out.length < 12) {
    const url = `${SITE}${m[1]}`;
    if (!seen.has(url)) { seen.add(url); out.push(url); }
  }
  return out;
}

function parseDetailHadith(html) {
  const text = htmlToText(html);
  const result = text.match(/#####\s*-\s*([\s\S]*?)\n\s*خلاصة\s+حكم\s+المحدث\s*:\s*([\s\S]*?)(?=\n\s*#####|\n\s*روابط هامة|$)/u);
  if (!result) return null;

  const body = cleanInline(result[1]);
  const gradeBlock = cleanInline(result[2]);
  const grade = stripSquareBrackets(gradeBlock.split(/\s+الراوي\s*:/u)[0]);
  const narrator = stripSquareBrackets((gradeBlock.match(/الراوي\s*:\s*(.*?)(?=\s+\|\s*المحدث\s*:|\s+المحدث\s*:|$)/u) || [,''])[1]);
  const scholar = stripSquareBrackets((gradeBlock.match(/المحدث\s*:\s*(.*?)(?=\s+\|\s*المصدر\s*:|\s+المصدر\s*:|$)/u) || [,''])[1]);
  const source = stripSquareBrackets((gradeBlock.match(/المصدر\s*:\s*(.*?)(?=\s+الصفحة\s+أو\s+الرقم\s*:|\s+التخريج\s*:|$)/u) || [,''])[1]);
  const page = stripSquareBrackets((gradeBlock.match(/الصفحة\s+أو\s+الرقم\s*:\s*(.*?)(?=\s+التخريج\s*:|\s+التصنيف\s+الموضوعي|$)/u) || [,''])[1]);
  // التخريج قد يكون خارج كتلة الحكم؛ اقرأه من الصفحة كاملة حتى لا نفقده.
  const takhrij = stripSquareBrackets((text.match(/التخريج\s*:\s*(.*?)(?=\s+التصنيف\s+الموضوعي|\s+أحاديث مشابهة|\s+أصول الحديث|$)/u) || [,''])[1]);

  if (body.length < 20 || /(?:تسجيل الدخول|اختر نوع البحث|التعريف بالموقع|روابط مهمة)/u.test(body)) return null;
  return { text: body, grade, narrator, scholar, source, page, takhrij };
}

function isAuthentic(row) {
  const grade = normalizeArabic(row?.grade);
  return /(^|\s)صحيح(\s|$)/u.test(grade) && !/(ليس بصحيح|غير صحيح|لا يصح|لم يصح|موضوع|ضعيف)/u.test(grade);
}

function significantWords(value) {
  const stop = new Set(['ان','أن','انه','أنه','او','أو','في','من','عن','على','له','به','ثم','هذا','هذه','ذلك','تلك','الذي','التي','ما','لا','لم','لن','هو','هي','كان','يكون','قد','حتى','مع','بين','كل']);
  return normalizeArabic(value).split(' ').filter(x => x.length >= 3 && !stop.has(x));
}

function phraseScore(query, text) {
  const q = significantWords(query), t = significantWords(text);
  if (!q.length || !t.length) return 0;
  const nq = normalizeArabic(query), nt = normalizeArabic(text);
  if (nt.includes(nq)) return 1;
  let hit = 0;
  for (const word of q) if (t.some(x => x === word || (word.length >= 4 && (x.startsWith(word) || word.startsWith(x))))) hit++;
  return hit / q.length;
}

async function enrichHadithTakhrij(row) {
  if (row?.takhrij) return row;
  const match = String(row?.url || '').match(/\/h\/([A-Za-z0-9_-]+)/u);
  if (!match) return row;
  try {
    const html = await request(`${SITE}/hadith/sharh/${match[1]}`);
    const text = htmlToText(html);
    const takhrij = stripSquareBrackets((text.match(/التخريج\s*:\s*(.*?)(?=\s+التصنيف\s+الموضوعي|\s+أحاديث مشابهة|\s+أصول الحديث|$)/u) || [,''])[1]);
    return takhrij ? { ...row, takhrij } : row;
  } catch {
    return row;
  }
}

async function exactHadith(query) {
  const phrase = cleanInline(String(query || '').replace(/^"([\s\S]*)"$/u, '$1'));
  if (!phrase) return { requiresQuotes: true, results: [], elapsedSeconds: 0, url: `${SITE}/hadith/search` };

  const key = normalizeArabic(phrase);
  const cached = CACHE.get(key);
  if (cached && Date.now() - cached.time < CACHE_TTL) {
    CACHE.delete(key);
    CACHE.set(key, cached);
    return { ...cached.value, elapsedSeconds: 0.001, cached: true };
  }
  if (cached) CACHE.delete(key);

  const started = Date.now();
  const searchUrl = `${SITE}/hadith/search?q=${encodeURIComponent(phrase)}`;
  const searchHtml = await request(searchUrl);
  let links = extractHadithLinks(searchHtml);

  // API remains a discovery fallback; the authoritative detail page is parsed separately.
  try {
    const api = parseJsonp(await request(`${API}?skey=${encodeURIComponent(phrase)}&page=1`));
    const raw = String(api?.ahadith?.result || '');
    const apiLinks = extractHadithLinks(raw);
    links = [...new Set([...links, ...apiLinks])].slice(0, 12);
  } catch {}

  const rows = [];
  for (const url of links) {
    try {
      const row = parseDetailHadith(await request(url));
      if (!row) continue;
      const enriched = await enrichHadithTakhrij({ ...row, url });
      rows.push({ ...enriched, matchScore: phraseScore(phrase, enriched.text) });
    } catch {}
    if (rows.length >= 8) break;
  }

  rows.sort((a, b) => {
    const exact = Number(b.matchScore >= 0.95) - Number(a.matchScore >= 0.95);
    if (exact) return exact;
    const auth = Number(isAuthentic(b)) - Number(isAuthentic(a));
    return auth || b.matchScore - a.matchScore;
  });

  const wordCount = significantWords(phrase).length;
  const minScore = wordCount >= 5 ? 0.50 : wordCount >= 3 ? 0.60 : 0.75;
  const selected = rows.find(x => x.matchScore >= minScore);
  if (!selected) return { requiresQuotes: false, exactMatch: false, noMatch: true, results: [], elapsedSeconds: (Date.now() - started) / 1000, url: searchUrl };

  const value = {
    requiresQuotes: false,
    exactMatch: selected.matchScore >= 0.95,
    url: selected.url,
    results: [selected],
    elapsedSeconds: (Date.now() - started) / 1000
  };
  CACHE.set(key, { time: Date.now(), value });
  while (CACHE.size > CACHE_MAX) CACHE.delete(CACHE.keys().next().value);
  return value;
}

function parseExactSurahQuery(query) {
  const n = normalizeArabic(String(query || ''))
    .replace(/(?:تفسير|سوره|السوره|سورة|السورة)/gu, ' ')
    .replace(/(?:ايه|الاية|الايه|اية)\s*\d{1,3}/gu, ' ')
    .replace(/\s+/g, ' ').trim();
  if (!n) return null;
  const found = Object.entries(SURAH_ALIASES).find(([name]) => normalizeArabic(name) === n);
  return found ? { surahId: found[1], surahName: found[0] } : null;
}

function parseExactVerseQuery(query) {
  const raw = normalizeArabic(String(query || ''));
  if (/^(?:ايه|اية) الكرسي$/u.test(raw)) return { surahId: 2, surahName: 'البقرة', ayah: 255 };
  const n = raw
    .replace(/(?:تفسير|سوره|السوره|سورة|السورة)/gu, ' ')
    .replace(/(?:ايه|الاية|الايه|اية)/gu, ' ')
    .replace(/\s+/g, ' ').trim();
  const m = n.match(/^(.+?)\s+(\d{1,3})$/u);
  if (!m) return null;
  const found = Object.entries(SURAH_ALIASES).find(([name]) => normalizeArabic(name) === m[1]);
  const ayah = Number(m[2]);
  if (!found || !Number.isInteger(ayah) || ayah < 1 || ayah > 286) return null;
  return { surahId: found[1], surahName: found[0], ayah };
}

function parseRange(text) {
  const m = cleanInline(text).match(/الآيات\s*\(\s*(\d+)\s*[-–]\s*(\d+)\s*\)/u) || cleanInline(text).match(/الايات\s*\(\s*(\d+)\s*[-–]\s*(\d+)\s*\)/u);
  return m ? { from: Number(m[1]), to: Number(m[2]) } : null;
}

function tafseerSection(text) {
  const start = text.search(/#####\s*تفسير\s+الآيات\s*:/u);
  if (start < 0) return '';
  const tail = text.slice(start);
  const end = tail.search(/\n#####\s*(?:الفوائد|بلاغة|مقاصد|موضوعات|بيان المكي|مناسبة افتتاح)/u);
  return (end >= 0 ? tail.slice(0, end) : tail).replace(/^#####\s*[^\n]+\n?/, '').trim();
}

function parseVerseBlocks(text, range) {
  const section = tafseerSection(text) || String(text || '');
  const matches = [];
  const re = /(?:^|\n)\s*([^\n]{8,1200}?)\s*\((\d{1,3})\)\.?/gu;
  let m;

  while ((m = re.exec(section))) {
    const num = Number(m[2]);
    if (range && (num < range.from || num > range.to)) continue;
    matches.push({
      ayah: num,
      start: m.index + (m[0].startsWith('\n') ? 1 : 0),
      heading: cleanInline(m[1])
    });
  }

  const out = [];
  for (let i = 0; i < matches.length; i++) {
    const cur = matches[i];
    const next = matches[i + 1];
    let block = section.slice(cur.start, next ? next.start : section.length).trim();
    block = block.replace(/^\s+|\s+$/g, '').replace(/\n+/g, '\n').trim();
    if (block.length > 7000) block = `${block.slice(0, 6900).trim()}...`;
    if (block.length < 20) continue;
    out.push({ index: cur.ayah, text: block });
  }

  return out;
}

function nextPageFromHtml(html, surahId, current) {
  const re = new RegExp(`href\\s*=\\s*["'](?:${SITE.replace(/[.*+?^${}()|[\\]\\\\]/g, '\\\\$&')})?/tafseer/${surahId}/(\\d+)["']`, 'gi');
  const pages = [];
  let m;
  while ((m = re.exec(String(html || '')))) pages.push(Number(m[1]));
  const greater = pages.filter(x => x > current).sort((a, b) => a - b);
  return greater[0] || null;
}

async function fetchTafseerPage(surahId, page) {
  const url = `${SITE}/tafseer/${surahId}/${page}`;
  const html = await request(url);
  return { url, html, text: htmlToText(html), range: parseRange(html) };
}

async function exactTafseerSurah(ref) {
  const started = Date.now();
  const results = [];
  let page = 1;
  const visited = new Set();
  for (let guard = 0; guard < 80; guard++) {
    if (visited.has(page)) break;
    visited.add(page);
    const current = await fetchTafseerPage(ref.surahId, page);
    const blocks = parseVerseBlocks(current.text, current.range);
    results.push(...blocks.map(x => ({ index: x.index, text: x.text })));
    const next = nextPageFromHtml(current.html, ref.surahId, page);
    if (!next) break;
    page = next;
  }
  return {
    url: `${SITE}/tafseer/${ref.surahId}`,
    title: `تفسير سورة ${ref.surahName}`,
    total: results.length,
    elapsedSeconds: (Date.now() - started) / 1000,
    results,
    exactReference: { ...ref, ayah: null },
    largeSurah: results.length > 7
  };
}

async function resolveTafseerVersePage(surahId, ayah) {
  const start = Math.max(1, Math.ceil(ayah / 7));
  const candidates = [];
  for (let d = 0; d <= 6; d++) {
    if (start - d >= 1) candidates.push(start - d);
    if (d && start + d <= 80) candidates.push(start + d);
  }

  const seen = new Set();
  for (const page of candidates) {
    if (seen.has(page)) continue;
    seen.add(page);
    try {
      const current = await fetchTafseerPage(surahId, page);
      if (current.range && ayah >= current.range.from && ayah <= current.range.to) return current;
    } catch {}
  }
  return null;
}

async function exactTafseerVerse(ref) {
  const started = Date.now();
  const page = await resolveTafseerVersePage(ref.surahId, ref.ayah);
  if (!page) return { results: [], total: 0, elapsedSeconds: (Date.now() - started) / 1000, exactReference: ref };
  const blocks = parseVerseBlocks(page.text, page.range).filter(x => x.index === ref.ayah);
  return {
    url: page.url,
    title: `تفسير ${ref.surahName} — الآية ${ref.ayah}`,
    total: blocks.length,
    elapsedSeconds: (Date.now() - started) / 1000,
    results: blocks,
    exactReference: ref
  };
}

async function hadith(query, page = 1) {
  const url = `${SITE}/hadith/search?q=${encodeURIComponent(query)}&page=${Math.max(1, Number(page) || 1)}`;
  const html = await request(url);
  const links = extractHadithLinks(html);
  const rows = [];
  for (const link of links.slice(0, 8)) {
    try {
      const row = parseDetailHadith(await request(link));
      if (row) rows.push({ ...row, url: link });
    } catch {}
  }
  return { url, results: rows };
}

function searchUrlForSection(key, query, page) {
  const parameter = key === 'tafseer' ? 'q' : 'skeys';
  return `${SITE}/${key}/search?${parameter}=${encodeURIComponent(query)}&page=${Math.max(1, Number(page) || 1)}`;
}

function parseNumberedResults(html, limit = 15) {
  const text = htmlToText(html);
  const rows = [];
  const re = /(?:^|\n)\s*(\d+)\s*-\s*([^\n]{10,1400})/gu;
  let m;
  while ((m = re.exec(text)) && rows.length < limit) {
    const value = cleanInline(m[2]);
    if (value && !/^(?:البحث|فلترة نتائج البحث|روابط هامة)/u.test(value)) rows.push({ index: Number(m[1]), text: value });
  }
  return { rows, total: rows.length, elapsedSeconds: 0 };
}

async function section(section, query, page = 1, options = {}) {
  const key = SECTIONS[section] || section;
  if (!/^[a-z0-9-]+$/i.test(key)) throw new Error('قسم الدرر غير معروف. استخدم .درر قائمة');
  if (key === 'hadith') return hadith(query, page);
  if (key === 'tafseer') {
    const verse = parseExactVerseQuery(query);
    if (verse) return exactTafseerVerse(verse);
    const surah = parseExactSurahQuery(query);
    if (surah) return exactTafseerSurah(surah);
    return { clarification: true, message: '⚠️ حدد السورة، أو السورة مع رقم الآية.' };
  }
  const url = searchUrlForSection(key, query, page);
  const html = await request(url);
  const parsed = parseNumberedResults(html, Math.min(15, Number(options.pageSize) || 15));
  return { url, title: `موسوعة ${SECTION_TITLES[key] || section}`, ...parsed, results: parsed.rows };
}

async function globalSearch(query, page = 1) {
  const url = `${SITE}/site/search?skeys=${encodeURIComponent(query)}&page=${Math.max(1, Number(page) || 1)}`;
  const html = await request(url);
  return { url, title: 'نتائج البحث الشامل', ...parseNumberedResults(html, 15) };
}

function sectionList() {
  return ['حديث', 'تفسير', 'فقه', 'عقيدة', 'أديان', 'فرق', 'أصول', 'قواعد', 'أخلاق', 'آداب', 'تاريخ', 'لغة', 'منتشر'];
}

function extractTextFromMessage(message) {
  const m = message?.message || message || {};
  return m.conversation || m.extendedTextMessage?.text || m.imageMessage?.caption || m.videoMessage?.caption || m.documentMessage?.caption || '';
}

function extractHadithCandidates(text) {
  const source = cleanInline(text);
  if (!source) return [];
  const parts = source.split(/(?<=[.!؟؛])\s+/u).filter(x => x.length >= 20 && x.length <= 900);
  return parts.filter(x => /(النبي|رسول الله|قال|عن)/u.test(x)).slice(0, 10);
}

async function findHadithInText(text) {
  const candidates = extractHadithCandidates(text);
  const out = [];
  for (const candidate of candidates) {
    try {
      const r = await exactHadith(candidate);
      if (r.results?.[0]) out.push({ ...r.results[0], matchedText: candidate });
    } catch {}
  }
  return out.slice(0, 5);
}

export {
  SECTIONS, SECTION_TITLES, sectionList, section, hadith, globalSearch,
  extractTextFromMessage, extractHadithCandidates, findHadithInText,
  isAuthentic, parseExactVerseQuery, parseExactSurahQuery, exactHadith,
  exactTafseerVerse, exactTafseerSurah
};
