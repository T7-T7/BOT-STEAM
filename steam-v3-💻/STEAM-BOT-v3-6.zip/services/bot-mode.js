let developerMode = false;

export function setBotDeveloperMode(value) {
  developerMode = String(value || '').toLowerCase() === 'developer';
}

export function isBotDeveloper() {
  return developerMode;
}
