import {
  proto,
  generateWAMessageFromContent,
  prepareWAMessageMedia
} from '@whiskeysockets/baileys';

/* =========================================================
 * NATIVE BUTTON
 * ========================================================= */

function nativeButton(button) {
  return {
    name: String(button?.name || ''),
    buttonParamsJson: String(
      button?.buttonParamsJson || '{}'
    )
  };
}

/* =========================================================
 * BIZ NODE
 * ========================================================= */

function buildBizNode() {
  return {
    tag: 'biz',

    attrs: {
      actual_actors: '2',
      host_storage: '2',
      privacy_mode_ts: String(
        Math.floor(Date.now() / 1000)
      )
    },

    content: [
      {
        tag: 'interactive',

        attrs: {
          type: 'native_flow',
          v: '1'
        },

        content: [
          {
            tag: 'native_flow',

            attrs: {
              v: '9',
              name: 'mixed'
            }
          }
        ]
      }
    ]
  };
}

/* =========================================================
 * MENTIONS
 * ========================================================= */

function normalizeMentions(mentions) {
  if (!Array.isArray(mentions)) {
    return [];
  }

  return [
    ...new Set(
      mentions
        .map(value =>
          String(value || '').trim()
        )
        .filter(Boolean)
    )
  ];
}

/* =========================================================
 * SEND INTERACTIVE
 * =========================================================
 *
 * يدعم الآن:
 *
 * - text
 * - title
 * - footer
 * - buttons
 * - mentions
 * - quoted
 * - image
 *
 * image يمكن أن يكون Buffer.
 * ========================================================= */

export async function sendInteractive(
  sock,
  chatId,
  {
    text = '',
    title = '',
    footer = '',
    buttons = [],
    quoted = null,
    mentions = [],
    image = null
  } = {}
) {
  if (!sock?.relayMessage) {
    throw new Error(
      'اتصال WhatsApp غير متاح.'
    );
  }

  /* =======================================================
   * BUTTONS
   * ======================================================= */

  const nativeFlowButtons =
    (
      Array.isArray(buttons)
        ? buttons
        : []
    )
      .map(nativeButton)
      .filter(
        button =>
          button.name
      );

  /* =======================================================
   * MENTIONS
   * ======================================================= */

  const mentionedJid =
    normalizeMentions(
      mentions
    );

  const contextInfo = {
    ...(mentionedJid.length
      ? {
          mentionedJid
        }
      : {})
  };

  /* =======================================================
   * IMAGE MEDIA
   * ======================================================= */

  let preparedMedia = null;

  if (
    Buffer.isBuffer(image) &&
    image.length
  ) {
    preparedMedia =
      await prepareWAMessageMedia(
        {
          image
        },
        {
          upload:
            sock.waUploadToServer
        }
      );
  }

  /* =======================================================
   * HEADER
   * ======================================================= */

  const headerData = {
    title:
      String(title || ''),

    hasMediaAttachment:
      Boolean(preparedMedia)
  };

  if (
    preparedMedia?.imageMessage
  ) {
    headerData.imageMessage =
      preparedMedia.imageMessage;
  }

  /* =======================================================
   * INTERACTIVE MESSAGE
   * ======================================================= */

  const interactiveMessage =
    proto.Message.InteractiveMessage.create({
      body:
        proto.Message
          .InteractiveMessage
          .Body
          .create({
            text:
              String(text || '')
          }),

      footer:
        proto.Message
          .InteractiveMessage
          .Footer
          .create({
            text:
              String(footer || '')
          }),

      header:
        proto.Message
          .InteractiveMessage
          .Header
          .create(
            headerData
          ),

      nativeFlowMessage:
        proto.Message
          .InteractiveMessage
          .NativeFlowMessage
          .create({
            buttons:
              nativeFlowButtons,

            messageParamsJson:
              '{}',

            messageVersion:
              1
          }),

      contextInfo
    });

  /* =======================================================
   * BUILD MESSAGE
   * ======================================================= */

  const message =
    generateWAMessageFromContent(
      chatId,
      {
        viewOnceMessage: {
          message: {
            messageContextInfo: {
              deviceListMetadata: {},
              deviceListMetadataVersion: 2
            },

            interactiveMessage
          }
        }
      },
      {
        userJid:
          sock.user?.id,

        quoted
      }
    );

  /* =======================================================
   * ADDITIONAL NODES
   * ======================================================= */

  const additionalNodes = [
    buildBizNode()
  ];

  if (
    !String(chatId).endsWith('@g.us')
  ) {
    additionalNodes.unshift({
      tag: 'bot',

      attrs: {
        biz_bot: '1'
      }
    });
  }

  /* =======================================================
   * SEND
   * ======================================================= */

  await sock.relayMessage(
    chatId,
    message.message,
    {
      messageId:
        message.key.id,

      additionalNodes
    }
  );

  return message;
}

/* =========================================================
 * URL BUTTON
 * ========================================================= */

export function urlButton(
  displayText,
  url
) {
  return {
    name: 'cta_url',

    buttonParamsJson:
      JSON.stringify({
        display_text:
          String(
            displayText ||
            'فتح'
          ),

        url:
          String(url || ''),

        merchant_url:
          String(url || '')
      })
  };
}

/* =========================================================
 * QUICK REPLY
 * ========================================================= */

export function quickReply(
  displayText,
  id
) {
  return {
    name: 'quick_reply',

    buttonParamsJson:
      JSON.stringify({
        display_text:
          String(
            displayText ||
            'اختيار'
          ),

        id:
          String(id || '')
      })
  };
}

/* =========================================================
 * LIST BUTTON
 * ========================================================= */

export function listButton(
  title,
  sections
) {
  return {
    name: 'single_select',

    buttonParamsJson:
      JSON.stringify({
        title:
          String(
            title ||
            'اختيار'
          ),

        sections:
          Array.isArray(
            sections
          )
            ? sections
            : []
      })
  };
}