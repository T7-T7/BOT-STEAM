import { emit } from './bus.js';
import { runSerial } from './queue.js';
import { isBotDeveloper } from '../services/bot-mode.js';

export async function dispatch(ctx, command) {
  if (!command || !ctx?.message?.isGroup) {
    return false;
  }

  // أوامر المطور لا ينفذها البوت عندما يكون وضعه "ليس مطور".
  // استثناء اعداد حتى يستطيع المطور تغيير وضع البوت مرة أخرى.
  if (
    command.requiredRole === 'developer' &&
    command.name !== 'اعداد' &&
    !isBotDeveloper()
  ) {
    await ctx.message.reply('❌ البوت ليس في وضع المطور.');
    return false;
  }

  const task = () => command.execute(ctx);

  await emit('command:before', { ctx, command });

  const result = command.serial === true
    ? await runSerial(ctx.message.chatId, task)
    : await task();

  await emit('command:after', { ctx, command, result });

  return result;
}
