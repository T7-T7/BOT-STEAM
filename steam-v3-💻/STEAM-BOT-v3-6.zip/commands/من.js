export default {
name: 'من',
aliases: [],
category: 'إدارة',
requiredRole: 'user',

async execute(ctx) {
const { message, sock } = ctx;

const chatId =
  message?.chatId ||
  message?.key?.remoteJid;

if (!chatId?.endsWith('@g.us')) {
  return sock.sendMessage(chatId, {
    text: '❌ هذا الأمر يعمل داخل المجموعات فقط.'
  });
}

const text =
  Array.isArray(ctx.args)
    ? ctx.args.join(' ').trim()
    : '';

if (!text) {
  return sock.sendMessage(chatId, {
    text:
      '⚠️ اكتب النص بعد الأمر.\n\n' +
      'مثال:\n' +
      '.من يا شباب تعالوا'
  });
}

try {
  /*
   * لا نضع أي JID في النص.
   *
   * nonJidMentions = 1
   * يجعل الرسالة نفسها Mention جماعي
   * بدون كتابة @all أو أرقام الأعضاء.
   */
  await sock.sendMessage(
    chatId,
    {
      text,

      contextInfo: {
        nonJidMentions: 1
      }
    }
  );

} catch (error) {
  console.error(
    '[STEAM .من]',
    error
  );

  await sock.sendMessage(
    chatId,
    {
      text:
        `❌ تعذر تنفيذ المنشن الجماعي.\n` +
        `السبب: ${
          error?.message ||
          'خطأ غير معروف'
        }`
    }
  );
}

}
};