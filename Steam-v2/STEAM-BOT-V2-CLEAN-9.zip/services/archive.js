import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';

const ROOT = path.resolve(
  path.dirname(fileURLToPath(import.meta.url)),
  '../data/archives'
);

export function cleanArchiveName(value) {
  return String(value || '')
    .replace(/[\\/:*?"<>|]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function fileFor(name) {
  const safe = cleanArchiveName(name);
  if (!safe) throw new Error('اسم الأرشيف غير صالح.');
  return path.join(ROOT, `${safe}.json`);
}

export async function readArchive(name) {
  const safe = cleanArchiveName(name);
  if (!safe) throw new Error('اسم الأرشيف غير صالح.');

  try {
    const data = JSON.parse(await fs.readFile(fileFor(safe), 'utf8'));
    return {
      name: safe,
      entries: Array.isArray(data?.entries) ? data.entries : []
    };
  } catch {
    return { name: safe, entries: [] };
  }
}

export async function writeArchive(archive) {
  const safe = cleanArchiveName(archive?.name);
  if (!safe) throw new Error('اسم الأرشيف غير صالح.');

  await fs.mkdir(ROOT, { recursive: true });
  await fs.writeFile(
    fileFor(safe),
    JSON.stringify(
      { name: safe, entries: Array.isArray(archive.entries) ? archive.entries : [] },
      null,
      2
    )
  );
}

export function quotedText(ctx) {
  const q = ctx?.message?.quoted;
  return (
    q?.message?.conversation ||
    q?.message?.extendedTextMessage?.text ||
    q?.message?.imageMessage?.caption ||
    q?.message?.videoMessage?.caption ||
    q?.message?.documentMessage?.caption ||
    q?.text ||
    ''
  ).trim();
}

export function parseDirectAdd(value) {
  const match = String(value || '')
    .trim()
    .match(/^(.+?)\s*-\s*\[([\s\S]*)\]\s*$/u);

  if (!match) return null;

  const name = cleanArchiveName(match[1]);
  const content = String(match[2] || '').replace(/\r/g, '').trim();

  return name && content ? { name, content } : null;
}

export function commandPayload(ctx) {
  return String(ctx?.message?.text || '').trim()
    .replace(/^\.?(?:اضف|ارشيف|ت)(?:-)?/iu, '')
    .trim();
}
