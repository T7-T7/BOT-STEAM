import path from 'path';

import { entries } from '../heart/registry.js';

import {
  readSafeFile,
  walkProject,
  isSensitivePath
} from '../services/system-files.js';

import {
  sendInteractive
} from '../services/interactive.js';

const root = path.resolve('.');

function normalizeRel(value) {
  return String(value || '')
    .replaceAll(path.sep, '/')
    .replace(/^\.\//, '');
}

function commandList() {
  return entries()
    .filter(command => {
      const file = command?.file
        ? normalizeRel(
            path.relative(
              root,
              command.file
            )
          )
        : '';

      return file && !isSensitivePath(file);
    })
    .sort((a, b) =>
      String(a.name).localeCompare(
        String(b.name),
        'ar'
      )
    );
}

function folderLabel(dir) {
  return `#${dir}`;
}

function orderedProjectFiles(files, dirs) {
  const allDirs = [...dirs]
    .filter(Boolean)
    .sort((a, b) =>
      a.localeCompare(b, 'ar')
    );

  const ordered = [];

  for (const dir of allDirs) {
    const directFiles = files
      .filter(
        file =>
          path.posix.dirname(file) === dir
      )
      .sort((a, b) =>
        a.localeCompare(b, 'ar')
      );

    ordered.push(
      ...directFiles
    );
  }

  const rootFiles = files
    .filter(
      file =>
        !file.includes('/')
    )
    .sort((a, b) =>
      a.localeCompare(b, 'ar')
    );

  ordered.push(
    ...rootFiles
  );

  return ordered;
}

function buildTreeMessage(files, dirs) {
  const lines = [
    '📁 *ملفات سيستم:*',
    ''
  ];

  const allDirs = [...dirs]
    .filter(Boolean)
    .sort((a, b) =>
      a.localeCompare(b, 'ar')
    );

  const orderedFiles =
    orderedProjectFiles(
      files,
      dirs
    );

  const numberByFile =
    new Map(
      orderedFiles.map(
        (file, index) => [
          file,
          index + 1
        ]
      )
    );

  for (const dir of allDirs) {
    const directFiles = files
      .filter(
        file =>
          path.posix.dirname(file) === dir
      )
      .sort((a, b) =>
        a.localeCompare(b, 'ar')
      );

    const directDirs =
      allDirs.filter(
        child =>
          child !== dir &&
          child.startsWith(
            `${dir}/`
          ) &&
          !child
            .slice(dir.length + 1)
            .includes('/')
      );

    if (
      !directFiles.length &&
      !directDirs.length
    ) {
      continue;
    }

    lines.push(
      `📁 ${folderLabel(dir)}`
    );

    for (const file of directFiles) {
      lines.push(
        `📄 #${numberByFile.get(file)} ${path.posix.basename(file)}`
      );
    }

    if (directDirs.length) {
      lines.push('');
    }
  }

  const rootFiles = files
    .filter(
      file =>
        !file.includes('/')
    )
    .sort((a, b) =>
      a.localeCompare(b, 'ar')
    );

  for (const file of rootFiles) {
    lines.push(
      `📄 #${numberByFile.get(file)} ${file}`
    );
  }

  lines.push('');
  lines.push(
    `📦 # ${orderedFiles.length} ملف`
  );

  return lines.join('\n');
}

function decode(value) {
  return Buffer
    .from(value, 'base64url')
    .toString('utf8');
}

function fileStats(source) {
  const bytes =
    Buffer.byteLength(
      source,
      'utf8'
    );

  const kb =
    bytes / 1024;

  const size =
    kb >= 1024
      ? `${(
          kb / 1024
        ).toFixed(2)} MB`
      : `${kb.toFixed(2)} KB`;

  const lines =
    source.length
      ? source.split(
          /\r\n|\r|\n/
        ).length
      : 0;

  return {
    size,
    lines
  };
}

/*
 * عرض الملف كنص عادي
 * مع زر Native Flow لنسخ محتوى الملف فقط.
 */
async function sendRichCode(ctx, rel) {
  if (isSensitivePath(rel)) {
    return ctx.message.reply(
      '❌ هذا الملف محمي ولا يمكن عرضه.'
    );
  }

  const data =
    await readSafeFile(rel);

  const source =
    data.toString('utf8');

  if (!source.trim()) {
    return ctx.message.reply(
      '⚠️ الملف فارغ ولا يوجد كود لعرضه.'
    );
  }

  const fileName =
    path.posix.basename(
      normalizeRel(rel)
    );

  const relativePath =
    normalizeRel(rel);

  const {
    size,
    lines
  } =
    fileStats(source);

  /*
   * النص الظاهر فوق الكود.
   *
   * source يبقى منفصلًا حتى يكون
   * copy_code هو الكود فقط.
   */
  const text = [
    `📄 *${fileName}*`,
    '',
    `📦 ${size} | 📋 ${lines} سطر`,
    `📁 : ${relativePath}`,
    '',
    source
  ].join('\n');

  /*
   * زر نسخ Native Flow.
   *
   * copy_code = محتوى الملف فقط.
   */
  const copyButton = {
    name: 'cta_copy',

    buttonParamsJson:
      JSON.stringify({
        display_text: '📋 نسخ',

        id: 'steam-copy-file',

        copy_code: source
      })
  };

  try {
    return await sendInteractive(
      ctx.sock,
      ctx.message.chatId,
      {
        text,

        buttons: [
          copyButton
        ],

        quoted:
          ctx.message.raw
      }
    );
  } catch (error) {
    console.error(
      '[SYSTEM FILE VIEW]',
      error
    );

    /*
     * في حالة فشل Native Flow،
     * لا نخفي الملف عن المستخدم.
     */
    return ctx.message.reply(
      [
        text,
        '',
        '⚠️ تعذر إظهار زر النسخ.'
      ].join('\n')
    );
  }
}

export default {
  name: 'سيستم',

  category: 'نظام',

  aliases: [
    'system'
  ],

  requiredRole:
    'developer',

  async execute(ctx) {
    const {
      message,
      args
    } = ctx;

    const arg =
      String(
        args?.[0] || ''
      ).trim();

    /*
     * .سيستم al
     */
    if (
      arg.toLowerCase() ===
      'al'
    ) {
      const {
        createProjectZip
      } =
        await import(
          '../services/project-pack.js'
        );

      const zip =
        await createProjectZip();

      return message.reply(
        {
          document: zip,

          mimetype:
            'application/zip',

          fileName:
            'STEAM-BOT-v3.zip'
        },
        {
          caption:
            '📦 *STEAM-BOT-v3.zip*\n\n' +
            '✅ نسخة نظيفة وجاهزة للتشغيل.'
        }
      );
    }

    const {
      files,
      dirs
    } =
      await walkProject();

    const orderedFiles =
      orderedProjectFiles(
        files,
        dirs
      );

    const number =
      Number(arg);

    /*
     * .سيستم رقم
     */
    if (
      Number.isInteger(number) &&
      number > 0
    ) {
      const selected =
        orderedFiles[
          number - 1
        ];

      if (!selected) {
        return message.reply(
          '⚠️ رقم الملف غير صحيح.'
        );
      }

      return sendRichCode(
        ctx,
        selected
      );
    }

    /*
     * .سيستم
     */
    return message.reply(
      [
        buildTreeMessage(
          files,
          dirs
        ),

        '',

        '• استخدم `.سيستم 1` لعرض ملف الأمر رقم 1 فقط.',

        '• الملفات الحساسة والسرية محجوبة تلقائيًا.',

        '• استخدم `.سيستم al` لإرسال نسخة كاملة نظيفة.'
      ].join('\n')
    );
  }
};