import { jidNormalizedUser } from '@whiskeysockets/baileys';
import { getCachedGroupMetadata, setGroupMetadata } from './group-cache.js';
import { ROLES, hasRole } from '../security/roles.js';

export function isGroupMessage(message) {
  return Boolean(
    message?.isGroup ||
    String(message?.chatId || '').endsWith('@g.us')
  );
}

export function assertGroup(message) {
  if (!isGroupMessage(message)) {
    throw new Error('هذا الأمر يعمل داخل المجموعات فقط.');
  }
}

function same(a, b) {
  if (!a || !b) return false;
  try {
    return jidNormalizedUser(String(a)) === jidNormalizedUser(String(b));
  } catch {
    return String(a).split(':')[0].toLowerCase() === String(b).split(':')[0].toLowerCase();
  }
}

function isAdmin(participant) {
  return Boolean(
    participant?.admin === 'admin' ||
    participant?.admin === 'superadmin' ||
    participant?.isAdmin ||
    participant?.isSuperAdmin
  );
}

export async function getGroupMetadata(sock, jid, { fresh = false } = {}) {
  assertGroup({ isGroup: String(jid || '').endsWith('@g.us'), chatId: jid });

  if (!fresh) {
    const cached = getCachedGroupMetadata(jid);
    if (cached) return cached;
  }

  const metadata = await sock.groupMetadata(jid);
  setGroupMetadata(metadata);
  return metadata;
}

export async function groupContext(ctx, options = {}) {
  const { message, sock } = ctx;
  assertGroup(message);

  const metadata = await getGroupMetadata(sock, message.chatId, options);
  const meIds = [
    sock.user?.id,
    sock.user?.lid,
    sock.user?.phoneNumber,
    message.raw?.key?.participantAlt
  ].filter(Boolean);

  const me = metadata.participants.find(p =>
    meIds.some(id => same(p.id, id) || same(p.lid, id) || same(p.phoneNumber, id))
  );

  if (!isAdmin(me)) {
    throw new Error('❌ يجب أن يكون البوت مشرفًا في المجموعة أولًا.');
  }

  return { metadata, me, botAdmin: true };
}

/*
 * تحقق أن مُرسل الأمر هو مشرف فعلي داخل المجموعة على واتساب
 * (وليس فقط أن البوت نفسه مشرف).
 *
 * بدون هذا الفحص كان أي عضو عادي في المجموعة يقدر يستخدم
 * أوامر الطرد/رفع أو إزالة الإشراف/تغيير اسم أو صورة المجموعة
 * لمجرد أن البوت مشرف — وهي ثغرة خطيرة تسمح بالاستيلاء على المجموعة.
 *
 * أعضاء "نخبة" أو "مطور" في البوت نفسه مستثنون من هذا الشرط.
 */
export function assertSenderCanManageGroup(ctx, metadata) {
  if (hasRole(ctx?.role, ROLES.DEVELOPER) || hasRole(ctx?.role, ROLES.ELITE)) return;

  const sender = ctx?.message?.sender;
  const participant = findParticipant(metadata, sender);

  if (!isAdmin(participant)) {
    throw new Error('❌ هذا الأمر متاح فقط لمشرفي المجموعة على واتساب.');
  }
}

export function findParticipant(metadata, target) {
  if (!target) return null;
  return metadata.participants.find(p =>
    same(p.id, target) || same(p.lid, target) || same(p.phoneNumber, target)
  ) || null;
}

export function targetFromMessage(message) {
  const quoted = message?.quoted;
  if (quoted?.participant) return quoted.participant;
  if (quoted?.participantAlt) return quoted.participantAlt;

  const mentioned = message?.mentions?.[0];
  if (mentioned) return mentioned;

  return null;
}

export function participantJid(participant) {
  return participant?.id || participant?.lid || participant?.phoneNumber || null;
}

export function participantNumber(participant) {
  const value = participantJid(participant);
  return String(value || '').split('@')[0].split(':')[0].replace(/\D/g, '');
}

export function isParticipantAdmin(participant) {
  return isAdmin(participant);
}
