'use strict';

import {
  downloadMediaMessage
} from '@whiskeysockets/baileys';

/* =========================================================
 * CONFIG
 * ========================================================= */

const API_URL =
  'https://api2.pixelcut.app/image/matte/v1';

const MAX_INPUT_SIZE =
  50 * 1024 * 1024;

const REQUEST_TIMEOUT =
  120000;

/* =========================================================
 * MIME
 * ========================================================= */

function cleanMime(value) {
  return String(value || '')
    .toLowerCase()
    .split(';')[0]
    .trim();
}

/* =========================================================
 * MEDIA MESSAGE
 * ========================================================= */

function getImageMessage(message) {
  if (!message) {
    return null;
  }

  /*
   * صورة مباشرة
   */
  if (message.imageMessage) {
    return {
      key: 'imageMessage',
      data: message.imageMessage
    };
  }

  /*
   * View Once
   */
  if (
    message.viewOnceMessage?.message
  ) {
    return getImageMessage(
      message.viewOnceMessage.message
    );
  }

  if (
    message.viewOnceMessageV2?.message
  ) {
    return getImageMessage(
      message.viewOnceMessageV2.message
    );
  }

  if (
    message
      .viewOnceMessageV2Extension
      ?.message
  ) {
    return getImageMessage(
      message
        .viewOnceMessageV2Extension
        .message
    );
  }

  return null;
}

/* =========================================================
 * QUOTED MESSAGE
 * ========================================================= */

function getQuotedMessage(message) {
  const raw =
    message?.raw;

  if (!raw?.message) {
    return null;
  }

  for (
    const value
    of Object.values(raw.message)
  ) {
    if (
      value?.contextInfo?.quotedMessage
    ) {
      return {
        message:
          value
            .contextInfo
            .quotedMessage,

        context:
          value.contextInfo
      };
    }
  }

  return null;
}

/* =========================================================
 * DOWNLOAD MEDIA
 * ========================================================= */

async function downloadImage(
  sock,
  message
) {
  const image =
    getImageMessage(message);

  if (!image) {
    return null;
  }

  const mime =
    cleanMime(
      image.data?.mimetype
    );

  if (
    mime &&
    !mime.startsWith('image/')
  ) {
    return null;
  }

  const buffer =
    await downloadMediaMessage(
      {
        message: {
          [image.key]:
            image.data
        }
      },
      'buffer',
      {},
      {
        logger: console,

        reuploadRequest:
          sock.updateMediaMessage
      }
    );

  if (
    !Buffer.isBuffer(buffer) ||
    !buffer.length
  ) {
    return null;
  }

  if (
    buffer.length >
    MAX_INPUT_SIZE
  ) {
    throw new Error(
      'حجم الصورة أكبر من 50MB.'
    );
  }

  return {
    buffer,
    mime:
      mime || 'image/jpeg'
  };
}

/* =========================================================
 * REMOVE BACKGROUND API
 * ========================================================= */

async function removeBackground(
  imageBuffer,
  filename = 'image.jpg'
) {
  const form =
    new FormData();

  form.append(
    'format',
    'png'
  );

  form.append(
    'model',
    'v1'
  );

  form.append(
    'image',
    new Blob(
      [imageBuffer],
      {
        type:
          'image/jpeg'
      }
    ),
    filename
  );

  const controller =
    new AbortController();

  const timeout =
    setTimeout(
      () =>
        controller.abort(),
      REQUEST_TIMEOUT
    );

  try {
    const response =
      await fetch(
        API_URL,
        {
          method: 'POST',

          headers: {
            Accept:
              'application/json,text/plain,*/*',

            'x-locale':
              'en',

            'x-client-version':
              'web:pixa.com:4a5b0af2',

            'User-Agent':
              'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/131.0.0.0 Safari/537.36',

            Origin:
              'https://remove-image-background-v2.vercel.app',

            Referer:
              'https://remove-image-background-v2.vercel.app/'
          },

          body:
            form,

          signal:
            controller.signal
        }
      );

    const contentType =
      cleanMime(
        response.headers.get(
          'content-type'
        )
      );

    if (!response.ok) {
      let errorText = '';

      try {
        if (
          contentType ===
          'application/json'
        ) {
          const json =
            await response.json();

          errorText =
            json?.error ||
            json?.message ||
            '';
        } else {
          errorText =
            await response.text();
        }
      } catch {}

      throw new Error(
        errorText ||
        `الخدمة أعادت HTTP ${response.status}.`
      );
    }

    const arrayBuffer =
      await response.arrayBuffer();

    const result =
      Buffer.from(arrayBuffer);

    if (!result.length) {
      throw new Error(
        'الخدمة لم تُرجع صورة.'
      );
    }

    return result;

  } finally {
    clearTimeout(
      timeout
    );
  }
}

/* =========================================================
 * DELETE MESSAGE
 * ========================================================= */

async function deleteMessage(
  sock,
  chatId,
  key
) {
  if (!key) {
    return;
  }

  try {
    await sock.sendMessage(
      chatId,
      {
        delete: key
      }
    );
  } catch {
    // تجاهل فشل حذف رسالة الانتظار
  }
}

/* =========================================================
 * COMMAND
 * ========================================================= */

export default {
  name: 'ازالة خلفية',

  aliases: [
    'اذالة_خلفية',
    'ازالة_خلفية',
    'إزالة_خلفية',
    'إزالة خلفية',
    'removebg',
    'rmbg',
    'نظف_الصورة'
  ],

  category: 'وسائط',

  requiredRole: 'user',

  async execute(ctx) {
    const {
      message,
      sock
    } = ctx;

    if (
      !message?.chatId ||
      !sock
    ) {
      return false;
    }

    let media = null;

    try {
      /* =====================================================
       * 1. محاولة الحصول على الصورة من Reply
       * ===================================================== */

      const quoted =
        getQuotedMessage(
          message
        );

      if (quoted) {
        media =
          await downloadImage(
            sock,
            quoted.message
          );
      }

      /* =====================================================
       * 2. إذا لم توجد صورة في Reply
       *    نحاول الصورة نفسها
       * ===================================================== */

      if (!media) {
        const raw =
          message.raw;

        media =
          await downloadImage(
            sock,
            raw?.message
          );
      }

      /* =====================================================
       * لا توجد صورة
       * ===================================================== */

      if (!media) {
        await message.reply(
          [
            '✂️ *إزالة خلفية الصور*',
            '',
            '⚡ *طريقة الاستخدام:*',
            '',
            '1️⃣ رد على أي صورة بالأمر `.ازالة_خلفية`',
            '',
            '2️⃣ أو أرسل الصورة مع الأمر في نفس الرسالة.'
          ].join('\n')
        );

        return true;
      }

      /* =====================================================
       * Processing
       * ===================================================== */

      await message.react?.(
        '✂️'
      ).catch?.(
        () => {}
      );

      const waiting =
        await message.reply(
          [
            '✂️ *جاري إزالة الخلفية...*',
            '',
            '⏱️ قد تستغرق العملية بعض الوقت.'
          ].join('\n')
        );

      try {
        /* ===================================================
         * API
         * =================================================== */

        const result =
          await removeBackground(
            media.buffer,
            'image.jpg'
          );

        /* ===================================================
         * حذف رسالة الانتظار
         * =================================================== */

        await deleteMessage(
          sock,
          message.chatId,
          waiting?.key
        );

        /* ===================================================
         * إرسال النتيجة
         * =================================================== */

        await sock.sendMessage(
          message.chatId,
          {
            image:
              result,

            mimetype:
              'image/png',

            caption:
              [
                '✂️ *تمت إزالة الخلفية بنجاح*',
                '',
                '> 𓂃 ࣪˖ ִֶָ⚜️ 𝑺𝑻𝑬𝑨𝑴 𝑩𝑶𝑻 ♖ ִֶָ ˖ ࣪'
              ].join('\n')
          },
          {
            quoted:
              message.raw
          }
        );

        await message.react?.(
          '✅'
        ).catch?.(
          () => {}
        );

      } catch (error) {
        await deleteMessage(
          sock,
          message.chatId,
          waiting?.key
        );

        throw error;
      }

      return true;

    } catch (error) {
      console.error(
        '[REMOVE-BG]',
        error
      );

      await message.react?.(
        '❌'
      ).catch?.(
        () => {}
      );

      let reason =
        error?.message ||
        'خطأ غير معروف.';

      if (
        error?.name ===
        'AbortError'
      ) {
        reason =
          'انتهت مهلة الاتصال بالخدمة.';
      }

      await message.reply(
        [
          '❌ *تعذر إزالة الخلفية.*',
          '',
          `السبب: ${reason}`
        ].join('\n')
      );

      return true;
    }
  }
};