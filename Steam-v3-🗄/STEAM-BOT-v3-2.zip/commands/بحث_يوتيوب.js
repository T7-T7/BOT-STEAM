import ytsearch from 'yt-search';

import {
  proto,
  generateWAMessageFromContent,
  prepareWAMessageMedia
} from '@whiskeysockets/baileys';

/* =========================================================
 * CONSTANTS
 * ========================================================= */

const FOOTER =
  '𓂃 ࣪˖ ִֶָ⚜️ 𝑺𝑻𝑬𝑨𝑴 𝑩𝑶𝑻 ♖ ִֶָ ˖ ࣪';

const USER_AGENT =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) ' +
  'AppleWebKit/537.36 (KHTML, like Gecko) ' +
  'Chrome/131.0.0.0 Safari/537.36';

/* =========================================================
 * FORBIDDEN
 * ========================================================= */

const BLOCKED = [
  /اغنيه|اغنية|أغنية|اغاني|أغاني|موسيقى|موسيق/i,
  /music|song|songs|remix|ريمكس|راب|rap/i,
  /كليب|clip|حفله|حفلة|concert|dj/i,
  /lyrics|lyric|البوم|ألبوم|album/i,
  /single|سينجل|مطرب|مطربة|مغني|مغنية/i
];

function forbidden(text) {
  return BLOCKED.some(regex =>
    regex.test(String(text || ''))
  );
}

/* =========================================================
 * CLEAN
 * ========================================================= */

function clean(value) {
  return String(value || '')
    .replace(/\s+/g, ' ')
    .trim();
}

/* =========================================================
 * YOUTUBE ID
 * ========================================================= */

function getYoutubeId(url) {
  try {
    const parsed = new URL(url);

    const host =
      parsed.hostname.toLowerCase();

    if (
      host === 'youtu.be' ||
      host.endsWith('.youtu.be')
    ) {
      const id =
        parsed.pathname
          .split('/')
          .filter(Boolean)[0];

      return id &&
        /^[a-zA-Z0-9_-]{11}$/.test(id)
        ? id
        : null;
    }

    if (
      host === 'youtube.com' ||
      host === 'www.youtube.com' ||
      host === 'm.youtube.com' ||
      host === 'music.youtube.com' ||
      host.endsWith('.youtube.com')
    ) {
      const id =
        parsed.searchParams.get('v');

      if (
        id &&
        /^[a-zA-Z0-9_-]{11}$/.test(id)
      ) {
        return id;
      }

      const parts =
        parsed.pathname
          .split('/')
          .filter(Boolean);

      for (const part of parts) {
        if (
          /^[a-zA-Z0-9_-]{11}$/.test(part)
        ) {
          return part;
        }
      }
    }

    return null;
  } catch {
    return null;
  }
}

/* =========================================================
 * DURATION
 * ========================================================= */

function durationToSeconds(value) {
  const text =
    String(value || '').trim();

  if (!text) {
    return null;
  }

  const parts =
    text.split(':').map(Number);

  if (
    parts.length < 2 ||
    parts.some(
      value =>
        !Number.isFinite(value)
    )
  ) {
    return null;
  }

  if (parts.length === 3) {
    return (
      parts[0] * 3600 +
      parts[1] * 60 +
      parts[2]
    );
  }

  return (
    parts[0] * 60 +
    parts[1]
  );
}

/* =========================================================
 * VIEWS
 * ========================================================= */

function formatViews(value) {
  const views = Number(value);

  if (
    !Number.isFinite(views) ||
    views <= 0
  ) {
    return 'غير معروف';
  }

  return views.toLocaleString('en-US');
}

/* =========================================================
 * DURATION QUERY
 * ========================================================= */

function parseDurationQuery(input) {
  const text = clean(input);

  const match =
    text.match(
      /(\d+(?:\.\d+)?)\s*(ثانية|ثواني|ثانيه|ث|دقيقة|دقائق|دقيقه|د|min|mins|minute|minutes|sec|secs|second|seconds)\b/iu
    );

  if (!match) {
    return {
      query: text,
      duration: null
    };
  }

  const number =
    Number(match[1]);

  const unit =
    match[2];

  const minutes =
    /دقيقة|دقائق|دقيقه|^د$|^min$|^mins$|minute|minutes/i.test(
      unit
    );

  const seconds =
    number * (minutes ? 60 : 1);

  return {
    query:
      clean(
        text.replace(
          match[0],
          ''
        )
      ),

    duration:
      Number.isFinite(seconds) &&
      seconds > 0
        ? seconds
        : null
  };
}

/* =========================================================
 * NORMALIZE VIDEO
 * ========================================================= */

function normalizeVideo(video) {
  const url =
    video?.url ||
    (
      video?.videoId
        ? `https://www.youtube.com/watch?v=${video.videoId}`
        : ''
    );

  const id =
    getYoutubeId(url) ||
    video?.videoId ||
    null;

  const duration =
    clean(
      video?.timestamp ||
      video?.duration ||
      ''
    );

  return {
    id,

    url,

    title:
      clean(
        video?.title ||
        'بدون عنوان'
      ),

    channel:
      clean(
        video?.author?.name ||
        video?.author ||
        video?.channel ||
        'غير معروف'
      ),

    thumbnail:
      video?.image ||
      video?.thumbnail ||
      video?.thumb ||
      (
        id
          ? `https://i.ytimg.com/vi/${id}/hqdefault.jpg`
          : ''
      ),

    duration,

    durationSeconds:
      durationToSeconds(
        duration
      ),

    views:
      Number(video?.views) || 0
  };
}

/* =========================================================
 * SEARCH
 * ========================================================= */

async function searchYoutube(query) {
  const result =
    await ytsearch(query);

  const videos =
    Array.isArray(result?.videos)
      ? result.videos
      : [];

  const results = [];
  const seen = new Set();

  for (const raw of videos) {
    const video =
      normalizeVideo(raw);

    if (
      !video.id ||
      !video.url ||
      !video.title
    ) {
      continue;
    }

    if (
      forbidden(
        `${video.title} ${video.channel}`
      )
    ) {
      continue;
    }

    if (
      seen.has(video.id)
    ) {
      continue;
    }

    seen.add(video.id);

    results.push(video);

    if (
      results.length >= 8
    ) {
      break;
    }
  }

  return results;
}

/* =========================================================
 * THUMBNAIL
 * ========================================================= */

async function getThumbnail(url) {
  if (!url) {
    return null;
  }

  try {
    const response =
      await fetch(url, {
        headers: {
          'User-Agent':
            USER_AGENT
        },

        signal:
          AbortSignal.timeout(
            15000
          )
      });

    if (!response.ok) {
      return null;
    }

    const type =
      response.headers.get(
        'content-type'
      ) || '';

    if (
      !type.startsWith('image/')
    ) {
      return null;
    }

    const arrayBuffer =
      await response.arrayBuffer();

    const buffer =
      Buffer.from(arrayBuffer);

    if (!buffer.length) {
      return null;
    }

    return buffer;
  } catch (error) {
    console.error(
      '[بحث_يوتيوب:thumbnail]',
      error?.message || error
    );

    return null;
  }
}

/* =========================================================
 * CARD BODY
 * ========================================================= */

function buildCardBody(video, index) {
  return [
    `🎬 *${index + 1}. ${video.title}*`,
    '',
    `👤 القناة: ${video.channel || 'غير معروف'}`,
    `👁️ المشاهدات: ${formatViews(video.views)}`,
    `⏱️ المدة: ${video.duration || 'غير معروفة'}`,
    '',
    `🔗 ${video.url}`
  ].join('\n');
}

/* =========================================================
 * NATIVE BUTTON
 * ========================================================= */

function nativeButton(name, params) {
  return {
    name,

    buttonParamsJson:
      JSON.stringify(params)
  };
}

/* =========================================================
 * BUILD CARD
 * ========================================================= */

async function buildCard(
  video,
  index,
  sock
) {
  let imageMessage = null;

  const thumbnail =
    await getThumbnail(
      video.thumbnail
    );

  if (thumbnail) {
    try {
      const prepared =
        await prepareWAMessageMedia(
          {
            image: thumbnail
          },
          {
            upload:
              sock.waUploadToServer
          }
        );

      imageMessage =
        prepared?.imageMessage ||
        null;
    } catch (error) {
      console.error(
        '[بحث_يوتيوب:media]',
        error?.message || error
      );
    }
  }

  /* =======================================================
   * AUDIO BUTTON
   * ======================================================= */

  const audioButton =
    nativeButton(
      'quick_reply',
      {
        display_text:
          '🎵 تنزيل الصوت',

        id:
          `.صوت ${video.url}`
      }
    );

  /* =======================================================
   * URL BUTTON
   * ======================================================= */

  const urlButton =
    nativeButton(
      'cta_url',
      {
        display_text:
          '▶️ فتح الفيديو',

        url:
          video.url,

        merchant_url:
          video.url
      }
    );

  /* =======================================================
   * BODY
   * ======================================================= */

  const body =
    proto.Message
      .InteractiveMessage
      .Body.fromObject({
        text:
          buildCardBody(
            video,
            index
          )
      });

  /* =======================================================
   * FOOTER
   * ======================================================= */

  const footer =
    proto.Message
      .InteractiveMessage
      .Footer.fromObject({
        text:
          FOOTER
      });

  /* =======================================================
   * HEADER
   * ======================================================= */

  const headerData = {
    title:
      '🎬 YouTube',

    hasMediaAttachment:
      Boolean(imageMessage)
  };

  if (imageMessage) {
    headerData.imageMessage =
      imageMessage;
  }

  const header =
    proto.Message
      .InteractiveMessage
      .Header.fromObject(
        headerData
      );

  /* =======================================================
   * NATIVE FLOW
   * ======================================================= */

  const nativeFlow =
    proto.Message
      .InteractiveMessage
      .NativeFlowMessage.fromObject({
        buttons: [
          audioButton,
          urlButton
        ],

        messageParamsJson:
          '{}',

        messageVersion:
          1
      });

  /* =======================================================
   * CARD
   * ======================================================= */

  return proto.Message
    .InteractiveMessage
    .fromObject({
      body,

      footer,

      header,

      nativeFlowMessage:
        nativeFlow
    });
}

/* =========================================================
 * BUILD CAROUSEL
 * ========================================================= */

async function buildCarousel(
  videos,
  sock,
  query
) {
  const cards = [];

  for (
    let i = 0;
    i < videos.length;
    i++
  ) {
    try {
      const card =
        await buildCard(
          videos[i],
          i,
          sock
        );

      cards.push(card);
    } catch (error) {
      console.error(
        '[بحث_يوتيوب:card]',
        error?.message || error
      );
    }
  }

  if (!cards.length) {
    throw new Error(
      'فشل إنشاء بطاقات النتائج.'
    );
  }

  const carousel =
    proto.Message
      .InteractiveMessage
      .CarouselMessage.fromObject({
        cards
      });

  return proto.Message
    .InteractiveMessage
    .fromObject({
      body:
        proto.Message
          .InteractiveMessage
          .Body.fromObject({
            text:
              `🔎 *نتائج YouTube عن:*\n${query}\n\n↔️ اسحب البطاقات لعرض المزيد`
          }),

      footer:
        proto.Message
          .InteractiveMessage
          .Footer.fromObject({
            text:
              FOOTER
          }),

      header:
        proto.Message
          .InteractiveMessage
          .Header.fromObject({
            title:
              '🎬 بحث YouTube',

            hasMediaAttachment:
              false
          }),

      carouselMessage:
        carousel
    });
}

/* =========================================================
 * COMMAND
 * ========================================================= */

export default {
  name:
    'بحث_يوتيوب',

  aliases: [
    'بحث يوتيوب',
    'يوتيوب_بحث',
    'youtube_search',
    'بحث_يوت'
  ],

  category:
    'وسائط',

  requiredRole:
    'user',

  description:
    'البحث عن فيديوهات YouTube وعرضها كبطاقات',

  async execute(ctx) {
    const {
      message,
      sock
    } = ctx;

    if (
      !message?.chatId ||
      !sock
    ) {
      return false;
    }

    const args =
      Array.isArray(ctx.args)
        ? ctx.args
        : [];

    const input =
      clean(
        args.join(' ')
      );

    if (!input) {
      return message.reply(
        [
          '📘 *بحث YouTube*',
          '',
          '🔎 الاستخدام:',
          '`.بحث_يوتيوب <كلمة البحث>`',
          '',
          '⏱️ البحث حسب المدة:',
          '`.بحث_يوتيوب 3 دقائق محمد رمضان`',
          '',
          'مثال:',
          '`.بحث_يوتيوب محمد رمضان`'
        ].join('\n')
      );
    }

    if (
      forbidden(input)
    ) {
      return message.reply(
        '🚫 هذا النوع من المحتوى محظور.'
      );
    }

    let loading = null;

    try {
      /* =====================================================
       * LOADING
       * ===================================================== */

      try {
        loading =
          await message.reply(
            '🔎 جاري البحث في YouTube...'
          );
      } catch {}

      /* =====================================================
       * QUERY
       * ===================================================== */

      const parsed =
        parseDurationQuery(
          input
        );

      if (!parsed.query) {
        throw new Error(
          'اكتب اسم الفيديو أو كلمة البحث.'
        );
      }

      /* =====================================================
       * SEARCH
       * ===================================================== */

      let videos =
        await searchYoutube(
          parsed.query
        );

      /* =====================================================
       * DURATION FILTER
       * ===================================================== */

      if (
        parsed.duration != null
      ) {
        videos =
          videos
            .map(video => ({
              ...video,

              difference:
                Number.isFinite(
                  video.durationSeconds
                )
                  ? Math.abs(
                      video.durationSeconds -
                      parsed.duration
                    )
                  : Infinity
            }))
            .sort(
              (a, b) =>
                a.difference -
                b.difference
            )
            .slice(0, 8);
      }

      videos =
        videos.slice(0, 8);

      if (!videos.length) {
        throw new Error(
          'لم يتم العثور على نتائج مناسبة.'
        );
      }

      /* =====================================================
       * DELETE LOADING
       * ===================================================== */

      try {
        if (
          loading?.key &&
          typeof sock.sendMessage ===
            'function'
        ) {
          await sock.sendMessage(
            message.chatId,
            {
              delete:
                loading.key
            }
          );
        }
      } catch {}

      /* =====================================================
       * BUILD CAROUSEL
       * ===================================================== */

      const interactive =
        await buildCarousel(
          videos,
          sock,
          parsed.query
        );

      /* =====================================================
       * BUILD WHATSAPP MESSAGE
       * ===================================================== */

      const msg =
        generateWAMessageFromContent(
          message.chatId,

          {
            viewOnceMessage: {
              message: {
                messageContextInfo: {
                  deviceListMetadata: {},

                  deviceListMetadataVersion:
                    2
                },

                interactiveMessage:
                  interactive
              }
            }
          },

          {
            userJid:
              sock.user?.id,

            quoted:
              message.raw
          }
        );

      /* =====================================================
       * ADDITIONAL NODES
       * ===================================================== */

      const additionalNodes = [
        {
          tag:
            'biz',

          attrs: {
            actual_actors:
              '2',

            host_storage:
              '2',

            privacy_mode_ts:
              String(
                Math.floor(
                  Date.now() / 1000
                )
              )
          },

          content: [
            {
              tag:
                'interactive',

              attrs: {
                type:
                  'native_flow',

                v:
                  '1'
              },

              content: [
                {
                  tag:
                    'native_flow',

                  attrs: {
                    v:
                      '9',

                    name:
                      'mixed'
                  }
                }
              ]
            }
          ]
        }
      ];

      if (
        !String(
          message.chatId
        ).endsWith('@g.us')
      ) {
        additionalNodes.unshift({
          tag:
            'bot',

          attrs: {
            biz_bot:
              '1'
          }
        });
      }

      /* =====================================================
       * SEND
       * ===================================================== */

      await sock.relayMessage(
        message.chatId,
        msg.message,
        {
          messageId:
            msg.key.id,

          additionalNodes
        }
      );

      try {
        await message.react?.(
          '✅'
        );
      } catch {}

      return true;
    } catch (error) {
      console.error(
        '[بحث_يوتيوب]',
        error?.message || error
      );

      try {
        if (
          loading?.key &&
          typeof sock.sendMessage ===
            'function'
        ) {
          await sock.sendMessage(
            message.chatId,
            {
              delete:
                loading.key
            }
          );
        }
      } catch {}

      try {
        await message.react?.(
          '❌'
        );
      } catch {}

      return message.reply(
        [
          '❌ فشل البحث في YouTube.',
          '',
          `السبب: ${
            error?.message ||
            'خطأ غير معروف'
          }`
        ].join('\n')
      );
    }
  }
};