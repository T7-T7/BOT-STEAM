import crypto from 'crypto';
import {
  prepareWAMessageMedia,
  generateWAMessageFromContent,
  proto,
  downloadContentFromMessage as baileysDownloadContentFromMessage
} from '@whiskeysockets/baileys';
import { groupContext, isGroupMessage } from '../services/group.js';

const COLORS = [
  0xFFF44336,
  0xFFE91E63,
  0xFF9C27B0,
  0xFF673AB7,
  0xFF3F51B5,
  0xFF2196F3,
  0xFF03A9F4,
  0xFF00BCD4,
  0xFF009688,
  0xFF4CAF50,
  0xFF8BC34A,
  0xFFCDDC39,
  0xFFFFEB3B,
  0xFFFFC107,
  0xFFFF9800,
  0xFFFF5722
];

const COLOR_NAMES = [
  'أحمر',
  'وردي',
  'بنفسجي',
  'نيلي',
  'أزرق',
  'أزرق سماوي',
  'أزرق فاتح',
  'سماوي',
  'تركواز',
  'أخضر',
  'أخضر فاتح',
  'ليموني',
  'أصفر',
  'عسلي',
  'برتقالي',
  'برتقالي غامق'
];

function getQuotedMessage(message) {
  return message?.quoted?.message || null;
}

function getQuotedMedia(message) {
  const quoted = getQuotedMessage(message);

  if (!quoted) {
    return {
      message: null,
      type: null,
      mime: ''
    };
  }

  if (quoted.imageMessage) {
    return {
      message: quoted.imageMessage,
      type: 'image',
      mime: quoted.imageMessage.mimetype || ''
    };
  }

  if (quoted.videoMessage) {
    return {
      message: quoted.videoMessage,
      type: 'video',
      mime: quoted.videoMessage.mimetype || ''
    };
  }

  if (quoted.audioMessage) {
    return {
      message: quoted.audioMessage,
      type: 'audio',
      mime: quoted.audioMessage.mimetype || ''
    };
  }

  if (quoted.documentMessage) {
    return {
      message: quoted.documentMessage,
      type: 'document',
      mime: quoted.documentMessage.mimetype || ''
    };
  }

  return {
    message: null,
    type: null,
    mime: ''
  };
}

function isVoice(mediaMessage) {
  return (
    mediaMessage?.ptt === true ||
    String(mediaMessage?.mimetype || '')
      .toLowerCase()
      .includes('audio/ogg')
  );
}

async function downloadQuotedMedia(mediaMessage, type) {
  if (!mediaMessage) {
    throw new Error('لم يتم العثور على الوسائط المقتبس منها.');
  }

  const stream = await baileysDownloadContentFromMessage(
    mediaMessage,
    type
  );

  const chunks = [];

  for await (const chunk of stream) {
    chunks.push(
      Buffer.isBuffer(chunk)
        ? chunk
        : Buffer.from(chunk)
    );
  }

  if (!chunks.length) {
    throw new Error('تم العثور على الوسائط لكن تعذر تحميل بياناتها.');
  }

  return Buffer.concat(chunks);
}

function parsePostArgs(args) {
  let audienceType = 1;
  let listEmoji = '🛸';
  let listName = '𝐋𝐎𝐘𝐃';

  let remainingText = Array.isArray(args)
    ? args.join(' ').trim()
    : '';

  if (!remainingText) {
    return {
      audienceType,
      listEmoji,
      listName,
      colorIndex: -1,
      postText: ''
    };
  }

  let parts = remainingText.split(/\s+/);
  const firstWord = String(parts[0] || '').toLowerCase();

  if (firstWord === 'عام') {
    audienceType = 0;
    listEmoji = '';
    listName = '';

    remainingText = parts.slice(1).join(' ');
  } else if (
    firstWord === 'خاص' ||
    firstWord === 'اقارب' ||
    firstWord === 'اصدقاء'
  ) {
    audienceType = 2;
    listEmoji = '⭐';
    listName = 'الأقارب';

    remainingText = parts.slice(1).join(' ');
  } else if (
    firstWord === 'قائمة' &&
    parts.length >= 3
  ) {
    audienceType = 1;
    listEmoji = parts[1];
    listName = parts[2];

    remainingText = parts.slice(3).join(' ');
  }

  let colorIndex = -1;

  if (remainingText) {
    const colorParts = remainingText.split(/\s+/);
    const potentialColor = Number.parseInt(
      colorParts[0],
      10
    );

    if (
      Number.isInteger(potentialColor) &&
      potentialColor >= 0 &&
      potentialColor <= 15
    ) {
      colorIndex = potentialColor;
      remainingText = colorParts.slice(1).join(' ');
    }
  }

  return {
    audienceType,
    listEmoji,
    listName,
    colorIndex,
    postText: remainingText.trim()
  };
}

function buildHelp() {
  const lines = [
    '🎨 *بـوسـت مُخصص*',
    '',
    '👥 *أنواع الجمهور:*',
    '• `.بوست عام` — للجميع',
    '• `.بوست خاص` — للأقارب ⭐',
    '• `.بوست قائمة 💎 جواهر` — قائمة مخصصة',
    '',
    '🎨 *الألوان (0-15):*'
  ];

  for (let i = 0; i < COLOR_NAMES.length; i++) {
    lines.push(
      `• *${i}* — ${COLOR_NAMES[i]}`
    );
  }

  lines.push(
    '',
    '✏️ *أمثلة:*',
    '• `.بوست عام 5 مرحبا`',
    '• `.بوست خاص 12 مرحبا`',
    '• `.بوست قائمة 💎 جواهر 12 مرحبا`',
    '• `.بوست 3 نص البوست`',
    '• رد على صورة/فيديو/صوت ثم اكتب `.بوست`'
  );

  return lines.join('\n');
}

function getWatermark() {
  if (
    typeof globalThis !== 'undefined' &&
    typeof globalThis.watermark === 'string'
  ) {
    return globalThis.watermark;
  }

  return '';
}

function makeMessageId() {
  return crypto.randomBytes(10).toString('hex').toUpperCase();
}

async function sendMediaPost({
  sock,
  message,
  media,
  mediaType,
  postText,
  audienceType,
  listEmoji,
  listName
}) {
  const downloaded =
    await downloadQuotedMedia(
      media,
      mediaType
    );

  const voice =
    mediaType === 'audio' &&
    isVoice(media);

  let mediaOptions;

  if (voice) {
    mediaOptions = {
      audio: downloaded,
      mimetype: 'audio/ogg; codecs=opus',
      ptt: false
    };
  } else {
    mediaOptions = {
      [mediaType]: downloaded
    };
  }

  const prepared =
    await prepareWAMessageMedia(
      mediaOptions,
      {
        upload: sock.waUploadToServer
      }
    );

  const messageKey =
    mediaType === 'image'
      ? 'imageMessage'
      : mediaType === 'video'
        ? 'videoMessage'
        : 'audioMessage';

  const contentMessage = {
    [messageKey]: {
      ...prepared[messageKey],

      caption:
        postText || '',

      contextInfo: {
        isGroupStatus: true,

        pairedMediaType:
          'NOT_PAIRED_MEDIA',

        statusSourceType: 4,

        statusAttributions: [
          { type: 10 }
        ],

        featureEligibilities: {
          canBeReshared: true,
          canReceiveMultiReact: true
        },

        statusAudienceMetadata: {
          audienceType,

          ...(listEmoji
            ? { listEmoji }
            : {}),

          ...(listName
            ? { listName }
            : {})
        }
      }
    }
  };

  const webMessage =
    proto.Message.fromObject(
      contentMessage
    );

  const waMessage =
    generateWAMessageFromContent(
      message.chatId,
      webMessage,
      {
        userJid: sock.user?.id,
        quoted: message.raw
      }
    );

  await sock.relayMessage(
    message.chatId,
    waMessage.message,
    {
      messageId: waMessage.key.id,

      additionalNodes: [
        {
          tag: 'meta',
          attrs: {
            is_group_status: 'true'
          }
        }
      ]
    }
  );

  return {
    key: {
      remoteJid: message.chatId,
      id: waMessage.key.id,
      fromMe: true
    },
    type: mediaType
  };
}

async function sendTextPost({
  sock,
  message,
  postText,
  audienceType,
  listEmoji,
  listName,
  color
}) {
  const watermark =
    getWatermark();

  const finalText =
    watermark
      ? `${watermark}\n\n${postText}`
      : postText;

  const messageId = makeMessageId();

  await sock.relayMessage(
    message.chatId,
    {
      extendedTextMessage: {
        text: finalText,

        thumbnailUrl:
          'https://file.garden/ap7Y3MCskKqaij8B/file_1788807234895.jpeg',

        textArgb:
          4294967040,

        backgroundArgb:
          color,

        font: 5,

        previewType: 0,

        inviteLinkGroupTypeV2: 0,

        contextInfo: {
          statusAttributions: [
            { type: 10 }
          ],

          featureEligibilities: {
            canBeReshared: true,
            canReceiveMultiReact: true
          },

          statusSourceType:
            'TEXT',

          isGroupStatus:
            true,

          statusAudienceMetadata: {
            audienceType,

            ...(listEmoji
              ? { listEmoji }
              : {}),

            ...(listName
              ? { listName }
              : {})
          }
        }
      },

      messageContextInfo: {
        messageSecret:
          Buffer.from(
            Array.from(
              { length: 32 },
              () =>
                Math.floor(
                  Math.random() * 256
                )
            )
          )
      }
    },

    {
      messageId,
      additionalNodes: [
        {
          tag: 'meta',
          attrs: {
            is_group_status: 'true'
          }
        }
      ]
    }
  );

  return {
    key: {
      remoteJid: message.chatId,
      id: messageId,
      fromMe: true
    },
    type: 'text'
  };
}

const postCommand = {
  name: 'بوست',
  category: 'وسائط',
  requiredRole: 'user',

  async execute(ctx) {
    const {
      message,
      sock,
      args
    } = ctx;

    if (!message?.isGroup) {
      return message.reply(
        '⚠️ `.بوست` مخصص لستوري المجموعة. استخدمه داخل المجموعة.'
      );
    }

    const {
      audienceType,
      listEmoji,
      listName,
      colorIndex,
      postText
    } = parsePostArgs(args);

    const media =
      getQuotedMedia(message);

    if (!postText && !media.message) {
      return message.reply(
        buildHelp()
      );
    }

    const finalColor =
      colorIndex >= 0
        ? COLORS[colorIndex]
        : COLORS[
            Math.floor(
              Math.random() *
              COLORS.length
            )
          ];

    try {
      if (
        media.message &&
        (
          media.type === 'image' ||
          media.type === 'video' ||
          media.type === 'audio'
        )
      ) {
        const posted = await sendMediaPost({
          sock,
          message,
          media: media.message,
          mediaType: media.type,
          postText,
          audienceType,
          listEmoji,
          listName
        });
      } else if (media.message) {
        return message.reply(
          '⚠️ نوع الوسائط المرفقة غير مدعوم. استخدم صورة أو فيديو أو صوت.'
        );
      } else {
        const posted = await sendTextPost({
          sock,
          message,
          postText,
          audienceType,
          listEmoji,
          listName,
          color: finalColor
        });
      }

      await message.react?.('🚥');

      return true;
    } catch (error) {
      console.error(
        '❌ بوست:',
        error
      );

      await message.react?.('❌');

      return message.reply(
        `❌ تعذر نشر البوست.\nالسبب: ${
          error?.message || error
        }`
      );
    }
  }
};

export default postCommand;