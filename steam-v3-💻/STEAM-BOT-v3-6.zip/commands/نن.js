export default {
name: 'نن',
aliases: ['نن', 'nn'],
category: 'إدارة',
requiredRole: 'user',

async execute(ctx) {
const { message, sock } = ctx;

if (!message?.isGroup || !message?.chatId || !sock) {
  return false;
}

await message.react?.('⏱️');

try {
  const metadata = await sock.groupMetadata(message.chatId);

  const participants = Array.isArray(metadata?.participants)
    ? metadata.participants
    : [];

  if (!participants.length) {
    await message.reply('❌ تعذر الحصول على أعضاء المجموعة.');
    return true;
  }

  const normalize = participant => {
    if (!participant) return null;

    if (typeof participant === 'string') {
      return participant.trim();
    }

    return String(
      participant.id ||
      participant.jid ||
      participant.lid ||
      participant.phoneNumber ||
      ''
    ).trim() || null;
  };

  const getAlt = participant => {
    if (!participant || typeof participant === 'string') {
      return null;
    }

    return String(
      participant.phoneNumber ||
      participant.alt ||
      participant.jid ||
      ''
    ).trim() || null;
  };

  const uniqueParticipants = [];

  const seen = new Set();

  for (const participant of participants) {
    const jid = normalize(participant);

    if (!jid) continue;

    const key =
      jid ||
      getAlt(participant);

    if (!key || seen.has(key)) continue;

    seen.add(key);

    uniqueParticipants.push({
      raw: participant,
      jid
    });
  }

  const isAdmin = participant => {
    return (
      participant?.admin === 'admin' ||
      participant?.admin === 'superadmin' ||
      participant?.isAdmin === true ||
      participant?.isSuperAdmin === true
    );
  };

  const admins = uniqueParticipants.filter(item =>
    isAdmin(item.raw)
  );

  const adminJids = new Set(
    admins.map(item => item.jid)
  );

  /*
   * المالك هنا هو مالك المجموعة.
   * إذا لم يكن موجودًا ضمن participants نستخدم
   * metadata.owner كـ fallback.
   */
  const groupOwner =
    metadata?.owner ||
    metadata?.ownerPn ||
    metadata?.subjectOwner ||
    null;

  let ownerJid = String(groupOwner || '').trim();

  /*
   * إذا كان مالك المجموعة موجودًا في المشاركين
   * نستخدم الـ JID الموجود فعليًا في participants.
   */
  if (ownerJid) {
    const ownerParticipant =
      uniqueParticipants.find(item => {
        const alt = getAlt(item.raw);

        return (
          item.jid === ownerJid ||
          alt === ownerJid
        );
      });

    if (ownerParticipant) {
      ownerJid = ownerParticipant.jid;
    }
  }

  /*
   * المشرفون: لا نكرر المالك داخل قائمة المشرفين.
   */
  const moderators = admins.filter(item =>
    item.jid !== ownerJid
  );

  /*
   * الأعضاء: كل من ليس المالك أو مشرفًا.
   */
  const members = uniqueParticipants.filter(item => {
    if (item.jid === ownerJid) return false;
    if (adminJids.has(item.jid)) return false;

    return true;
  });

  /*
   * إذا لم توفر metadata.owner،
   * نبحث عن superadmin داخل المشاركين.
   */
  if (!ownerJid) {
    const detectedOwner =
      uniqueParticipants.find(
        item =>
          item.raw?.isSuperAdmin === true ||
          item.raw?.admin === 'superadmin'
      );

    if (detectedOwner) {
      ownerJid = detectedOwner.jid;
    }
  }

  /*
   * إذا أصبح المالك معروفًا بعد ذلك،
   * نتأكد أنه لا يظهر مرة أخرى كمشرف.
   */
  const finalModerators =
    moderators.filter(item =>
      item.jid !== ownerJid
    );

  const finalMembers =
    members.filter(item =>
      item.jid !== ownerJid &&
      !finalModerators.some(
        admin => admin.jid === item.jid
      )
    );

  const mention = jid =>
    `@${String(jid).split('@')[0]}`;

  const mentions = [];

  const addMention = jid => {
    if (!jid) return;

    if (!mentions.includes(jid)) {
      mentions.push(jid);
    }
  };

  const lines = [
    '⚜️ *S T E A M B O T ♖*',
    ''
  ];

  /*
   * OWNER
   */
  lines.push('┊⌔👑︙ المالك :');

  if (ownerJid) {
    addMention(ownerJid);
    lines.push(`┊⌔👑︙ ${mention(ownerJid)}`);
  } else {
    lines.push('┊⌔👑︙ غير معروف');
  }

  lines.push('');

  /*
   * ADMINS
   */
  lines.push('┊⌔⚙️︙ المشرفين :');

  if (finalModerators.length) {
    finalModerators.forEach((item, index) => {
      addMention(item.jid);

      lines.push(
        `┊⌔💎︙ ${index + 1} - ${mention(item.jid)}`
      );
    });
  } else {
    lines.push('┊⌔💎︙ لا يوجد مشرفون');
  }

  lines.push('');

  /*
   * MEMBERS
   */
  lines.push('┊⌔👤︙ الأعضاأ :');

  if (finalMembers.length) {
    finalMembers.forEach((item, index) => {
      addMention(item.jid);

      lines.push(
        `┊⌔🐦︙ ${index + 1} - ${mention(item.jid)}`
      );
    });
  } else {
    lines.push('┊⌔🐦︙ لا يوجد أعضاء');
  }

  const text = lines.join('\n');

  /*
   * Footer حقيقي.
   */
  try {
    await sock.sendMessage(
      message.chatId,
      {
        text,
        mentions,

        footer:
          '𓂃 ࣪˖ ִֶָ⚜️ 𝑺𝑻𝑬𝑨𝑴 𝑩𝑶𝑻 ♖ ִֶָ ˖ ࣪'
      }
    );
  } catch {
    /*
     * Fallback عادي في حال كان إصدار Baileys
     * لا يعرض footer مع نوع الرسالة المستخدمة.
     */
    await sock.sendMessage(
      message.chatId,
      {
        text,
        mentions
      }
    );
  }

  await message.react?.('✅');

  return true;

} catch (error) {
  console.error('[نن]', error);

  await message.react?.('❌');

  await message.reply(
    '❌ تعذر إنشاء قائمة المنشن الآن.'
  );

  return true;
}

}
};