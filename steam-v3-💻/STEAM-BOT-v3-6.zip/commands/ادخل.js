import {
  groupContext,
  assertSenderCanManageGroup,
  isGroupMessage
} from '../services/group.js';

/*
 * استخراج كود دعوة WhatsApp من الرابط.
 *
 * يدعم:
 * https://chat.whatsapp.com/XXXXXXXX
 * https://chat.whatsapp.com/XXXXXXXX?...
 * وكذلك الكود نفسه.
 */
function extractInviteCode(value) {
  const input = String(value || '').trim();

  if (!input) {
    return null;
  }

  /*
   * رابط دعوة WhatsApp.
   */
  const match = input.match(
    /chat\.whatsapp\.com\/([A-Za-z0-9_-]+)/i
  );

  if (match?.[1]) {
    return match[1];
  }

  /*
   * في حالة إرسال الكود مباشرة.
   */
  if (
    /^[A-Za-z0-9_-]{8,64}$/.test(input)
  ) {
    return input;
  }

  return null;
}

async function joinGroup(ctx, input) {
  const {
    message,
    sock
  } = ctx;

  /*
   * الأمر مخصص للمشرفين داخل المجموعات،
   * مثل بقية أوامر إدارة المجموعة.
   */
  if (!isGroupMessage(message)) {
    throw new Error(
      '⚠️ هذا الأمر يعمل داخل المجموعات فقط.'
    );
  }

  const {
    metadata
  } = await groupContext(
    ctx,
    {
      fresh: true
    }
  );

  assertSenderCanManageGroup(
    ctx,
    metadata
  );

  const code =
    extractInviteCode(input);

  if (!code) {
    return message.reply(
      '⚠️ أرسل رابط قروب WhatsApp صحيح.\n\n' +
      'مثال:\n' +
      '`.ادخل https://chat.whatsapp.com/XXXXXXXX`'
    );
  }

  await message.react?.('⏳');

  try {
    /*
     * WhatsApp نفسه يحدد النتيجة:
     *
     * - إذا كانت الموافقة غير مفعلة:
     *   يدخل البوت مباشرة.
     *
     * - إذا كانت الموافقة مفعلة:
     *   يتحول الطلب إلى طلب انضمام ينتظر
     *   موافقة مشرفي المجموعة.
     *
     * groupAcceptInvite هو API الرسمي في Baileys
     * للدخول باستخدام invite code.
     */
    const groupId =
      await sock.groupAcceptInvite(
        code
      );

    await message.react?.('✅');

    if (groupId) {
      return message.reply(
        '✅ *تم الدخول إلى القروب بنجاح.*\n\n' +
        `🆔 ${groupId}`
      );
    }

    /*
     * بعض حالات السيرفر قد لا تعيد JID
     * رغم قبول طلب الدعوة.
     */
    return message.reply(
      '📨 *تم إرسال طلب الانضمام.*\n\n' +
      '⏳ إذا كانت موافقة الانضمام مفعلة، ' +
      'سيحتاج الطلب إلى موافقة مشرفي القروب.'
    );

  } catch (error) {
    console.error(
      '[ادخل]',
      error
    );

    await message.react?.('❌');

    const reason =
      error?.output?.payload?.message ||
      error?.message ||
      String(error);

    return message.reply(
      '❌ *تعذر الدخول إلى القروب.*\n\n' +
      `السبب: ${reason}`
    );
  }
}

export default {
  name: 'ادخل',

  aliases: [
    'دخول',
    'join'
  ],

  category: 'إدارة',

  requiredRole: 'user',

  async execute(ctx) {
    try {
      return await joinGroup(
        ctx,
        (ctx.args || []).join(' ').trim()
      );
    } catch (error) {
      console.error(
        '[ادخل]',
        error
      );

      return ctx.message.reply(
        `❌ تعذر تنفيذ أمر الدخول.\n` +
        `السبب: ${
          error?.message || error
        }`
      );
    }
  }
};