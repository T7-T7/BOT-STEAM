'use strict';

import fs from 'fs';
import path from 'path';

import {
  proto,
  generateWAMessageFromContent,
  generateMessageID
} from '@whiskeysockets/baileys';

/* =========================================================
 * CONFIG
 * ========================================================= */

const PROTO_FILE = path.resolve(
  process.cwd(),
  'proto.json'
);

const MAX_PROTO_AGE =
  24 * 60 * 60 * 1000;

const MAX_CODE_LENGTH = 20000;

/* =========================================================
 * PROTO STORE
 * ========================================================= */

function loadProtoStore() {
  try {
    if (!fs.existsSync(PROTO_FILE)) {
      return {};
    }

    const data = fs.readFileSync(
      PROTO_FILE,
      'utf8'
    );

    if (!data.trim()) {
      return {};
    }

    const parsed = JSON.parse(data);

    return parsed &&
      typeof parsed === 'object'
      ? parsed
      : {};

  } catch (error) {
    console.error(
      '[EXTRACT] Failed to load proto store:',
      error
    );

    return {};
  }
}

function saveProtoStore(store) {
  try {
    fs.writeFileSync(
      PROTO_FILE,
      JSON.stringify(
        store,
        null,
        2
      ),
      'utf8'
    );
  } catch (error) {
    console.error(
      '[EXTRACT] Failed to save proto store:',
      error
    );
  }
}

function cleanProtoStore(store) {
  const now = Date.now();

  let changed = false;

  for (const key of Object.keys(store)) {
    const entry = store[key];

    if (
      !entry?.ts ||
      now - Number(entry.ts) >= MAX_PROTO_AGE
    ) {
      delete store[key];
      changed = true;
    }
  }

  return changed;
}

/* =========================================================
 * MESSAGE IDENTIFIERS
 * ========================================================= */

function getMessageId(message) {
  return (
    message?.key?.id ||
    message?.id ||
    null
  );
}

function getRemoteJid(message) {
  return (
    message?.key?.remoteJid ||
    message?.chatId ||
    message?.remoteJid ||
    null
  );
}

function buildStoreKey(jid, id) {
  if (!jid || !id) {
    return null;
  }

  return `${String(jid)}_${String(id)}`;
}

/* =========================================================
 * PROTO CONVERSION
 * ========================================================= */

function messageToProto(message) {
  if (!message) {
    return null;
  }

  try {
    return proto.Message.fromObject(
      message
    );
  } catch (error) {
    console.error(
      '[EXTRACT] proto conversion failed:',
      error?.message || error
    );

    return null;
  }
}

function messageToObject(message) {
  if (!message) {
    return null;
  }

  try {
    return proto.Message.toObject(
      message,
      {
        enums: Number,
        longs: String,
        bytes: String,
        defaults: false,
        arrays: true,
        objects: true
      }
    );
  } catch (error) {
    console.error(
      '[EXTRACT] proto object conversion failed:',
      error?.message || error
    );

    return null;
  }
}

/* =========================================================
 * STORE MESSAGE
 * ========================================================= */

function storeMessage(message) {
  if (
    !message ||
    !message.message
  ) {
    return;
  }

  const id =
    getMessageId(message);

  const jid =
    getRemoteJid(message);

  if (!id || !jid) {
    return;
  }

  const object =
    messageToObject(
      message.message
    );

  if (!object) {
    return;
  }

  const store =
    loadProtoStore();

  cleanProtoStore(
    store
  );

  const key =
    buildStoreKey(
      jid,
      id
    );

  if (!key) {
    return;
  }

  store[key] = {
    message: object,

    ts: Date.now(),

    key: {
      id: String(id),

      remoteJid:
        String(jid),

      fromMe:
        Boolean(
          message?.key?.fromMe
        ),

      participant:
        message?.key?.participant ||
        null
    }
  };

  saveProtoStore(
    store
  );
}

/* =========================================================
 * ADDITIONAL NODES STORE
 * ========================================================= */

function ensureAdditionalNodeStore(sock) {
  if (!sock) {
    return null;
  }

  if (
    !sock.__steamAdditionalNodes
  ) {
    sock.__steamAdditionalNodes =
      Object.create(null);
  }

  return sock.__steamAdditionalNodes;
}

/*
 * استخراج العقد المهمة من CB node.
 *
 * لا نحاول تعديل العقد.
 * نحفظها كما وصلت قدر الإمكان.
 */

function extractNodeContent(node) {
  if (
    !node ||
    typeof node !== 'object'
  ) {
    return [];
  }

  const content =
    node.content;

  if (!Array.isArray(content)) {
    return [];
  }

  return content.filter(
    item =>
      item &&
      typeof item === 'object' &&
      item.tag
  );
}

function bindAdditionalNodes(sock) {
  if (!sock) {
    return;
  }

  if (
    sock.__steamAdditionalNodesBound
  ) {
    return;
  }

  sock.__steamAdditionalNodesBound =
    true;

  const store =
    ensureAdditionalNodeStore(
      sock
    );

  /*
   * بعض إصدارات Baileys توفر ws.on.
   */

  try {
    if (
      sock.ws &&
      typeof sock.ws.on === 'function'
    ) {
      sock.ws.on(
        'CB:message',
        node => {
          try {
            const id =
              node?.attrs?.id;

            if (!id) {
              return;
            }

            const extracted =
              extractNodeContent(
                node
              );

            if (
              extracted.length
            ) {
              store[id] =
                extracted;
            }
          } catch (error) {
            console.error(
              '[EXTRACT] additional node error:',
              error?.message || error
            );
          }
        }
      );
    }
  } catch (error) {
    console.error(
      '[EXTRACT] failed to bind additional nodes:',
      error?.message || error
    );
  }
}

function getAdditionalNodes(
  sock,
  messageId
) {
  if (
    !sock ||
    !messageId
  ) {
    return [];
  }

  const store =
    ensureAdditionalNodeStore(
      sock
    );

  const nodes =
    store?.[messageId];

  return Array.isArray(nodes)
    ? nodes
    : [];
}

/* =========================================================
 * BIND MESSAGE STORE
 * ========================================================= */

function bindProtoStore(sock) {
  if (!sock) {
    return;
  }

  if (
    sock.__steamProtoStoreBound
  ) {
    bindAdditionalNodes(
      sock
    );

    return;
  }

  sock.__steamProtoStoreBound =
    true;

  bindAdditionalNodes(
    sock
  );

  if (
    sock.ev &&
    typeof sock.ev.on === 'function'
  ) {
    sock.ev.on(
      'messages.upsert',
      event => {
        try {
          const messages =
            event?.messages;

          if (
            !Array.isArray(messages)
          ) {
            return;
          }

          for (
            const message
            of messages
          ) {
            storeMessage(
              message
            );
          }
        } catch (error) {
          console.error(
            '[EXTRACT] messages.upsert error:',
            error?.message || error
          );
        }
      }
    );
  }
}

/* =========================================================
 * QUOTED MESSAGE
 * ========================================================= */

function getQuotedMessage(message) {
  const raw =
    message?.raw;

  if (
    !raw?.message ||
    typeof raw.message !== 'object'
  ) {
    return null;
  }

  for (
    const value
    of Object.values(
      raw.message
    )
  ) {
    if (
      !value ||
      typeof value !== 'object'
    ) {
      continue;
    }

    const context =
      value.contextInfo;

    if (
      context?.quotedMessage
    ) {
      return {
        message:
          context.quotedMessage,

        context
      };
    }
  }

  return null;
}

/* =========================================================
 * QUOTED KEY
 * ========================================================= */

function getQuotedKey(
  message,
  quoted
) {
  const context =
    quoted?.context || {};

  const id =
    context.stanzaId ||
    context.quotedMessageId ||
    context.messageId ||
    null;

  /*
   * participant هو صاحب الرسالة
   * المقتبسة في الجروبات غالبًا.
   */

  const participant =
    context.participant ||
    context.remoteJid ||
    message?.chatId ||
    null;

  return {
    id:
      id
        ? String(id)
        : null,

    jid:
      participant
        ? String(participant)
        : null
  };
}

/* =========================================================
 * FIND STORED MESSAGE
 * ========================================================= */

function findStoredMessage(
  jid,
  id
) {
  if (!jid || !id) {
    return null;
  }

  const store =
    loadProtoStore();

  const changed =
    cleanProtoStore(
      store
    );

  if (changed) {
    saveProtoStore(
      store
    );
  }

  const key =
    buildStoreKey(
      jid,
      id
    );

  if (!key) {
    return null;
  }

  const entry =
    store[key];

  if (
    !entry?.message
  ) {
    return null;
  }

  return messageToProto(
    entry.message
  );
}

/* =========================================================
 * BAILEYS MESSAGE STORE
 * ========================================================= */

async function getFromBaileysStore(
  sock,
  key
) {
  if (
    !sock ||
    !key
  ) {
    return null;
  }

  try {
    const getter =
      sock.ws?.config?.getMessage;

    if (
      typeof getter === 'function'
    ) {
      const result =
        await getter(
          key
        );

      if (
        result &&
        typeof result === 'object'
      ) {
        /*
         * getMessage قد يرجع Message
         * مباشرة أو object يحتوي message.
         */

        if (
          result.message &&
          typeof result.message === 'object'
        ) {
          return messageToProto(
            result.message
          );
        }

        return messageToProto(
          result
        );
      }
    }
  } catch (error) {
    console.error(
      '[EXTRACT] getMessage failed:',
      error?.message || error
    );
  }

  return null;
}

/* =========================================================
 * JS STRING
 * ========================================================= */

function jsString(value) {
  return JSON.stringify(
    value
  );
}

/* =========================================================
 * FORMAT PROTO OBJECT
 * ========================================================= */

function formatCodeValue(
  value,
  indent = 0
) {
  const pad =
    ' '.repeat(
      indent
    );

  const nextPad =
    ' '.repeat(
      indent + 2
    );

  if (
    typeof value === 'string'
  ) {
    return jsString(
      value
    );
  }

  if (
    value === null
  ) {
    return 'null';
  }

  if (
    typeof value === 'number' ||
    typeof value === 'boolean'
  ) {
    return String(
      value
    );
  }

  if (
    typeof value === 'bigint'
  ) {
    return `${value}n`;
  }

  if (
    Array.isArray(value)
  ) {
    if (
      !value.length
    ) {
      return '[]';
    }

    return [
      '[',

      value
        .map(
          item =>
            `${nextPad}${formatCodeValue(
              item,
              indent + 2
            )}`
        )
        .join(',\n'),

      `${pad}]`
    ].join('\n');
  }

  if (
    typeof value === 'object'
  ) {
    const entries =
      Object.entries(
        value
      );

    if (
      !entries.length
    ) {
      return '{}';
    }

    return [
      '{',

      entries
        .map(
          ([key, val]) => {
            const safeKey =
              /^[A-Za-z_$][A-Za-z0-9_$]*$/.test(
                key
              )
                ? key
                : jsString(
                    key
                  );

            return (
              `${nextPad}${safeKey}: ` +
              formatCodeValue(
                val,
                indent + 2
              )
            );
          }
        )
        .join(',\n'),

      `${pad}}`
    ].join('\n');
  }

  return jsString(
    String(value)
  );
}

/* =========================================================
 * CODE TOKENIZER
 *
 * بدون highlight.js.
 *
 * مهم:
 * هذا Regex مكتوب بطريقة آمنة ولا يحتوي
 * على الـ Regex المكسور الموجود في النسخة السابقة.
 * ========================================================= */

const CODE_TOKEN_REGEX =
  /("(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|`(?:\\.|[^`\\])*`|\/\/[^\r\n]*|\/\*[\s\S]*?\*\/|\b\d+(?:\.\d+)?\b|\b(?:const|let|var|function|return|if|else|for|while|async|await|import|from|export|default|class|new|try|catch|throw|true|false|null|undefined|switch|case|break|continue|typeof|instanceof|extends|static|this|super|yield|delete|in|of|do)\b|[A-Za-z_$][A-Za-z0-9_$]*)/g;

function mapTokenType(token) {
  if (
    /^["'`]/.test(
      token
    )
  ) {
    return 3;
  }

  if (
    /^\/\//.test(
      token
    ) ||
    /^\/\*/.test(
      token
    )
  ) {
    return 5;
  }

  if (
    /^\d/.test(
      token
    )
  ) {
    return 2;
  }

  if (
    /^(const|let|var|function|return|if|else|for|while|async|await|import|from|export|default|class|new|try|catch|throw|true|false|null|undefined|switch|case|break|continue|typeof|instanceof|extends|static|this|super|yield|delete|in|of|do)$/.test(
      token
    )
  ) {
    return 1;
  }

  return 0;
}

function tokenizeCode(code) {
  const result = [];

  let lastIndex = 0;

  CODE_TOKEN_REGEX.lastIndex = 0;

  let match;

  while (
    (
      match =
        CODE_TOKEN_REGEX.exec(
          code
        )
    ) !== null
  ) {
    if (
      match.index >
      lastIndex
    ) {
      result.push({
        highlightType: 0,

        codeContent:
          code.slice(
            lastIndex,
            match.index
          )
      });
    }

    result.push({
      highlightType:
        mapTokenType(
          match[0]
        ),

      codeContent:
        match[0]
    });

    lastIndex =
      CODE_TOKEN_REGEX.lastIndex;
  }

  if (
    lastIndex <
    code.length
  ) {
    result.push({
      highlightType: 0,

      codeContent:
        code.slice(
          lastIndex
        )
    });
  }

  return result;
}

/* =========================================================
 * NORMALIZE ADDITIONAL NODES FOR CODE
 * ========================================================= */

function formatAdditionalNodes(
  nodes
) {
  if (
    !Array.isArray(nodes) ||
    !nodes.length
  ) {
    return '';
  }

  try {
    return JSON.stringify(
      nodes,
      null,
      2
    ).replace(
      /^(\s*)"([A-Za-z_$][A-Za-z0-9_$]*)":/gm,
      '$1$2:'
    );
  } catch {
    return '';
  }
}

/* =========================================================
 * GENERATE REPLAY CODE
 * ========================================================= */

function generateReplayCode({
  messageObject,
  additionalNodes
}) {
  const messageCode =
    formatCodeValue(
      messageObject
    );

  const nodesCode =
    formatAdditionalNodes(
      additionalNodes
    );

  const lines = [
    'try {',

    '  await sock.relayMessage(',

    '    message.chatId,',

    `    ${messageCode},`,

    '    {'
  ];

  if (
    nodesCode
  ) {
    lines.push(
      `      additionalNodes: ${nodesCode}`
    );
  }

  lines.push(
    '    }',

    '  );',

    '',

    '  await sock.sendMessage(',

    '    message.chatId,',

    '    {',

    '      react: {',

    '        text: "✅",',

    '        key: message.raw.key',

    '      }',

    '    }',

    '  );',

    '} catch (error) {',

    '  console.error(error);',

    '}'
  );

  return lines.join(
    '\n'
  );
}

/* =========================================================
 * SEND LARGE CODE
 * ========================================================= */

async function sendCodeFile(
  sock,
  chatId,
  code,
  quoted
) {
  await sock.sendMessage(
    chatId,
    {
      document:
        Buffer.from(
          code,
          'utf8'
        ),

      mimetype:
        'text/javascript',

      fileName:
        'extracted_code.js',

      caption:
        '⚠️ الكود المستخرج كبير جدًا، لذلك تم إرساله كملف.'
    },
    {
      quoted
    }
  );
}

/* =========================================================
 * BUILD RICH RESPONSE
 * ========================================================= */

function buildRichCodeMessage({
  codeBlocks,
  originalMessage
}) {
  return proto.Message.fromObject({
    botForwardedMessage: {
      message: {
        richResponseMessage: {
          messageType: 1,

          submessages: [
            {
              messageType: 2,

              messageText:
                'كود المستخرج:\n'
            },

            {
              messageType: 5,

              codeMetadata: {
                codeLanguage:
                  'javascript',

                codeBlocks
              }
            },

            {
              messageType: 2,

              messageText:
                '𓂃 ࣪˖ ִֶָ⚜️ 𝑺𝑻𝑬𝑨𝑴 𝑩𝑶𝑻 ♖ ִֶָ ˖ ࣪'
            }
          ],

          contextInfo: {
            forwardingScore:
              2,

            isForwarded:
              true,

            forwardedAiBotMessageInfo: {
              botJid:
                'g1n@bot'
            },

            forwardOrigin:
              4,

            quotedMessage:
              originalMessage?.message,

            participant:
              originalMessage?.key?.participant ||
              originalMessage?.key?.remoteJid ||
              null
          }
        }
      }
    }
  });
}

/* =========================================================
 * COMMAND
 * ========================================================= */

export default {
  name: '-->',

  aliases: [
    '-->',
    'استخراج'
  ],

  category: 'نظام',

  requiredRole:
    'developer',

  async execute(ctx) {
    const {
      message,
      sock
    } = ctx;

    if (
      !message?.chatId ||
      !sock
    ) {
      return false;
    }

    /*
     * تشغيل أنظمة التخزين.
     */

    bindProtoStore(
      sock
    );

    /* =====================================================
     * GET QUOTED MESSAGE
     * ===================================================== */

    const quoted =
      getQuotedMessage(
        message
      );

    if (!quoted) {
      await message.reply(
        '⚠️ *المرجو الرد على رسالة لاستخراج كودها.*'
      );

      return true;
    }

    /* =====================================================
     * GET QUOTED KEY
     * ===================================================== */

    const quotedKey =
      getQuotedKey(
        message,
        quoted
      );

    let targetMessage =
      null;

    /* =====================================================
     * 1. PROTO STORE
     * ===================================================== */

    if (
      quotedKey.id &&
      quotedKey.jid
    ) {
      targetMessage =
        findStoredMessage(
          quotedKey.jid,
          quotedKey.id
        );
    }

    /* =====================================================
     * 2. BAILEYS getMessage()
     * ===================================================== */

    if (
      !targetMessage &&
      quotedKey.id
    ) {
      targetMessage =
        await getFromBaileysStore(
          sock,
          {
            id:
              quotedKey.id,

            remoteJid:
              quotedKey.jid ||
              message.chatId
          }
        );
    }

    /* =====================================================
     * 3. QUOTED MESSAGE DIRECTLY
     * ===================================================== */

    if (!targetMessage) {
      targetMessage =
        messageToProto(
          quoted.message
        );
    }

    /* =====================================================
     * MESSAGE NOT FOUND
     * ===================================================== */

    if (!targetMessage) {
      await message.reply(
        [
          '❌ *لم أستطع العثور على الرسالة الأصلية.*',
          '',
          'حاول الرد على الرسالة مرة أخرى.'
        ].join('\n')
      );

      return true;
    }

    /* =====================================================
     * REACTION
     * ===================================================== */

    await message.react?.(
      '⏳'
    ).catch?.(
      () => {}
    );

    try {
      /* ===================================================
       * ADDITIONAL NODES
       * =================================================== */

      const additionalNodes =
        getAdditionalNodes(
          sock,
          quotedKey.id
        );

      /* ===================================================
       * RELAY ORIGINAL
       *
       * هذا يحافظ على بنية protobuf
       * بدل تحويلها إلى نص.
       * =================================================== */

      await sock.relayMessage(
        message.chatId,
        targetMessage,
        {
          additionalNodes
        }
      );

      /* ===================================================
       * CONVERT MESSAGE
       * =================================================== */

      const messageObject =
        messageToObject(
          targetMessage
        );

      if (!messageObject) {
        throw new Error(
          'تعذر تحويل الرسالة إلى protobuf object.'
        );
      }

      /* ===================================================
       * GENERATE CODE
       * =================================================== */

      const fullCodeText =
        generateReplayCode({
          messageObject,

          additionalNodes
        });

      /* ===================================================
       * LARGE CODE
       * =================================================== */

      if (
        fullCodeText.length >
        MAX_CODE_LENGTH
      ) {
        await sendCodeFile(
          sock,
          message.chatId,
          fullCodeText,
          message.raw
        );

        await message.react?.(
          '✅'
        ).catch?.(
          () => {}
        );

        return true;
      }

      /* ===================================================
       * TOKENIZE
       * =================================================== */

      const codeBlocks =
        tokenizeCode(
          fullCodeText
        );

      /* ===================================================
       * BUILD MESSAGE
       * =================================================== */

      const msgContent =
        buildRichCodeMessage({
          codeBlocks,

          originalMessage:
            message.raw
        });

      /* ===================================================
       * GENERATE WA MESSAGE
       * =================================================== */

      const generated =
        generateWAMessageFromContent(
          message.chatId,
          msgContent,
          {
            userJid:
              sock.user?.id,

            messageId:
              generateMessageID(),

            quoted:
              message.raw
          }
        );

      /* ===================================================
       * SEND
       * =================================================== */

      await sock.relayMessage(
        message.chatId,
        generated.message,
        {
          messageId:
            generated.key.id
        }
      );

      /* ===================================================
       * SUCCESS
       * =================================================== */

      await message.react?.(
        '✅'
      ).catch?.(
        () => {}
      );

      return true;

    } catch (error) {
      console.error(
        '[EXTRACT]',
        error
      );

      await message.react?.(
        '❌'
      ).catch?.(
        () => {}
      );

      await message.reply(
        [
          '❌ *تعذر استخراج الرسالة.*',
          '',
          `السبب: ${
            error?.message ||
            'خطأ غير معروف.'
          }`
        ].join('\n')
      );

      return true;
    }
  }
};