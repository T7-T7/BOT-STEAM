import { entries } from '../heart/registry.js';

import {
  sendInteractive,
  listButton
} from '../services/interactive.js';

import {
  resolve,
  roleOf
} from '../security/index.js';

/* =========================================================
 * CONSTANTS
 * ========================================================= */

const STEAM_FOOTER =
  '𓂃 ࣪˖ ִֶָ⚜️ 𝑺𝑻𝑬𝑨𝑴 𝑩𝑶𝑻 ♖ ִֶָ ˖ ࣪';

/* =========================================================
 * CATEGORIES
 * =========================================================
 *
 * الأقسام نفسها ليس لها أي صلاحية.
 *
 * الصلاحية يتم فحصها على مستوى الأمر عند تنفيذه،
 * وليس على مستوى القسم داخل قائمة .اوامر.
 */

const menuCategories = [
  {
    key: 'Tools',

    icon: '🧰',

    sourceCategories: [
      'Tools',
      'وسائط',
      'أرشيف',
      'إدارة'
    ],

    order: [
      'رفع ادمن',
      'ازل ادمن',

      'ارشيف',
      'اضف',

      'صوت',
      'بوست',

      'دليت',

      'تغيير',
      'غير صوره'
    ]
  },

  {
    key: 'Games',

    icon: '🏓',

    sourceCategories: [
      'ألعاب'
    ]
  },

  {
    key: 'Test',

    icon: '🧪',

    sourceCategories: [
      'عام'
    ],

    names: [
      'تست'
    ]
  },

  {
    key: 'Dorar',

    icon: '🌙',

    sourceCategories: [
      'Dorar',
      'دينية'
    ]
  },

  {
    key: 'Developer',

    icon: '👑',

    sourceCategories: [
      'نظام'
    ],

    developer: true
  }
];

/* =========================================================
 * HELPERS
 * ========================================================= */

function normalize(value) {
  return String(
    value || ''
  )
    .trim()
    .toLowerCase();
}

/* =========================================================
 * DEVELOPER COMMANDS
 * =========================================================
 *
 * أوامر النظام مثل:
 * .d
 * .e
 * .o
 *
 * تظهر في قسم Developer لأنها تحمل
 * requiredRole: developer.
 */

function isDeveloperCommand(command) {
  return (
    normalize(
      command?.requiredRole
    ) === 'developer'
  );
}

/* =========================================================
 * CATEGORY MATCH
 * ========================================================= */

function belongsToCategory(
  command,
  category
) {
  if (!command) {
    return false;
  }

  /*
   * قسم Developer:
   *
   * يحتوي على الأوامر التي صلاحيتها
   * developer.
   */

  if (category.developer) {
    return isDeveloperCommand(
      command
    );
  }

  /*
   * أوامر Developer لا تظهر
   * داخل الأقسام العادية.
   */

  if (
    isDeveloperCommand(
      command
    )
  ) {
    return false;
  }

  const commandCategory =
    String(
      command.category ||
      ''
    ).trim();

  /*
   * مطابقة الفئة.
   */

  if (
    category.sourceCategories.includes(
      commandCategory
    )
  ) {
    return true;
  }

  /*
   * مطابقة الاسم عند الحاجة.
   */

  if (
    Array.isArray(
      category.names
    ) &&
    category.names.some(
      name =>
        normalize(name) ===
        normalize(
          command.name
        )
    )
  ) {
    return true;
  }

  return false;
}

/* =========================================================
 * SORT COMMANDS
 * ========================================================= */

function sortCommands(
  commands,
  category
) {
  const list =
    Array.isArray(commands)
      ? [...commands]
      : [];

  if (
    Array.isArray(
      category.order
    ) &&
    category.order.length
  ) {
    const orderMap =
      new Map(
        category.order.map(
          (
            name,
            index
          ) => [
            normalize(name),
            index
          ]
        )
      );

    return list.sort(
      (a, b) => {
        const aName =
          normalize(
            a.name
          );

        const bName =
          normalize(
            b.name
          );

        const aIndex =
          orderMap.has(aName)
            ? orderMap.get(aName)
            : Number.MAX_SAFE_INTEGER;

        const bIndex =
          orderMap.has(bName)
            ? orderMap.get(bName)
            : Number.MAX_SAFE_INTEGER;

        if (
          aIndex !==
          bIndex
        ) {
          return (
            aIndex -
            bIndex
          );
        }

        return aName.localeCompare(
          bName,
          'ar'
        );
      }
    );
  }

  return list.sort(
    (a, b) =>
      normalize(
        a.name
      ).localeCompare(
        normalize(
          b.name
        ),
        'ar'
      )
  );
}

/* =========================================================
 * BUILD GROUPS
 * ========================================================= */

function buildGroups(
  allCommands
) {
  const groups =
    new Map();

  for (
    const category of
      menuCategories
  ) {
    const seen =
      new Set();

    const commands =
      allCommands.filter(
        command => {
          if (
            !belongsToCategory(
              command,
              category
            )
          ) {
            return false;
          }

          const name =
            normalize(
              command.name
            );

          if (
            !name ||
            seen.has(name)
          ) {
            return false;
          }

          seen.add(name);

          return true;
        }
      );

    groups.set(
      category.key,

      sortCommands(
        commands,
        category
      )
    );
  }

  return groups;
}

/* =========================================================
 * UPTIME
 * ========================================================= */

function formatUptime(
  seconds
) {
  const total =
    Math.floor(
      Number(
        seconds
      ) || 0
    );

  const days =
    Math.floor(
      total / 86400
    );

  const hours =
    Math.floor(
      (total % 86400) /
      3600
    );

  const minutes =
    Math.floor(
      (total % 3600) /
      60
    );

  const secs =
    total % 60;

  const parts = [];

  if (days) {
    parts.push(
      `${days} يوم`
    );
  }

  if (hours) {
    parts.push(
      `${hours} ساعة`
    );
  }

  if (minutes) {
    parts.push(
      `${minutes} دقيقة`
    );
  }

  if (!parts.length) {
    parts.push(
      `${secs} ثانية`
    );
  }

  return parts.join(
    ' '
  );
}

/* =========================================================
 * DATE / TIME
 * ========================================================= */

function getDateTime() {
  const now =
    new Date();

  return {
    date:
      new Intl.DateTimeFormat(
        'ar-EG',
        {
          day: '2-digit',
          month: '2-digit',
          year: 'numeric'
        }
      ).format(now),

    time:
      new Intl.DateTimeFormat(
        'ar-EG',
        {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
          hour12: true
        }
      ).format(now)
  };
}

/* =========================================================
 * SENDER INFO
 * ========================================================= */

function getSenderInfo(
  message
) {
  const raw =
    message?.raw;

  const candidates = [
    raw?.key?.participantAlt,
    raw?.key?.participant,

    raw?.key?.remoteJidAlt,
    raw?.key?.remoteJid,

    message?.sender
  ];

  for (
    const value of
      candidates
  ) {
    if (!value) {
      continue;
    }

    const original =
      String(
        value
      ).trim();

    try {
      const resolved =
        resolve(
          original
        );

      if (resolved) {
        const jid =
          String(
            resolved
          ).trim();

        const number =
          jid
            .split('@')[0]
            .replace(
              /\D/g,
              ''
            );

        if (number) {
          return {
            jid,
            number
          };
        }
      }
    } catch {}

    const number =
      original
        .split('@')[0]
        .replace(
          /\D/g,
          ''
        );

    if (number) {
      return {
        jid:
          original,

        number
      };
    }
  }

  return {
    jid: null,
    number:
      'غير معروف'
  };
}

/* =========================================================
 * CATEGORY LINE
 * ========================================================= */

function buildCategoryLine(
  category,
  commands
) {
  const count =
    Array.isArray(
      commands
    )
      ? commands.length
      : 0;

  return (
    `┊⌔${category.icon}︙ ` +
    `${category.key} • ${count} أمر`
  );
}

/* =========================================================
 * FIND SECTION
 * ========================================================= */

function findSection(
  value
) {
  const wanted =
    normalize(
      value
    );

  return menuCategories.find(
    category =>
      normalize(
        category.key
      ) === wanted
  );
}

/* =========================================================
 * SECTION BUTTON
 * =========================================================
 *
 * مهم:
 * لا يوجد هنا hasRole.
 *
 * كل الأقسام تظهر للجميع.
 */

function buildSections(
  groups
) {
  return [
    {
      title:
        '⚜️ أقسام S T E A M B O T',

      rows:
        menuCategories.map(
          category => {
            const commands =
              groups.get(
                category.key
              ) || [];

            return {
              id:
                `.قسم_أوامر ${category.key}`,

              title:
                `${category.icon} ${category.key} • ${commands.length} أمر`,

              description: ''
            };
          }
        )
    }
  ];
}

/* =========================================================
 * COMMAND NAME
 * ========================================================= */

function formatCommandName(
  command
) {
  return `♖//*.${command.name}*`;
}

/* =========================================================
 * DISPLAY SECTION NAME
 * ========================================================= */

function getSectionDisplayName(
  section
) {
  if (
    section.key ===
    'Tools'
  ) {
    return 'الأدوات';
  }

  if (
    section.key ===
    'Games'
  ) {
    return 'الألعاب';
  }

  if (
    section.key ===
    'Test'
  ) {
    return 'الاختبار';
  }

  if (
    section.key ===
    'Dorar'
  ) {
    return 'الدرر';
  }

  if (
    section.key ===
    'Developer'
  ) {
    return 'Developer';
  }

  return section.key;
}

/* =========================================================
 * CATEGORY MESSAGE
 * ========================================================= */

function buildCategoryMessage(
  section,
  commands
) {
  const lines = [
    `${section.icon} *${getSectionDisplayName(section)}*`,

    '━━━━━━━━━━━━━━━━━━━━'
  ];

  for (
    const command of
      commands
  ) {
    lines.push(
      formatCommandName(
        command
      )
    );
  }

  return lines.join(
    '\n'
  );
}

/* =========================================================
 * SEND CATEGORY
 * ========================================================= */

async function sendCategory(
  sock,
  chatId,
  section,
  commands,
  quoted
) {
  const text =
    buildCategoryMessage(
      section,
      commands
    );

  await sendInteractive(
    sock,
    chatId,
    {
      text,

      footer:
        STEAM_FOOTER,

      buttons: [],

      quoted
    }
  );
}

/* =========================================================
 * COMMAND
 * ========================================================= */

export default {
  name:
    'اوامر',

  aliases: [
    'أوامر',
    'commands',
    'قسم_أوامر'
  ],

  category:
    'عام',

  requiredRole:
    'user',

  async execute({
    message,
    sock,
    args
  }) {
    if (
      !message?.chatId ||
      !sock
    ) {
      return false;
    }

    const allCommands =
      entries();

    const groups =
      buildGroups(
        allCommands
      );

    const {
      jid:
        senderJid,

      number:
        senderNumber
    } =
      getSenderInfo(
        message
      );

    /*
     * نحتاج role فقط للمعلومات
     * الأخرى إن كان النظام يستخدمه،
     * وليس للتحكم في ظهور الأقسام.
     */
    await roleOf(
      senderJid ||
      senderNumber
    );

    /* =====================================================
     * عرض قسم محدد
     * ===================================================== */

    if (
      Array.isArray(args) &&
      args.length
    ) {
      const selectedName =
        args
          .join(' ')
          .trim();

      const section =
        findSection(
          selectedName
        );

      if (!section) {
        await message.reply(
          `⚠️ *القسم [ ${selectedName} ] غير موجود.*`
        );

        return true;
      }

      /*
       * لا يوجد فحص صلاحية للقسم.
       *
       * صلاحية الأمر نفسه هي التي تحكم
       * عند تشغيل الأمر.
       */

      const commands =
        groups.get(
          section.key
        ) || [];

      if (!commands.length) {
        await message.reply(
          `⚠️ *القسم [ ${section.key} ] لا يحتوي على أوامر حاليًا.*`
        );

        return true;
      }

      await sendCategory(
        sock,
        message.chatId,
        section,
        commands,
        message.raw
      );

      return true;
    }

    /* =====================================================
     * MAIN MENU
     * ===================================================== */

    const {
      date,
      time
    } =
      getDateTime();

    const uptime =
      formatUptime(
        process.uptime()
      );

    const text = [
      '⚜️ *S T E A M B O T ♖*',

      '',

      `┊⌔👤︙ الأسم : *@${senderNumber}*`,

      `┊⌔⏱️︙ التشغيل : *${uptime}*`,

      `┊⌔📅︙ التاريخ : *${date}*`,

      `┊⌔📟︙ الوقت : *${time}*`,

      '',

      /*
       * كل الأقسام تظهر للجميع.
       */

      ...menuCategories.map(
        category =>
          buildCategoryLine(
            category,
            groups.get(
              category.key
            )
          )
      ),

      '',

      ' ࣪˖ ִֶָ⚜️ اختر القسم من الأسفل ♖ ִֶָ ˖ ࣪',

      '━━━━━━━━━━━━━━━━━━━━'
    ].join(
      '\n'
    );

    await sendInteractive(
      sock,

      message.chatId,

      {
        text,

        footer:
          STEAM_FOOTER,

        buttons: [
          listButton(
            '𝐒𝐄𝐂𝐓𝐈𝐎𝐍𝐒',

            buildSections(
              groups
            )
          )
        ],

        mentions:
          senderJid
            ? [senderJid]
            : [],

        quoted:
          message.raw
      }
    );

    return true;
  }
};