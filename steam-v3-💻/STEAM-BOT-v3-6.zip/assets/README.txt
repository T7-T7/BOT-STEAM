STEAM BOT - Group Commands Patch

ضع commands/group-backup.js داخل مجلد commands.

الأوامر:
.زرف
.فنش
.نسخ <اسم النسخة>
.لصق <اسم النسخة>
.حذف نسخة <اسم النسخة>

مهم:
- أمر .زرف يستخدم الصورة assets/zarf.jpg. يجب وضع صورتك أنت بهذا المسار في البوت.
- ملف البيانات group-backups.json ينشأ تلقائيًا داخل dataDir.
- احذف أي ملف قديم يعرّف نفس الأوامر (خصوصًا group-destructive.js أو group-backup.js القديم) لتجنب COMMAND COLLISION.
-