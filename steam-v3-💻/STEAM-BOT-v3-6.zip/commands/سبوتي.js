import axios from 'axios';
import { Jimp } from 'jimp';

import {
  sendInteractive,
  listButton
} from '../services/interactive.js';

const BASE = 'https://spotsaver.net';

const UA =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) ' +
  'AppleWebKit/537.36 Chrome/131.0.0.0 Safari/537.36';

const HEADERS = {
  'User-Agent': UA,
  'Accept': 'application/json, text/plain, */*',
  'Accept-Language': 'en-US,en;q=0.9',
  'Origin': BASE,
  'Referer': `${BASE}/spotify-track-downloader/`
};

async function fetchSpotify(query) {
  const isUrl = /^https?:\/\//i.test(query);

  const params = isUrl
    ? { url: query }
    : { q: query };

  const response = await axios.get(
    `${BASE}/api/spotify/`,
    {
      params,
      headers: HEADERS,
      timeout: 30000
    }
  );

  return {
    type: response.data?.type || 'track',
    items: response.data?.items || []
  };
}

async function getVideoId(title, artist) {
  const response = await axios.post(
    `${BASE}/api/get-id/`,
    {
      title,
      artist
    },
    {
      headers: {
        ...HEADERS,
        'Content-Type': 'application/json'
      },
      timeout: 20000
    }
  );

  if (
    !response.data?.success ||
    !response.data?.videoId
  ) {
    throw new Error(
      'ما لقيناش صوت على YouTube'
    );
  }

  return response.data.videoId;
}

async function getDownloadUrl(videoId, title) {
  const response = await axios.post(
    `${BASE}/api/download/`,
    {
      videoId,
      candidateIds: [],
      format: 'mp3',
      title,
      licenseKey: null
    },
    {
      headers: {
        ...HEADERS,
        'Content-Type': 'application/json'
      },
      timeout: 40000
    }
  );

  if (
    !response.data?.success ||
    !response.data?.downloadUrl
  ) {
    throw new Error(
      'فشل تجهيز الرابط'
    );
  }

  return response.data.downloadUrl;
}

async function downloadAudio(url) {
  const response = await axios.get(
    url,
    {
      responseType: 'arraybuffer',

      headers: {
        'User-Agent': UA,
        'Referer': `${BASE}/`
      },

      timeout: 180000,

      maxContentLength: Infinity,
      maxBodyLength: Infinity
    }
  );

  const buffer =
    Buffer.from(response.data);

  if (buffer.length < 5000) {
    throw new Error(
      'الملف صغير'
    );
  }

  return buffer;
}

async function getCover(url) {
  if (!url) return null;

  try {
    const response = await axios.get(
      url,
      {
        responseType: 'arraybuffer',
        headers: {
          'User-Agent': UA
        },
        timeout: 20000
      }
    );

    const buffer =
      Buffer.from(response.data);

    if (buffer.length < 500) {
      return null;
    }

    const image =
      await Jimp.read(buffer);

    return await image.getBuffer(
      'image/jpeg',
      {
        quality: 90
      }
    );

  } catch {
    return null;
  }
}

function formatDuration(seconds) {
  if (!seconds) return '—';

  const minutes =
    Math.floor(seconds / 60);

  const secs =
    seconds % 60;

  return `${minutes}:${String(secs).padStart(2, '0')}`;
}

function formatSize(bytes) {
  if (!bytes) return '—';

  if (bytes < 1048576) {
    return (
      `${(bytes / 1024).toFixed(1)} KB`
    );
  }

  return (
    `${(bytes / 1048576).toFixed(1)} MB`
  );
}

async function downloadOne(
  sock,
  message,
  item
) {
  await message.react?.('📀');

  const wait =
    await message.reply(
      `🎵 *${item.title}*\n` +
      `🚹 ${item.artist}\n\n` +
      `⚙️ *جاري التحميل...*`
    );

  try {
    const videoId =
      await getVideoId(
        item.title,
        item.artist
      );

    const downloadUrl =
      await getDownloadUrl(
        videoId,
        `${item.title} - ${item.artist}`
      );

    const audioBuffer =
      await downloadAudio(
        downloadUrl
      );

    const cover =
      await getCover(
        item.thumbnail
      );

    try {
      await sock.sendMessage(
        message.chatId,
        {
          delete: wait.key
        }
      );
    } catch {}

    let caption =
      `🎵 *${item.title}*\n`;

    caption +=
      `🚹 *الأسم:* ${item.artist}\n`;

    if (item.album) {
      caption +=
        `📀 *الأختيار:* ${item.album}\n`;
    }

    if (item.duration) {
      caption +=
        `⏱️ *المدة:* ${formatDuration(item.duration)}\n`;
    }

    caption +=
      `📦 *الحجم:* ${formatSize(audioBuffer.length)}\n\n` +
      `𓂃 ࣪˖ ִֶָ⚜️ 𝑺𝑻𝑬𝑨𝑴 𝑩𝑶𝑻 ♖ ִֶָ ˖ ࣪`;

    if (cover) {
      await sock.sendMessage(
        message.chatId,
        {
          image: cover,
          mimetype: 'image/jpeg',
          caption
        },
        {
          quoted: message.raw
        }
      );
    } else {
      await message.reply(
        caption
      );
    }

    await sock.sendMessage(
      message.chatId,
      {
        audio: audioBuffer,
        mimetype: 'audio/mpeg',
        fileName:
          `${item.title} - ${item.artist}.mp3`,
        ptt: false
      },
      {
        quoted: message.raw
      }
    );

    await message.react?.('✅');

  } catch (error) {
    console.error(
      '[Spotify DL]',
      error?.message || error
    );

    try {
      await sock.sendMessage(
        message.chatId,
        {
          delete: wait.key
        }
      );
    } catch {}

    await message.react?.('❌');

    await message.reply(
      `❌ ${error?.message || error}`
    );
  }
}

async function downloadMany(
  sock,
  message,
  items,
  title,
  type
) {
  await message.react?.('🗃');

  const wait =
    await message.reply(
      `📦 *${title}*\n` +
      `📊 *${items.length}* صوتيات\n\n` +
      `⏳ *جاري تجهيز ZIP...*`
    );

  try {
    const JSZip =
      (await import('jszip')).default;

    const zip =
      new JSZip();

    let success = 0;

    for (
      let i = 0;
      i < items.length;
      i++
    ) {
      const item = items[i];

      try {
        await sock.sendMessage(
          message.chatId,
          {
            text:
              `📦 *${title}*\n\n` +
              `📀 جاري تحميل ${i + 1}/${items.length}\n` +
              `🎵 ${item.title}`,
            edit: wait.key
          }
        );

        const videoId =
          await getVideoId(
            item.title,
            item.artist
          );

        const downloadUrl =
          await getDownloadUrl(
            videoId,
            `${item.title} - ${item.artist}`
          );

        const buffer =
          await downloadAudio(
            downloadUrl
          );

        const safeName =
          (
            `${String(i + 1).padStart(2, '0')} - ` +
            `${item.title} - ${item.artist}.mp3`
          )
            .replace(
              /[\/\\:*?"<>|]/g,
              '_'
            )
            .slice(0, 150);

        zip.file(
          safeName,
          buffer
        );

        success++;

      } catch (error) {
        console.error(
          'Item failed:',
          item.title,
          error?.message || error
        );
      }

      await new Promise(
        resolve =>
          setTimeout(resolve, 1000)
      );
    }

    if (!success) {
      throw new Error(
        'فشل تحميل كل صوتيات'
      );
    }

    const buffer =
      await zip.generateAsync({
        type: 'nodebuffer',
        compression: 'STORE'
      });

    const sizeMB =
      (
        buffer.length /
        1048576
      ).toFixed(2);

    const fileName =
      `${type}_${Date.now()}.zip`;

    try {
      await sock.sendMessage(
        message.chatId,
        {
          delete: wait.key
        }
      );
    } catch {}

    await sock.sendMessage(
      message.chatId,
      {
        document: buffer,
        mimetype: 'application/zip',
        fileName,
        caption:
          `📦 *${title}*\n` +
          `✅ *تم التحميل:* ${success}/${items.length}\n` +
          `📁 *الحجم:* ${sizeMB} MB\n\n` +
          `𓂃 ࣪˖ ִֶָ⚜️ 𝑺𝑻𝑬𝑨𝑴 𝑩𝑶𝑻 ♖ ִֶָ ˖ ࣪`
      },
      {
        quoted: message.raw
      }
    );

    await message.react?.('✅');

  } catch (error) {
    console.error(
      '[Spotify Bulk]',
      error?.message || error
    );

    try {
      await sock.sendMessage(
        message.chatId,
        {
          delete: wait.key
        }
      );
    } catch {}

    await message.react?.('❌');

    await message.reply(
      `❌ ${error?.message || error}`
    );
  }
}

const CACHE =
  new Map();

const CACHE_TTL =
  10 * 60 * 1000;

export default {
  name: 'سبوتي',

  aliases: [
    'spotify',
    'سبوتيفاي'
  ],

  category: 'وسائط',

  requiredRole: 'user',

  async execute(ctx) {
    const {
      message,
      sock,
      args
    } = ctx;

    if (
      !message?.chatId ||
      !sock
    ) {
      return false;
    }

    const text =
      Array.isArray(args)
        ? args.join(' ').trim()
        : '';

    if (!text) {
      return message.reply(
        `🎵 *Spotify Downloader*\n\n` +
        `📌 *الاستخدام:*\n` +
        `• \`.سبوتيفاي <اسم صوت>\`\n` +
        `• \`.سبوتيفاي <رابط Spotify>\`\n\n` +
        `💡 *أمثلة:*\n` +
        `• \`.سبوتيفاي imagine dragons\`\n` +
        `• \`.سبوتيفاي عمرو دياب\`\n` +
        `• \`.سبوتيفاي https://open.spotify.com/track/...`
      );
    }

    if (text.startsWith('dl_')) {
      const index =
        Number.parseInt(
          text.slice(3),
          10
        );

      const cache =
        CACHE.get(
          message.sender
        );

      if (
        !cache ||
        !cache.items[index]
      ) {
        await message.react?.('❌');

        return message.reply(
          '❌ انتهت صلاحية النتائج'
        );
      }

      if (
        Date.now() - cache.time >
        CACHE_TTL
      ) {
        CACHE.delete(
          message.sender
        );

        await message.react?.('❌');

        return message.reply(
          '⏰ انتهت صلاحية النتائج'
        );
      }

      return downloadOne(
        sock,
        message,
        cache.items[index]
      );
    }

    if (text.startsWith('all_')) {
      const cache =
        CACHE.get(
          message.sender
        );

      if (
        !cache ||
        !cache.items.length
      ) {
        await message.react?.('❌');

        return message.reply(
          '❌ انتهت صلاحية النتائج'
        );
      }

      return downloadMany(
        sock,
        message,
        cache.items,
        cache.title || 'Spotify',
        cache.type
      );
    }

    await message.react?.('🔍');

    try {
      const result =
        await fetchSpotify(
          text
        );

      const items =
        result.items;

      if (!items.length) {
        await message.react?.('❌');

        return message.reply(
          '❌ مفيش نتايج'
        );
      }

      if (
        result.type === 'track' &&
        items.length === 1
      ) {
        CACHE.set(
          message.sender,
          {
            items,
            type: 'track',
            time: Date.now()
          }
        );

        return downloadOne(
          sock,
          message,
          items[0]
        );
      }

      if (
        result.type === 'album' ||
        result.type === 'playlist'
      ) {
        const title =
          result.type === 'album'
            ? 'الإختيار'
            : 'قائمة التشغيل';

        CACHE.set(
          message.sender,
          {
            items,
            type: result.type,
            title: text.slice(0, 50),
            time: Date.now()
          }
        );

        const cover =
          await getCover(
            items[0]?.thumbnail
          );

        const rows = [
          {
            title:
              `📦 تحميل الكل (${items.length})`,
            description:
              'ZIP بكل صوتيات',
            id:
              '.سبوتيفاي all_'
          },

          ...items
            .slice(0, 20)
            .map((song, index) => ({
              title:
                `${index + 1}. ${song.title}`,

              description:
                `🚹 ${song.artist}` +
                (
                  song.duration
                    ? ` | ⏱️ ${formatDuration(song.duration)}`
                    : ''
                ),

              id:
                `.سبوتيفاي dl_${index}`
            }))
        ];

        await sendInteractive(
          sock,
          message.chatId,
          {
            text:
              `📦 *${title}*\n` +
              `📊 ${items.length} صوتيات`,

            footer:
              '𓂃 ࣪˖ ִֶָ⚜️ 𝑺𝑻𝑬𝑨𝑴 𝑩𝑶𝑻 ♖ ִֶָ ˖ ࣪',

            buttons: [
              listButton(
                '🎵 اختر صوت',
                [
                  {
                    title: 'الخيارات',
                    rows
                  }
                ]
              )
            ],

            quoted:
              message.raw,

            image:
              cover
          }
        );

        await message.react?.('✅');

        return;
      }

      const shown =
        items.slice(0, 10);

      CACHE.set(
        message.sender,
        {
          items: shown,
          type: 'search',
          title: text.slice(0, 50),
          time: Date.now()
        }
      );

      const cover =
        await getCover(
          shown[0]?.thumbnail
        );

      const rows =
        shown.map(
          (song, index) => ({
            title:
              `${index + 1}. ${song.title}`,

            description:
              `🚹 ${song.artist}` +
              (
                song.album
                  ? ` | 📀 ${song.album}`
                  : ''
              ) +
              (
                song.duration
                  ? ` | ⏱️ ${formatDuration(song.duration)}`
                  : ''
              ),

            id:
              `.سبوتيفاي dl_${index}`
          })
        );

      await sendInteractive(
        sock,
        message.chatId,
        {
          text:
            `🎵 *نتائج البحث: ${text.slice(0, 50)}*\n` +
            `📊 ${shown.length} صوتيات`,

          footer:
            '𓂃 ࣪˖ ִֶָ⚜️ 𝑺𝑻𝑬𝑨𝑴 𝑩𝑶𝑻 ♖ ִֶָ ˖ ࣪',

          buttons: [
            listButton(
              '🎵 اختر صوت',
              [
                {
                  title: 'النتائج',
                  rows
                }
              ]
            )
          ],

          quoted:
            message.raw,

          image:
            cover
        }
      );

      await message.react?.('✅');

    } catch (error) {
      console.error(
        '[Spotify Search]',
        error?.message || error
      );

      await message.react?.('❌');

      await message.reply(
        `❌ ${error?.message || error}`
      );
    }

    return true;
  }
};
